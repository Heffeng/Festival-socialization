package com.anniday.presenters;

import com.android.volley.Response;
import com.anniday.model.CloudFile;
import com.anniday.model.OSS.OSSManager;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.User;
import com.anniday.model.service.UserManager;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.BitmapUtil;
import com.anniday.view.IUserInfoSettingView;

import java.io.IOException;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by Administrator on 2015/7/15，23.22.
 * 描述：用户信息设置presenter层
 */
public class UserInfoSettingPresenter extends BasePresenter<IUserInfoSettingView> {



    public void commit(final String currentPicPath, final User user) {

        view.showProgressDialog("正在提交信息");
        Observable.create(new Observable.OnSubscribe<User>() {
            @Override
            public void call(final Subscriber<? super User> subscriber) {
                try {
                    if (currentPicPath!=null){
                        CloudFile cloudFile = OSSManager.uploadFile(currentPicPath);
                        user.setAvatarUrl(cloudFile.getFileUrl());
                    }
                    UserManager.getInstance().editUser(user, new Response.Listener<User>() {
                        @Override
                        public void onResponse(User user) {
                            subscriber.onNext(user);
                        }
                    }, new NetErrorListener() {
                        @Override
                        public void onError(ErrorMessage msg) {
                            subscriber.onError(new Throwable(msg.getMessage()));
                        }
                    });

                } catch (IOException e) {
                    e.printStackTrace();
                    subscriber.onError(new Throwable("我也不知道为什么，不能处理你的照片，请重新试一次吧"));
                }
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Subscriber<User>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                if (view != null) {
                    view.showError(new ErrorMessage(0, e.getMessage()));
                    view.hideProgressDialog();
                }
            }

            @Override
            public void onNext(User user) {
                if (view != null) {
                    User.saveCurrentUser(user);
                    UserManager.getInstance().saveUser(user);
                    view.editUserSucess();
                    view.hideProgressDialog();
                }
            }
        });
    }

    public void cutAvatar(final float[] scales, final String currentPicPath) {
        view.showProgressDialog("正在处理头像");
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(final Subscriber<? super String> subscriber) {
                try {
                    BitmapUtil.cutBitmap(currentPicPath, currentPicPath, scales);
                    BitmapUtil.compressBitmap(currentPicPath, currentPicPath);
                    subscriber.onNext(currentPicPath);
                } catch (IOException e) {
                    e.printStackTrace();
                    subscriber.onError(new Throwable("我也不知道为什么，不能处理你的照片，请重新试一次吧"));
                }
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
                if (view != null) {
                    view.showError(e.getMessage());
                    view.hideProgressDialog();
                }
            }

            @Override
            public void onNext(String path) {
                if (view != null) {
                    view.hideProgressDialog();
                    view.cutAvatarSuccess(path);
                }
            }
        });
    }
}
