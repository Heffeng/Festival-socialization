package com.anniday.presenters;

/**
 * Created by Administrator on 2015/7/13，17.54.
 * 描述：获取对话presenter层
 */
public interface IChatPresenter {

    /**
     * 获取对话消息
     *
     * @param userId
     */
    void requestSessions(String userId);

    /**
     * 加载更多对话消息
     */
    void loadMoreSessions();

    /**
     * 将该用户加入黑名单
     *
     * @param userId
     */
    void addToBlackList(String userId);


    /**
     * 举报该用户
     *
     * @param userId
     */
    void report(String userId);
}
