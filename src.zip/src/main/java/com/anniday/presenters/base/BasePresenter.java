package com.anniday.presenters.base;


import com.anniday.app.App;

import com.anniday.model.db.dao.StoryDao;
import com.anniday.view.base.BaseView;

/**
 * Created by Administrator on 2015/6/12.
 * 描述：Presenter的基类
 */
public class BasePresenter<V extends BaseView> {
    protected V view;
    private boolean isActive;

    protected boolean isActive() {
        return isActive;
    }

    public void setView(V view) {
        this.view = view;
    }

    public void onDestroy() {
        isActive = false;
        view = null;
    }

    public void onResume() {
        isActive = true;
    }

    public void onPause() {
        isActive = false;
    }


}
