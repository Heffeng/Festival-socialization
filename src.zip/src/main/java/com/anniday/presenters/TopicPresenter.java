package com.anniday.presenters;

import com.android.volley.Response;
import com.anniday.model.service.AnniDayManager;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.Topic;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.view.ITopicView;

import java.util.List;

/**
 * Created by VeyHey on 2016/3/28.
 * 话题presenter层
 */
public class TopicPresenter extends BasePresenter<ITopicView> {
    private int page;
    private int num;
    private List<Topic> mTopics;
    private boolean hasMore;

    public void requestTopics(){
        hasMore = true;
        this.page = 0;
        this.num = 10;
        AnniDayManager.getInstance().list(page, num, new Response.Listener<List<Topic>>() {
            @Override
            public void onResponse(List<Topic> topics) {
                mTopics = topics;
                view.showTopics(mTopics);
                view.loadComplete();
                if (mTopics.size()<num){
                    hasMore = false;
                }
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.loadComplete();
            }
        });
    }

    public void loadMore() {
        if (!hasMore){
            view.loadComplete();
            return;
        }
        this.page++;
        AnniDayManager.getInstance().list(page, num, new Response.Listener<List<Topic>>() {
            @Override
            public void onResponse(List<Topic> topics) {
                if (topics.size() < num) {
                    hasMore = false;
                }
                topics.addAll(0,mTopics);
                mTopics = topics;
                view.showTopics(mTopics);
                view.loadComplete();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.loadComplete();
            }
        });
    }
}
