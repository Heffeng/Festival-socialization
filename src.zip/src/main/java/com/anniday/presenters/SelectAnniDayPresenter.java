package com.anniday.presenters;

import com.android.volley.Response;
import com.anniday.model.service.AnniDayManager;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.HotAnniDay;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.view.ISelectAnniDayView;

import java.util.List;

/**
 * Created by VeyHey on 2016/3/28.
 * 选择节日presenter层
 */
public class SelectAnniDayPresenter extends BasePresenter<ISelectAnniDayView>{
    private int page;
    private int num;
    private String key;
    private List<HotAnniDay> mAnniDays;
    public void requestAnniDay(final String s) {
        this.page = 0;
        this.num = 10;
        this.key = s;
        AnniDayManager.getInstance().getHotAnniDayByName(key, page, num, new Response.Listener<List<HotAnniDay>>() {
            @Override
            public void onResponse(List<HotAnniDay> hotAnniDays) {
                if (hotAnniDays.size()<num){
                    view.setLoadMoreEnable(false);
                }else {
                    view.setLoadMoreEnable(true);
                }
                if (hotAnniDays.size()>0) {
                    mAnniDays = hotAnniDays;
                    view.showHotAnniDays(hotAnniDays);
                }else {
                    view.showNoResult(key);
                }
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
            }
        });
    }

    public void loadMoreAnniDay() {
        page++;
        AnniDayManager.getInstance().getHotAnniDayByName(key, page, num, new Response.Listener<List<HotAnniDay>>() {
            @Override
            public void onResponse(List<HotAnniDay> hotAnniDays) {
                if (hotAnniDays.size()<num){
                    view.setLoadMoreEnable(false);
                }else {
                    view.setLoadMoreEnable(true);
                }
                if (hotAnniDays.size()>0) {
                    hotAnniDays.addAll(0,mAnniDays);
                    mAnniDays = hotAnniDays;
                    view.showHotAnniDays(mAnniDays);
                }
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
            }
        });
    }
}
