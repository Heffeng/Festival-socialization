package com.anniday.presenters;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.android.volley.Response;
import com.anniday.app.App;
import com.anniday.constant.URLConstant;
import com.anniday.model.CommentModel;
import com.anniday.model.db.User;
import com.anniday.model.service.ErrorMessage;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.LogUtil;
import com.anniday.utils.NetworkUtil;
import com.anniday.utils.SharePreferenceUtil;
import com.anniday.view.GetCommentView;
import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by HuangChun on 2016/3/30.
 * 获取评论presenter层
 */
public class GetCommentPresenter extends BasePresenter<GetCommentView> {
    private Context context;

    public GetCommentPresenter(Context context,GetCommentView getCommentView) {
        this.context = context;
        view = getCommentView;
    }
    public void getComment(int pageSize,int pageNum,Long storyId){
        view.startGet();
        User currentUesr = JSON.parseObject(SharePreferenceUtil.getString(App.application, com.anniday.model.service.User.CURRENT_USER), User.class);
        Long userId = currentUesr.getUserId();
        Map<String,String> params = new HashMap<String ,String>();
        LogUtil.e(String.valueOf(storyId));
        params.put("storyId", String.valueOf(storyId));
        params.put("pageSize",String.valueOf(pageSize));
        params.put("pageNum", String.valueOf(pageNum));
        GsonRequest<List<CommentModel>> gsonRequest = new GsonRequest<List<CommentModel>>(URLConstant.GET_COMMENT_BY_STORYID, params,
                new TypeToken<List<CommentModel>>() {
                }.getType(), new Response.Listener<List<CommentModel>>() {
            @Override
            public void onResponse(List<CommentModel> commentModels) {
                if (view!=null) {
                    view.endGet();
                    LogUtil.e(String.valueOf(commentModels.size()));
                    view.setResult(commentModels);
                }
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                if (view!=null) {
                    view.endGet();
                    view.showError(msg);
                }
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
