package com.anniday.presenters;

/**
 * Created by WeiHey on 2015/7/13，15.01.
 * 描述：presenter for SessionItem
 */
public interface ISessionItemPresenter {
    /**
     * 获取User
     *
     * @param userId
     */
    void getUser(String userId);

    /**
     * 删除User
     *
     * @param userId
     */
    void deleteUser(String userId);
}
