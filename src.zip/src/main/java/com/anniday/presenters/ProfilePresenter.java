package com.anniday.presenters;

import com.android.volley.Response;
import com.anniday.model.db.Story;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.StoryManager;
import com.anniday.model.service.User;
import com.anniday.model.service.UserManager;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.view.IProfileView;
import com.anniday.view.ITopicDetailView;

import java.util.List;

/**
 * Created by VeyHey on 2016/3/28.
 */
public class ProfilePresenter extends BasePresenter<IProfileView> {
    private int page;
    private int num;
    private List<Story> mTopics;
    private boolean hasMore;
    private long userId;

    public ProfilePresenter(long userId){
        this.userId = userId;
    }

    public void requestStories(){
        hasMore = true;
        this.page = 0;
        this.num = 10;
        StoryManager.getInstance().getStorysByUserId(userId, page, num, new Response.Listener<List<Story>>() {
            @Override
            public void onResponse(List<Story> topics) {
                mTopics = topics;
                view.showStorys(mTopics);
                view.loadComplete();
                if (mTopics.size() < num) {
                    hasMore = false;
                }
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.loadComplete();
            }
        });
    }

    public void loadMore() {
        if (!hasMore){
            view.loadComplete();
            return;
        }
        this.page++;
        StoryManager.getInstance().getStorysByAnniDayId(userId, page, num, new Response.Listener<List<Story>>() {
            @Override
            public void onResponse(List<Story> topics) {
                if (topics.size() < num) {
                    hasMore = false;
                }
                topics.addAll(0, mTopics);
                mTopics = topics;
                view.showStorys(mTopics);
                view.loadComplete();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.loadComplete();
            }
        });
    }

    public void requsetUser() {
        UserManager.getInstance().getUserById(userId, new Response.Listener<User>() {
            @Override
            public void onResponse(User user) {
                view.setUser(user);
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
            }
        });
    }
}
