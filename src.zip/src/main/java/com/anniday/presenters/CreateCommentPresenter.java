package com.anniday.presenters;

import android.content.Context;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.CommentModel;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.User;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.LogUtil;
import com.anniday.utils.NetworkUtil;
import com.anniday.view.CreateCommentView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by HuangChun on 2016/4/1.
 * 发表评论presenter层
 */
public class CreateCommentPresenter extends BasePresenter<CreateCommentView> {
    private Context context;

    public CreateCommentPresenter(Context context,CreateCommentView createCommentView) {
        this.context = context;
        view = createCommentView;
    }

    public void createComment(Long toUserId,Long storyId,String content){
        view.startCreate();
        Long fromUserId = User.getCurrentUser().getUserId();
        Long createAt = System.currentTimeMillis();
        Map<String,String> params = new HashMap<>();
        params.put("fromUserId",String.valueOf(fromUserId));
        if(toUserId != null) {
            params.put("toUserId", String.valueOf(toUserId));
        }
        params.put("storyId", String.valueOf(storyId));
        params.put("content",content);
        params.put("createAt",String.valueOf(createAt));

        GsonRequest<CommentModel> gsonRequest = new GsonRequest<CommentModel>(URLConstant.COMMENT, params, CommentModel.class, new Response.Listener<CommentModel>() {
            @Override
            public void onResponse(CommentModel commentModel) {
                view.endCreate();
                LogUtil.e(String.valueOf(commentModel.getCommentId()));
                view.setResult();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.endCreate();
                view.showError(msg);
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
