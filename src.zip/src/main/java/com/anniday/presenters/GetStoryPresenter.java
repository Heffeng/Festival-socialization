package com.anniday.presenters;

import android.content.Context;

import com.android.volley.Response;
import com.anniday.app.App;
import com.anniday.constant.URLConstant;
import com.anniday.model.db.HistoryToday;
import com.anniday.model.db.Story;
import com.anniday.model.db.dao.HistoryTodayDao;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.HistoryTodayManager;
import com.anniday.model.service.StoryModel;
import com.anniday.model.service.User;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.LogUtil;
import com.anniday.utils.NetworkUtil;
import com.anniday.utils.SharePreferenceUtil;
import com.anniday.view.GetStoryView;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.greenrobot.dao.query.QueryBuilder;
import de.greenrobot.dao.query.WhereCondition;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by HuangChun on 2016/3/1.
 * 获取动态presenter层
 */
public class GetStoryPresenter extends BasePresenter<GetStoryView> {
    public static final String LAST_TIME_GET_HISTORY_TODAY = "lastTimeGetHistoryToday";
    private Context context;
    private List<Story> storys;

    public GetStoryPresenter(Context context,GetStoryView getStoryView) {
        this.context = context;
        view = getStoryView;
    }

    public void getHistoryToday(){
        loadHistoryTodays();
        if (System.currentTimeMillis()-SharePreferenceUtil.getLong(App.application,LAST_TIME_GET_HISTORY_TODAY)<3600*12*1000){
            return;
        }
        HistoryTodayManager.getInstance().todayList(new Response.Listener<List<HistoryToday>>() {
            @Override
            public void onResponse(final List<HistoryToday> topics) {
                Observable.create(new Observable.OnSubscribe<Object>() {
                    @Override
                    public void call(Subscriber<? super Object> subscriber) {
                        App.application.daoSession.getHistoryTodayDao().insertOrReplaceInTx(topics);
                        SharePreferenceUtil.saveLong(App.application,
                                LAST_TIME_GET_HISTORY_TODAY, System.currentTimeMillis());
                        subscriber.onNext(null);
                    }
                }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Object>() {
                    @Override
                    public void call(Object o) {
                        loadHistoryTodays();
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {

                    }
                });
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {

            }
        });
    }

    private void loadHistoryTodays() {
        int count = storys.size()/5;
        QueryBuilder<HistoryToday> builder =
                App.application.daoSession.getHistoryTodayDao().queryBuilder();
        builder.limit(count);
        Calendar calendar = Calendar.getInstance();
        builder.where(HistoryTodayDao.Properties.Day.eq(calendar.get(Calendar.DAY_OF_MONTH)),
                HistoryTodayDao.Properties.Month.eq(calendar.get(Calendar.MONTH) + 1));
        List<HistoryToday> list = builder.list();
        count = count>list.size()?list.size():count;
        for (int i = count-1; i >= 0; i--) {
            storys.add(i*5,new Story(list.get(i)));
        }
        if (view!=null){
            view.setResult(storys);
        }
    }

    public void getStory(int pageSize,Long beforeId,Long afterId){
        view.startGet();
        Long userId = User.getCurrentUser().getUserId();
        Map<String,String> params = new HashMap<String ,String>();
        params.put("userId",String.valueOf(userId));
        params.put("size",String.valueOf(pageSize));
        if (beforeId != null){
            params.put("beforeId", String.valueOf(beforeId));
        }
        if (afterId != null){
            params.put("afterId",String.valueOf(afterId));
        }
        GsonRequest<StoryModel> gsonRequest = new GsonRequest<StoryModel>(URLConstant.GETSTORY, params, StoryModel.class, new Response.Listener<StoryModel>() {
            @Override
            public void onResponse(StoryModel storyModel) {
//                Boolean isClearCache = storyModel.getIsClearCache();
//                if (isClearCache){
//                    clearCache();
//                }
//                insertIntoDb(storyModel.getStorys());
//                QueryBuilder<Story> builder;
//                builder = App.application.daoSession.getStoryDao().queryBuilder();
//               builder.orderDesc(StoryDao.Properties.StoryId);
//                builder.limit(20);
//                builder.offset(10);
//                List<Story> list = builder.list();
                view.endGet();
                storys = storyModel.getStorys();
                view.setResult(storys);
                getHistoryToday();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.endGet();
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }

    private void insertIntoDb(List<Story> storys) {
        App.application.daoSession.getStoryDao().insertOrReplaceInTx(storys);
        LogUtil.e(storys.toString());
    }

    private void clearCache() {
        App.application.daoSession.getStoryDao().deleteAll();
    }

}
