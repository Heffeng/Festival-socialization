package com.anniday.presenters;


import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DaoSession;

/**
 * Created by Administrator on 2015/7/14，14.31.
 * 描述：下载音频
 */
public interface IChatAudioPresenter {
    /**
     * 下载音频
     *
     * @param session
     */
    void downAudio(Session session);
}
