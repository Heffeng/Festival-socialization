package com.anniday.presenters;

import android.content.Context;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.service.User;
import com.anniday.model.service.ErrorMessage;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.NetworkUtil;
import com.anniday.view.LoginView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by HuangChun on 2016/2/28.
 * 登陆presenter层
 */
public class LoginPresenter extends BasePresenter<LoginView>{
    private Context context;
    public LoginPresenter(Context context, LoginView loginView){
        this.context = context;
        this.view = loginView;
    }
    public void login(String phoneNumber,String password){
        view.startLogin();
        Map<String,String> params= new HashMap<String,String>();
        params.put("phoneNum",phoneNumber);
        params.put("password",password);
        GsonRequest<User> gsonRequest = new GsonRequest<>(URLConstant.LOGIN, params, User.class, new Response.Listener<User>() {
            @Override
            public void onResponse(User accountModel) {
                User.saveCurrentUser(accountModel);
                view.setAuthResult(accountModel);
                view.endLogin();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.endLogin();
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
