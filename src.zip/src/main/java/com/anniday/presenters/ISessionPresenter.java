package com.anniday.presenters;

/**
 * Created by Administrator on 2015/7/12，21.54.
 * 描述：SessionFragment的presenter
 */
public interface ISessionPresenter {
    /**
     * 刷新
     */
    void refresh();

    /**
     * 加载更多
     */
    void loadMore();

    /**
     * 检测是否有未读消息
     */
    void checkNotReadedSession();


}
