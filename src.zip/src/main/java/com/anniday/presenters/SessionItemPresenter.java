package com.anniday.presenters;


import com.anniday.app.App;
import com.anniday.model.db.User;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.view.ISessionItemView;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by Administrator on 2015/7/13，15.05.
 * 描述：
 */
public class SessionItemPresenter extends BasePresenter<ISessionItemView> implements ISessionItemPresenter {
    @Override
    public void getUser(final String userId) {
        Observable.create(new Observable.OnSubscribe<User>() {
            @Override
            public void call(Subscriber<? super User> subscriber) {
                User user = App.application.daoSession.getUserDao().load(Long.valueOf(userId));
                subscriber.onNext(user);
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe(new Action1<User>() {
            @Override
            public void call(User user) {
                if (view != null) {
                    view.setUser(user);
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
    }

    @Override
    public void deleteUser(final String userId) {
        Observable.create(new Observable.OnSubscribe<User>() {
            @Override
            public void call(Subscriber<? super User> subscriber) {
                App.application.daoSession.getSessionDao().deleteUserSessions(userId);
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribe();
    }
}
