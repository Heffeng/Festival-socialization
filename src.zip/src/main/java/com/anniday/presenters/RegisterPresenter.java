package com.anniday.presenters;

import android.content.Context;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.service.User;
import com.anniday.model.service.ErrorMessage;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.NetworkUtil;
import com.anniday.view.RegisterView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by HuangChun on 2016/3/1.
 * 账号注册presenter层
 */
public class RegisterPresenter extends BasePresenter<RegisterView> {
    private Context context;

    public RegisterPresenter(Context context, RegisterView registerView) {
        this.context = context;
        this.view = registerView;
    }
    public void register(String phoneNum,String password,String nickname){
        view.startRegister();
        Long  createAt = System.currentTimeMillis();
        Map<String,String> params = new HashMap<String,String>();
        params.put("phoneNum",phoneNum);
        params.put("password",password);
        params.put("nickname",nickname);
        params.put("createAt",createAt.toString());
        GsonRequest gsonRequest = new GsonRequest(URLConstant.REGISTER, params, User.class, new Response.Listener<User>() {
            @Override
            public void onResponse(User accountModel) {
                view.setAuthResult(accountModel);
                view.endRegister();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.endRegister();
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
