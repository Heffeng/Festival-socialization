package com.anniday.presenters;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.android.volley.Response;
import com.anniday.app.App;
import com.anniday.constant.URLConstant;
import com.anniday.model.db.Story;
import com.anniday.model.service.AnniDayManager;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.HotAnniDay;
import com.anniday.model.service.User;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.NetworkUtil;
import com.anniday.utils.SharePreferenceUtil;
import com.anniday.view.PublishStoryView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by HuangChun on 2016/3/1.
 * 发表动态presenter层
 */
public class PublishStoryPresenter extends BasePresenter<PublishStoryView> {
    private Context context;

    public PublishStoryPresenter(Context context,PublishStoryView publishStoryView) {
        this.context = context;
        this.view = publishStoryView;
    }
    public void publishStory(String text,String imgUrl,Long annidayId,String anniName,int type){
        view.startPublish();
        Long userId = User.getCurrentUser().getUserId();
        Long createAt = System.currentTimeMillis();
        Map<String,String> params = new HashMap<String,String>();
        params.put("userId",userId.toString());
        params.put("text",text);
        params.put("imgUrl",imgUrl);
        params.put("type",String.valueOf(type));
        if (annidayId!=null) {
            params.put("anniDayId", annidayId.toString());
        }
        if (anniName!=null){
            params.put("anniName",anniName);
        }
        params.put("createAt",createAt.toString());
        GsonRequest gsonRequest = new GsonRequest(URLConstant.PUBLISHSTORY, params, Story.class, new Response.Listener<Story>() {
            @Override
            public void onResponse(Story storyModel) {
                view.setResult(storyModel);
                view.endPublish();
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
                view.endPublish();
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }

    public void getLastlyAnniDay(){
        AnniDayManager.getInstance().getHotAnniDayByName("", 0, 1, new Response.Listener<List<HotAnniDay>>() {
            @Override
            public void onResponse(List<HotAnniDay> hotAnniDays) {
                if (hotAnniDays.size()>0) {
                    view.setAnniDay(hotAnniDays.get(0));
                }
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.showError(msg);
            }
        });
    }

}
