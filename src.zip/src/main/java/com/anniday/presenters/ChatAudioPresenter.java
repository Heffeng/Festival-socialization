package com.anniday.presenters;

import android.text.TextUtils;


import com.anniday.app.App;
import com.anniday.app.GlobalParams;
import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.DownLoadUtil;

import java.io.File;

/**
 * Created by Administrator on 2015/7/14，14.33.
 * 描述：语音聊天presenter层
 */
public class ChatAudioPresenter extends BasePresenter implements IChatAudioPresenter {
    @Override
    public void downAudio(final Session session) {
        if (!TextUtils.isEmpty(session.getAudioPath()) && !new File(session.getAudioPath()).exists() || TextUtils.isEmpty(session.getAudioPath())) {
            if (!TextUtils.isEmpty(session.getAudio())) {
                String path = GlobalParams.APPFIEPATH + "/audio/" + session.getAudio().hashCode() + ".amr";
                DownLoadUtil.getInstance().getFilePath(path, session.getAudio(), new DownLoadUtil.GetFileCallBack() {
                    @Override
                    public void onFinish(String filePath) {
                        session.setAudioPath(filePath);
                        App.application.daoSession.getSessionDao().update(session);
                    }
                });
            }
        }
    }
}
