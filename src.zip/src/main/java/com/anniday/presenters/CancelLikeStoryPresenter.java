package com.anniday.presenters;

import android.content.Context;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.LikeModel;
import com.anniday.model.db.Story;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.User;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.NetworkUtil;
import com.anniday.view.CancelLikeStoryView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by HuangChun on 2016/3/27.
 * 取消赞presenter层
 */
public class CancelLikeStoryPresenter extends BasePresenter<CancelLikeStoryView> {
    private Context context;

    public CancelLikeStoryPresenter(Context context,CancelLikeStoryView cancelLikeStoryView) {
        this.context = context;
        view = cancelLikeStoryView;
    }
    public void cancelLike(final Story story){
        view.startCancelLike();
        Map<String,String> params= new HashMap<String,String>();
        params.put("storyId",String.valueOf(story.getStoryId()));
        params.put("userId", String.valueOf(User.getCurrentUser().getUserId()));
        GsonRequest<LikeModel> gsonRequest = new GsonRequest<LikeModel>(URLConstant.CANCEL_LIKE, params, LikeModel.class, new Response.Listener<LikeModel>() {
            @Override
            public void onResponse(LikeModel likeModel) {
                view.endCancelLike();
                view.setResult(story);
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.endCancelLike();
                view.showError(msg);
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}

