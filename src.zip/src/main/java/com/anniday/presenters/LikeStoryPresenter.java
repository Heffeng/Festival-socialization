package com.anniday.presenters;

import android.content.Context;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.LikeModel;
import com.anniday.model.db.Story;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.User;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.NetworkUtil;
import com.anniday.view.LikeStoryView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by HuangChun on 2016/3/27.
 * 点赞presenter层
 */
public class LikeStoryPresenter extends BasePresenter<LikeStoryView> {
    private Context context;

    public LikeStoryPresenter(Context context,LikeStoryView likeStoryView) {
        view = likeStoryView;
        this.context = context;
    }
    public void like(final Story story){
        view.startLike();
        Map<String,String> params= new HashMap<String,String>();
        params.put("userId",String.valueOf(User.getCurrentUser().getUserId()));
        params.put("storyId", String.valueOf(story.getStoryId()));
        params.put("createAt", String.valueOf(System.currentTimeMillis()));
        GsonRequest<LikeModel> gsonRequest = new GsonRequest<LikeModel>(URLConstant.LIKE, params, LikeModel.class, new Response.Listener<LikeModel>() {
            @Override
            public void onResponse(LikeModel likeModel) {
                view.endLike();
                view.setResult(story);
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                view.endLike();
                view.showError(msg);
            }
        });
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
