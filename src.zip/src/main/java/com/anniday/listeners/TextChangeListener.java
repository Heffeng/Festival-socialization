package com.anniday.listeners;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月5日下午9:07:16
 * <p/>
 * 描述 ：
 * EditText文字变化监听
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class TextChangeListener implements TextWatcher {

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
                                  int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
    }

}
