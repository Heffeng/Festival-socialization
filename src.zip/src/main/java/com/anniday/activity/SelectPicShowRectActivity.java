package com.anniday.activity;

import android.content.Intent;
import android.graphics.Paint;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.GlobalParams;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.BitmapUtil;
import com.anniday.utils.FileUtil;
import com.anniday.widgets.AvaterCut;
import com.anniday.widgets.ImageCut;

import java.io.IOException;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * 选择图片显示的区域
 *
 * @author Administrator
 */
public class SelectPicShowRectActivity extends BaseActivity implements
        OnClickListener {
    public static final String SCALE = "Scale";
    public static final int OK = 1;
    public static final String PICTUREPATH = "picturePath";
    public static final int CANCEL = 2;
    public static final String INTENT_ID = "intent_id";
    public static final int AVATER = 1;
    public static final int IMAGE = 2;
    @Bind(R.id.image_cut_pic_show_select)
     ImageCut ivCut;
    @Bind(R.id.avater_cut_pic_show_select)
     AvaterCut avaterCut;
    
    @Bind(R.id.tv_select_pic_rect_select)
     TextView tvRectSelect;
    
    @Bind(R.id.iv_select_pic_rect_scale)
     ImageView ivScale;

    
    @Bind(R.id.tv_select_pic_rect_cancel)
     TextView tvCancle;
    private String bitmapPath;
    private int intent_id;

    @Override
    protected BasePresenter createP() {
        return null;
    }

    @Override
    protected void initData() {
        tvCancle.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);//下划线
        tvRectSelect.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);//下划线

        Intent intent = getIntent();
        intent_id = intent.getIntExtra(INTENT_ID, 0);
        bitmapPath = getIntent().getStringExtra(PICTUREPATH);
        switch (intent_id) {
            case AVATER:
                ivScale.setVisibility(View.INVISIBLE);
                avaterCut.setVisibility(View.VISIBLE);
                ivCut.setVisibility(View.GONE);
                avaterCut.setBitmapPath(bitmapPath);
                break;
            case IMAGE:
                ivCut.setBitmapPath(bitmapPath);
                break;
        }
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_select_pic_show);
    }

    @OnClick({R.id.tv_select_pic_rect_cancel,R.id.tv_select_pic_rect_select,R.id.iv_select_pic_rect_scale})
    public void onClick(View v) {
        Intent intent = getIntent();
        switch (v.getId()) {
            case R.id.tv_select_pic_rect_select:
                try {
                    switch (intent_id) {
                        case AVATER:
                            String path = GlobalParams.APPFIEPATH + "/pic/" + bitmapPath.hashCode();
                            FileUtil.copyFile(bitmapPath, path);
                            intent.putExtra(SCALE, avaterCut.getScale());
                            intent.putExtra(PICTUREPATH, path);
                            break;
                        case IMAGE:
                            showProgressDialog("正在处理图片");
                            path = GlobalParams.APPFIEPATH + "/pic/" + bitmapPath.hashCode();
                            BitmapUtil.compressBitmap(bitmapPath, path);
                            hideProgressDialog();
                            intent.putExtra(SCALE, ivCut.getScale());
                            intent.putExtra(PICTUREPATH, path);
                            break;
                    }
                    setResult(OK, intent);
                } catch (IOException e) {
                    e.printStackTrace();
                    setResult(CANCEL, intent);
                }
                AppManager.getInstance().finishActivity(this);
                break;
            case R.id.tv_select_pic_rect_cancel:
                setResult(CANCEL, intent);
                AppManager.getInstance().finishActivity(this);
                break;
            case R.id.iv_select_pic_rect_scale:
                ivCut.showAll();
                break;
        }
    }

}
