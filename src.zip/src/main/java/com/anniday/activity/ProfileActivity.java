package com.anniday.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.adapter.MainListAdapter;
import com.anniday.adapter.StoryAdapter;
import com.anniday.model.db.Story;
import com.anniday.model.service.User;
import com.anniday.presenters.ProfilePresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.LogUtil;
import com.anniday.view.IProfileView;
import com.facebook.drawee.view.SimpleDraweeView;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayout;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayoutDirection;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by VeyHey on 2016/4/2.
 */
public class ProfileActivity extends BaseActivity<ProfilePresenter> implements SwipyRefreshLayout.OnRefreshListener,MainListAdapter.CommentListener, IProfileView {
    public static final String USER_ID = "userId";
    @Bind(R.id.lv_profile)
    ListView lvProfile;
    @Bind(R.id.sfl_topic_detail)
    SwipyRefreshLayout sflTopicDetail;
    @Bind(R.id.iv_chat)
    ImageView ivChat;

    private StoryAdapter adapter;
    private ProfileHeader header;
    private User user;
    private long userId;


    @Override
    protected ProfilePresenter createP() {
        userId = getIntent().getLongExtra(USER_ID, -1);
        return new ProfilePresenter(userId);
    }

    @OnClick({R.id.iv_chat})
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.iv_chat:
                Intent intent = new Intent(this, ChatActivity.class);
                intent.putExtra(ChatActivity.USER_ID_IN_LONG,user.getUserId());
                intent.putExtra(ChatActivity.NICK_NAME, user.getNickname());
                startActivity(intent);
                break;
        }
    }

    @Override
    protected void initData() {
        adapter = new StoryAdapter(this, new ArrayList<Story>());
        adapter.setListener(this);
        lvProfile.setAdapter(adapter);
        presenter.requestStories();
        presenter.requsetUser();
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_profile);
    }

    @Override
    public void initView() {
        super.initView();
        View headerView = View.inflate(this, R.layout.profile_hedder, null);
        headerView.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelOffset(R.dimen.profile_header_height)));
        header = new ProfileHeader(headerView);
        sflTopicDetail.setOnRefreshListener(this);
        lvProfile.addHeaderView(headerView);
        if (User.getCurrentUser().getUserId()==userId){
            ivChat.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRefresh(SwipyRefreshLayoutDirection swipyRefreshLayoutDirection) {
        switch (swipyRefreshLayoutDirection) {
            case TOP:
                presenter.requestStories();
                break;
            case BOTTOM:
                presenter.loadMore();
                break;
        }
    }

    @Override
    public void showStorys(List<Story> stories) {
        adapter.changeData(stories);
    }

    @Override
    public void loadComplete() {
        sflTopicDetail.setRefreshing(false);
    }

    @Override
    public void setUser(User user) {
        this.user = user;
        header.setUser(this.user);
    }

    @Override
    public void comment(Long storyId) {
        Intent intent = new Intent(this, CommitActivity.class);
        LogUtil.e(String.valueOf(storyId));
        Bundle bundle = new Bundle();
        bundle.putLong("storyId", storyId);
        intent.putExtra("bundle", bundle);
        startActivity(intent);
    }

    class ProfileHeader {

        @Bind(R.id.sv_avatar)
        SimpleDraweeView svAvatar;
        @Bind(R.id.tv_name_gender)
        TextView tvNameGender;
        @Bind(R.id.tv_resume)
        TextView tvResume;

        @OnClick({R.id.ib_titlebar_back,R.id.sv_avatar})
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.sv_avatar:
                    if (user != null) {
                        Intent  intent = new Intent(ProfileActivity.this, ShowImageActivity.class);
                        intent.putExtra(ShowImageActivity.IMAGE_URL, user.getAvatarUrl());
                        startActivity(intent);
                    }
                    break;
                case R.id.ib_titlebar_back:
                    AppManager.getInstance().finishActivity(ProfileActivity.this);
                    break;
            }
        }

        public void setUser(User user) {
            if (!TextUtils.isEmpty(user.getAvatarUrl())) {
                svAvatar.setImageURI(Uri.parse(user.getAvatarUrl()));
            }
            tvResume.setText(user.getResume());
            if (user.getGender() != null) {
                if (user.getGender()) {
                    tvNameGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.mipmap.male, 0);
                } else {
                    tvNameGender.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.mipmap.female, 0);
                }
            }
            tvNameGender.setText(user.getNickname());
        }

        ProfileHeader(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
