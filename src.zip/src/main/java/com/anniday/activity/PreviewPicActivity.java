package com.anniday.activity;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.widgets.MainActionBar;
import com.facebook.drawee.view.SimpleDraweeView;

import java.io.File;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by Administrator on 2015/8/9，21.06.
 * 描述：预览图片
 */

public class PreviewPicActivity extends BaseActivity {


    public static final String PIC_PATH = "picPath";
    public static final String IS_SEND = "isSend";

    @Bind(R.id.iv_preview_pic)
    SimpleDraweeView ivPreviewPic;
    @Bind(R.id.btn_preview_pic_send)
    Button btnPreviewPicSend;
    private MainActionBar actionBar;

    @Override
    protected BasePresenter createP() {
        return null;
    }

    @Override
    public void initView() {
        super.initView();
        actionBar = new MainActionBar(this);
        actionBar.initActionBarButton();
        actionBar.btnLeft.setVisibility(View.VISIBLE);
        actionBar.btnLeft.setText(R.string.go_back);
    }


    @Override
    protected void initData() {
        Intent intent = getIntent();
        String picPath = intent.getStringExtra(PIC_PATH);
        ivPreviewPic.setImageURI(Uri.fromFile(new File(picPath)));
    }


    @OnClick(value = {R.id.btn_actionbar_left, R.id.btn_preview_pic_send})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_actionbar_left:
                Intent intent = getIntent();
                intent.putExtra(IS_SEND, false);
                setResult(0, intent);
                AppManager.getInstance().finishActivity(this);
                break;
            case R.id.btn_preview_pic_send:
                intent = getIntent();
                intent.putExtra(IS_SEND, true);
                setResult(0, intent);
                AppManager.getInstance().finishActivity(this);
                break;
        }
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_preview_pic);
    }

}
