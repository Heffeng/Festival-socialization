package com.anniday.activity;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.widgets.TitleBar;

import butterknife.Bind;

/**
 * 账号设置页面的实现
 */
public class AccountSettingActivity extends BaseActivity {


    @Bind(R.id.tb_title)
    TitleBar tbTitle;

    @Override
    protected BasePresenter createP() {
        return null;
    }

    @Override
    protected void initData() {
        tbTitle.setOnClickListener(new TitleBar.TitleBarClickListener() {
            @Override
            public void leftClick() {
                finish();
            }

            @Override
            public void rightClick() {

            }
        });
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_account_setting);
    }

}
