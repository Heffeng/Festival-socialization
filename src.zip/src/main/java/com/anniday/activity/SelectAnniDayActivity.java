package com.anniday.activity;

import android.content.Intent;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.adapter.SelectAnniDayAdapter;
import com.anniday.listeners.TextChangeListener;
import com.anniday.model.service.HotAnniDay;
import com.anniday.presenters.SelectAnniDayPresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.SoftInputUtil;
import com.anniday.view.ISelectAnniDayView;
import com.anniday.widgets.xlistview.XListView;

import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;

/**
 * Created by Administrator on 2015/7/24，10.25.
 * 描述：选择节日
 */
public class SelectAnniDayActivity extends BaseActivity<SelectAnniDayPresenter> implements ISelectAnniDayView, TextView.OnEditorActionListener, AdapterView.OnItemClickListener {

    @Bind(R.id.lv_anniday_list)
    public XListView lvLocations;

    @Bind(R.id.et_anniday_search)
    public EditText etSearch;
    @Bind(R.id.tv_create_anniday)
    TextView tvCreateAnniday;

    private SelectAnniDayAdapter adapter;
    private List<HotAnniDay> hotAnniDays;


    @Override
    protected SelectAnniDayPresenter createP() {
        return new SelectAnniDayPresenter();
    }


    protected void setOnClick() {
        etSearch.addTextChangedListener(new TextChangeListener() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                presenter.requestAnniDay(etSearch.getText().toString());
            }
        });
        etSearch.setOnEditorActionListener(this);
        lvLocations.setPullRefreshEnable(false);
        lvLocations.setAutoLoadEnable(true);
        lvLocations.setPullLoadEnable(false);
        lvLocations.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
            }

            @Override
            public void onLoadMore() {
                presenter.loadMoreAnniDay();
            }
        });
        lvLocations.setOnItemClickListener(this);
    }

    @Override
    protected void initData() {
        presenter.requestAnniDay("");
    }

    @Override
    public void initView() {
        super.initView();
        setOnClick();
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_select_anniday);
    }

    @Override
    public void showHotAnniDays(List<HotAnniDay> hotAnniDays) {
        tvCreateAnniday.setVisibility(View.GONE);
        if (adapter == null) {
            adapter = new SelectAnniDayAdapter(hotAnniDays, SelectAnniDayActivity.this);
            lvLocations.setAdapter(adapter);
        } else {
            adapter.changeList(hotAnniDays);
        }
        this.hotAnniDays = hotAnniDays;
    }

    @Override
    public void showNoResult(String s) {
        tvCreateAnniday.setText("未找到该节日，创建节日 : "+s);
        tvCreateAnniday.setVisibility(View.VISIBLE);
    }

    @Override
    public void setLoadMoreEnable(boolean hasMore) {
        lvLocations.setPullLoadEnable(hasMore);
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        presenter.requestAnniDay(etSearch.getText().toString());
        return true;
    }

    @OnClick({R.id.tv_search_anniday_cancel, R.id.tv_search_text_delete,R.id.tv_create_anniday})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_search_text_delete:
                etSearch.setText(null);
                break;
            case R.id.tv_search_anniday_cancel:
                SoftInputUtil.hideSoftInput(this, etSearch);
                AppManager.getInstance().finishActivity(this);
                break;
            case R.id.tv_create_anniday:
                Intent intent = getIntent();
                intent.putExtra(PublishStoryActivity.CREATE_ANNIDAY_TEXT, etSearch.getText().toString().trim());
                setResult(PublishStoryActivity.CREATE_ANNIDAY_CODE, intent);
                AppManager.getInstance().finishActivity(this);
                overridePendingTransition(0, 0);
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = getIntent();
        HotAnniDay anniDay = hotAnniDays.get((int) id);
        intent.putExtra(PublishStoryActivity.SELECT_ANNIDAY, anniDay);
        setResult(PublishStoryActivity.SELECT_ANNIDAY_CODE, intent);
        AppManager.getInstance().finishActivity(this);
        overridePendingTransition(0, 0);
    }
}
