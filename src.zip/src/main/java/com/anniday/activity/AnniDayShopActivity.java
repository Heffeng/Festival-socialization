package com.anniday.activity;

import android.content.Intent;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.widgets.TitleBar;

import butterknife.Bind;

/**
 * Created by VeyHey on 2016/4/26.
 */
public class AnniDayShopActivity extends BaseActivity {
    public static final String ANNIDAY = "ANNIDAY";
    @Bind(R.id.wb_anniday)
    WebView wbAnniday;
    @Bind(R.id.tb_title)
    TitleBar tbTitle;

    @Override
    protected BasePresenter createP() {
        return null;
    }

    @Override
    protected void initData() {
        Intent intent = getIntent();
        String anniday = intent.getStringExtra(ANNIDAY);
        tbTitle.getTitleTv().setText(anniday);
//        wbAnniday.setWebViewClient(new WebViewClient() {
//            @Override
//            public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                LogUtil.e(view.getUrl()+"\n"+url);
//                view.loadUrl(url);
//                return false;
//            }
//        });
        wbAnniday.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        wbAnniday.getSettings().setAllowContentAccess(true);
        wbAnniday.getSettings().setAppCacheEnabled(true);
        wbAnniday.getSettings().setJavaScriptEnabled(true);
        wbAnniday.loadUrl("https://s.m.tmall.com/m/search.htm?q=" + anniday);
    }

    @Override
    public void initView() {
        super.initView();
        tbTitle.setOnClickListener(new TitleBar.TitleBarClickListener() {
            @Override
            public void leftClick() {
                AppManager.getInstance().finishActivity(AnniDayShopActivity.this);
            }

            @Override
            public void rightClick() {
            }
        });
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_anniday_shop);
    }

}

