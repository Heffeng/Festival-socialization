package com.anniday.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.presenters.UserInfoSettingPresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.StatusBarCompat;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by VeyHey on 2016/3/29.
 */
public class UserResumeSettingActivity extends BaseActivity {


    public static final String RESUME = "RESUME";
    @Bind(R.id.et_resume)
    EditText etResume;

    @Override
    protected UserInfoSettingPresenter createP() {
        return new UserInfoSettingPresenter();
    }


    @Override
    protected void initData() {
    }


    @OnClick({R.id.iv_cancel, R.id.iv_ok})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_cancel:
                break;
            case R.id.iv_ok:
                Intent intent = getIntent();
                intent.putExtra(RESUME, etResume.getText().toString());
                setResult(RESULT_OK,intent);
                break;
        }
        AppManager.getInstance().finishActivity(this);
    }


    @Override
    public void setContentView() {
        setContentView(R.layout.activity_user_resume_setting);
    }

    @Override
    protected void initStatusBar() {
        StatusBarCompat.compat(this, 0xFF1E1F23);
    }

}
