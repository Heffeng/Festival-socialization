package com.anniday.activity.base;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;

import com.anniday.R;
import com.anniday.app.App;
import com.anniday.model.service.ErrorMessage;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.CommonUtil;
import com.anniday.utils.DialogUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.NetUtil;
import com.anniday.utils.StatusBarCompat;
import com.anniday.utils.ToastUtil;
import com.anniday.view.base.BaseView;

import butterknife.ButterKnife;


/**
 * ============================================================
 * <p/>
 * 版权 ：Walker
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年4月8日上午10:40:29
 * <p/>
 * 描述 ： 所有的Activity都继承该类
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 */
public abstract class BaseActivity<P extends BasePresenter> extends AppCompatActivity implements BaseView {
    protected P presenter;
    protected ProgressDialog dialog;
    protected BroadcastReceiver netReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean isConnected = NetUtil.checkNet(context);
            onNetStatusChanged(isConnected);
        }
    };

    protected abstract P createP();

    public void showProgressDialog(String message) {
        if (dialog == null) {
            dialog = DialogUtil.showProgressDialog(this);
            dialog.setMessage(message);
        } else {
            dialog.setMessage(message);
            dialog.show();
        }
    }

    public void hideProgressDialog() {
        if (dialog != null) {
            DialogUtil.hideDialog(dialog);
        }
    }

    @Override
    protected void onCreate(android.os.Bundle arg0) {
        super.onCreate(arg0);
        presenter = createP();
        if (presenter != null) {
            presenter.setView(this);
        }
        registerBroadcast();
        setContentView();
        initStatusBar();
        initView();
        AppManager.getInstance().addActivity(this);
        initData();
    }

    protected void initStatusBar() {
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(R.attr.colorPrimaryDark, typedValue, true);
        StatusBarCompat.compat(this, typedValue.data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (presenter != null) presenter.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (presenter != null) presenter.onPause();
    }

    /**
     * 初始化数据
     */
    protected abstract void initData();

    public abstract void setContentView();

    public void initView() {
        ButterKnife.bind(this);
    }

    /**
     * 网络状态改变
     *
     * @param isConnected
     */
    protected void onNetStatusChanged(boolean isConnected) {
    }

    /**
     * 注册网络判断的广播接收者
     */
    private void registerBroadcast() {
        IntentFilter netFilter = new IntentFilter(
                ConnectivityManager.CONNECTIVITY_ACTION);
        netFilter.addCategory(Intent.CATEGORY_DEFAULT);
        registerReceiver(netReceiver, netFilter);
    }

    @Override
    protected void onDestroy() {
        ButterKnife.unbind(this);
        if (presenter != null)
            presenter.onDestroy();
        presenter = null;
        hideProgressDialog();
        super.onDestroy();
        System.gc();
        unregisterReceiver(netReceiver);
        AppManager.getInstance().finishActivity(this);
    }

    /**
     * 跳转
     *
     * @param clazz
     */
    protected void jump(Class<? extends BaseActivity> clazz) {
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(), clazz);
        startActivity(intent);
    }

    /**
     * 在网络通畅的时候执行任务
     *
     * @param task
     */
    public void excuteTaskWhenNetOk(Task task) {
        if (NetUtil.checkNet(getApplicationContext())) {
            if (task != null) {
                task.onExcute();
            }
        } else {
            CommonUtil.showNetError(getApplicationContext());
        }
    }


    @Override
    public void showError(ErrorMessage message) {
        ToastUtil.showCustomToastInRelease(App.application, message.getMessage());
    }

    @Override
    public void showError(String message) {
        ToastUtil.showCustomToastInRelease(App.application, message);
    }

    public interface Task {
        void onExcute();
    }
}
