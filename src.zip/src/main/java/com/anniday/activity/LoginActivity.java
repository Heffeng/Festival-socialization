package com.anniday.activity;

import android.content.Intent;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.model.service.User;
import com.anniday.model.service.ErrorMessage;
import com.anniday.presenters.LoginPresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.LogUtil;
import com.anniday.utils.SharePreferenceUtil;
import com.anniday.utils.ToastUtil;
import com.anniday.view.LoginView;
import com.anniday.widgets.TitleBar;

import java.lang.reflect.Method;

import butterknife.Bind;
import butterknife.OnClick;
import butterknife.OnTextChanged;

/**
 * 账号登陆的实现
 */
public class LoginActivity extends BaseActivity<LoginPresenter> implements LoginView {


    @Bind(R.id.tb_title)
    TitleBar tbTitle;
    @Bind(R.id.edtTxt_phonenum)
    EditText edtTxtPhonenum;
    @Bind(R.id.edtTxt_password)
    EditText edtTxtPassword;
    @Bind(R.id.btn_login)
    Button btnLogin;
    @Bind(R.id.tv_forget_pwd)
    TextView tvForgetPwd;
    @Bind(R.id.tv_register)
    TextView tvRegister;
    private String phoneNum;
    private String password;

    @OnTextChanged({R.id.edtTxt_phonenum, R.id.edtTxt_password})
    public void onTextChanged() {
        phoneNum = edtTxtPhonenum.getText().toString().trim();
        password = edtTxtPassword.getText().toString().trim();
        if(phoneNum.length() == 11&&password.length() >= 6){
            btnLogin.setClickable(true);
            btnLogin.setBackgroundColor(Color.parseColor("#3497db"));
        }else {
            btnLogin.setBackgroundColor(Color.parseColor("#b7b7b7"));
            btnLogin.setClickable(false);
        }
    }

    @Override
    protected LoginPresenter createP() {
        return new LoginPresenter(this, this);
    }


    @Override
    protected void initData() {
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_login);
    }

    @Override
    public void initView() {
        super.initView();
    }


    @Override
    public void startLogin() {
        showProgressDialog("正在登陆");
    }

    @Override
    public void endLogin() {
        hideProgressDialog();
    }

    @Override
    public void setAuthResult(User account) {
        if (account != null) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @OnClick({R.id.btn_login, R.id.tv_forget_pwd, R.id.tv_register})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                presenter.login(phoneNum, password);
                break;
            case R.id.tv_forget_pwd:
                break;
            case R.id.tv_register:
                Intent intent = new Intent(this, RegisterActivity.class);
                startActivity(intent);
                break;
        }
    }
}
