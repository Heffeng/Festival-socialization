package com.anniday.activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.GlobalParams;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.widgets.AudioHelper;
import com.anniday.widgets.BaseRecordNoticeCallback;

import butterknife.Bind;
import butterknife.OnClick;


public class Record4Pic extends BaseActivity  {
    public static final String AUDIO_PATH = "AudioPath";
    public static final String PICTUREPATH = "picturePath";
    public static final int RESULT_OK = 1;
    public static final int RESULT_CANCEL = 2;
    public static final int RESULT_RESELECT = 3;
    @Bind(R.id.iv_record_for_pic_show_pic)
    public ImageView ivPicShow;
    @Bind(R.id.ib_record_for_pic_record)
    public ImageButton ibRecord;

    
    @Bind(R.id.tv_record_for_pic_go_back)
    public TextView tvBack;

   
    @Bind(R.id.tv_record_for_pic_reselect_pic)
    public TextView tvReselect;

    @Override
    protected BasePresenter createP() {
        return null;
    }



    @Override
    protected void initData() {
        ivPicShow.setImageDrawable(Drawable.createFromPath(getIntent()
                .getStringExtra(PICTUREPATH)));
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_record_for_pic);
    }

    @Override
    public void initView() {
        super.initView();
        AudioHelper audioHelper = new AudioHelper(ibRecord,
                new AudioHelper.OnFinishRecordCallback() {

                    @Override
                    public void finish(boolean isOk, String path) {
                        if (isOk) {
                            Intent data = getIntent();
                            data.putExtra(AUDIO_PATH, path);
                            setResult(RESULT_OK, data);
                            Record4Pic.this.finish();
                        }
                    }
                });
        audioHelper.setRecoderNoticeCallback(new BaseRecordNoticeCallback(
                ivPicShow, getApplicationContext()) {
            @Override
            protected void show(PopupWindow popWindow, View parent) {
                popWindow.showAtLocation(parent, Gravity.CENTER_HORIZONTAL
                        | Gravity.TOP, 0, GlobalParams.screenHeight / 4);
            }
        });
    }

    @OnClick({R.id.tv_record_for_pic_go_back,R.id.tv_record_for_pic_reselect_pic})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_record_for_pic_go_back:
                setResult(RESULT_CANCEL, getIntent());
                break;
            case R.id.tv_record_for_pic_reselect_pic:
                setResult(RESULT_RESELECT, getIntent());
                break;
        }
        finish();
    }
}
