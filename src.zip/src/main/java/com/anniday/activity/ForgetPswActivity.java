package com.anniday.activity;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.presenters.base.BasePresenter;

public class ForgetPswActivity extends BaseActivity {


    @Override
    protected BasePresenter createP() {
        return null;
    }


    @Override
    protected void initData() {

    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_forget_psw);
    }
}
