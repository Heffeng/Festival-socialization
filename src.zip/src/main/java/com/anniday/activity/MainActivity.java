package com.anniday.activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.text.TextUtils;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.fragment.MainFragment;
import com.anniday.fragment.MessageFragment;
import com.anniday.fragment.TopicFragment;
import com.anniday.fragment.UserFragment;
import com.anniday.fragment.base.BaseFragment;
import com.anniday.model.leancloud.base.BaseLeanCloud;
import com.anniday.model.leancloud.helper.MessageHelperV2;
import com.anniday.model.service.User;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.SharePreferenceUtil;
import com.anniday.widgets.CustomViewPager;
import com.anniday.widgets.MyRadioButton;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnCheckedChanged;


public class MainActivity extends BaseActivity {


    @Bind(R.id.main_vp)
    CustomViewPager mainVp;
    @Bind(R.id.rb_message)
    MyRadioButton rbSession;

    private UserFragment userFragment;
    private MainFragment mainFragment;
    private TopicFragment topicFragment;
    private MessageFragment messageFragment;
    private List<BaseFragment> fragments;

    @Override
    protected BasePresenter createP() {
        return null;
    }


    @Override
    protected void initData() {
        if (TextUtils.isEmpty(SharePreferenceUtil.getString(App.application, User.CURRENT_USER))){
            startActivity(new Intent(getApplication(),LoginActivity.class));
        }

        if (App.application.daoSession==null){
            App.application.initSession();
        }
        BaseLeanCloud.init(getApplication());
        MessageHelperV2.openImClient();
    }


    @Override
    public void setContentView() {
        setContentView(R.layout.activity_main);
    }

    @OnCheckedChanged({R.id.rb_home, R.id.rb_topic, R.id.rb_add, R.id.rb_message, R.id.rb_user})
    public void onCheckedChanged(CompoundButton view, boolean isChecked) {
        if (isChecked) {
            switch (view.getId()) {
                case R.id.rb_home:
                    mainVp.setCurrentItem(0, false);
                    break;
                case R.id.rb_topic:
                    mainVp.setCurrentItem(1, false);
                    break;
                case R.id.rb_add:
                    Intent intent = new Intent(this, PublishStoryActivity.class);
                    startActivity(intent);
                    break;
                case R.id.rb_message:
                    mainVp.setCurrentItem(2, false);
                    break;
                case R.id.rb_user:
                    mainVp.setCurrentItem(3, false);
                    break;
            }
        }
    }


    @Override
    public void initView() {
        super.initView();
        initFragments();
        mainVp.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }

            @Override
            public int getCount() {
                return fragments.size();
            }
        });
        mainVp.setOffscreenPageLimit(3);
    }

    private void initFragments() {
        fragments = new ArrayList<>();
        mainFragment = new MainFragment();
        topicFragment = new TopicFragment();
        messageFragment = new MessageFragment();
        userFragment = new UserFragment();
        fragments.add(mainFragment);
        fragments.add(topicFragment);
        fragments.add(messageFragment);
        fragments.add(userFragment);
    }


    public void setMessageNotReaded(boolean hasNotReaded) {
        if (hasNotReaded) {
            rbSession.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.rb_session_new_message_bg, 0, 0);
        } else {
            rbSession.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.rb_session_bg, 0, 0);
        }
    }



}
