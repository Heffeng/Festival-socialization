package com.anniday.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.adapter.MainListAdapter;
import com.anniday.adapter.StoryAdapter;
import com.anniday.model.db.Story;
import com.anniday.model.service.Topic;
import com.anniday.presenters.TopicDetailPresenter;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.LogUtil;
import com.anniday.view.ITopicDetailView;
import com.anniday.widgets.TitleBar;
import com.facebook.drawee.view.SimpleDraweeView;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayout;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayoutDirection;

import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

import static com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayoutDirection.*;


/**
 * 主题详情
 * Created by VeyHey on 2016/3/28.
 */
public class AnniDayDetailActivity extends BaseActivity<TopicDetailPresenter> implements SwipyRefreshLayout.OnRefreshListener ,ITopicDetailView,MainListAdapter.CommentListener, View.OnClickListener {

    public static final String TOPIC = "TOPIC";
    @Bind(R.id.tb_title)
    TitleBar tbTitle;
    @Bind(R.id.lv_topic_detail)
    ListView lvTopicDetail;
    @Bind(R.id.sfl_topic_detail)
    SwipyRefreshLayout sflTopicDetail;
    SimpleDraweeView svTopicBackground;
    private Topic topic;
    private StoryAdapter adapter;
    private TextView tvOrigin;

    public static final String anniday_origin = "<a style=\"text-decoration:none;\" href='doyouknow'>你知道吗  </a>DETAIL   <a style=\"text-decoration:none;\" href='detail'>查看详情</a>";
    public static final String anniday_origin_detail = "<a style=\"text-decoration:none;\" href='doyouknow'>你知道吗  </a>DETAIL  <a style=\"text-decoration:none;\" href='close'>收起</a>";


    @Override
    protected TopicDetailPresenter createP() {
        Intent intent = getIntent();
        topic = intent.getParcelableExtra(TOPIC);
        return new TopicDetailPresenter(topic.getAnniDayId()) ;
    }

    @Override
    protected void initData() {
        Intent intent = getIntent();
        topic = intent.getParcelableExtra(TOPIC);
        tbTitle.getTitleTv().setText(topic.getName());
        adapter = new StoryAdapter(this,new ArrayList<Story>());
        adapter.setListener(this);
        lvTopicDetail.setAdapter(adapter);
        if (!TextUtils.isEmpty(topic.getBackgroundUrl())) {
            View headerView = View.inflate(this, R.layout.topic_detail_header_view, null);
            lvTopicDetail.addHeaderView(headerView);
            svTopicBackground = (SimpleDraweeView) headerView.findViewById(R.id.sv_topic_background);
            tvOrigin = (TextView) headerView.findViewById(R.id.tv_origin);
            svTopicBackground.setImageURI(Uri.parse(topic.getBackgroundUrl()));

            if (!TextUtils.isEmpty(topic.getOrigin())){
                final String detail = anniday_origin.replace("DETAIL", topic.getOrigin().substring(0, 30));
                tvOrigin.setVisibility(View.VISIBLE);
                initDetail(detail);
            }
        }
        presenter.requestStories();
    }

    private void initDetail(final String detail) {
        tvOrigin.setText(Html.fromHtml(detail));
        tvOrigin.setMovementMethod(LinkMovementMethod
                .getInstance());
        CharSequence text = tvOrigin.getText();
        int ends = text.length();
        Spannable spannable = (Spannable) tvOrigin.getText();
        URLSpan[] urlspan = spannable.getSpans(0, ends, URLSpan.class);
        SpannableStringBuilder stylesBuilder = new SpannableStringBuilder(text);
        stylesBuilder.clearSpans();

        for (URLSpan url : urlspan) {
            MyURLSpan myURLSpan = new MyURLSpan(url.getURL()) {
                @Override
                public void onClick(View view) {
                    if (this.url.equals("detail")){
                        final String detail = anniday_origin_detail.replace("DETAIL", topic.getOrigin());
                        initDetail(detail);
                    }else if (this.url.equals("close")){
                        final String detail = anniday_origin.replace("DETAIL", topic.getOrigin().substring(0, 30));
                        initDetail(detail);
                    }
                }
            };
            stylesBuilder.setSpan(myURLSpan, spannable.getSpanStart(url),
                    spannable.getSpanEnd(url), spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        tvOrigin.setText(stylesBuilder);
        tvOrigin.setFocusable(false);
        tvOrigin.setClickable(false);
        tvOrigin.setLongClickable(false);
    }


    private abstract class MyURLSpan extends ClickableSpan  {
        protected final String url;

        public MyURLSpan(String url) {
            this.url = url;
        }
        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setUnderlineText(false);
            //给标记的部分 的文字 添加颜色
            ds.setColor(0xff3497D8);
        }
    }
    @Override
    public void setContentView() {
        setContentView(R.layout.activity_anniday_detail);
    }

    @Override
    public void initView() {
        super.initView();
        sflTopicDetail.setOnRefreshListener(this);
        tbTitle.getLeftIv().setOnClickListener(this);
        tbTitle.getRightIv().setOnClickListener(this);
    }

    @Override
    public void onRefresh(SwipyRefreshLayoutDirection swipyRefreshLayoutDirection) {
        switch (swipyRefreshLayoutDirection){
            case TOP:
                presenter.requestStories();
                break;
            case BOTTOM:
                presenter.loadMore();
                break;
        }
    }

    @Override
    public void showStorys(List<Story> stories) {
        adapter.changeData(stories);
    }

    @Override
    public void loadComplete() {
        sflTopicDetail.setRefreshing(false);
    }

    @Override
    public void comment(Long storyId) {
        Intent intent = new Intent(this,CommitActivity.class);
        LogUtil.e(String.valueOf(storyId));
        Bundle bundle = new Bundle();
        bundle.putLong("storyId",storyId);
        intent.putExtra("bundle",bundle);
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imgBtn_left:
                AppManager.getInstance().finishActivity(this);
                break;
            case R.id.imgBtn_right:
                Intent intent = new Intent(this,AnniDayShopActivity.class);
                intent.putExtra(AnniDayShopActivity.ANNIDAY,topic.getName()+"礼物");
                startActivity(intent);
                break;
        }
    }
}
