package com.anniday.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.EditText;
import android.widget.ImageButton;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.adapter.CommentListAdapter;
import com.anniday.model.CommentModel;
import com.anniday.presenters.CreateCommentPresenter;
import com.anniday.presenters.GetCommentPresenter;
import com.anniday.utils.LogUtil;
import com.anniday.utils.SoftInputUtil;
import com.anniday.view.CreateCommentView;
import com.anniday.view.GetCommentView;
import com.anniday.widgets.DividerItemDecoration;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 评论功能的实现
 */
public class CommitActivity extends BaseActivity<GetCommentPresenter> implements GetCommentView,CreateCommentView,CommentListAdapter.ReplyListener {


    @Bind(R.id.rv_commit)
    RecyclerView rvCommit;
    @Bind(R.id.srl_commit)
    SwipyRefreshLayout srlCommit;
    @Bind(R.id.et_commit)
    EditText etCommit;
    @Bind(R.id.imgBtn_commit_sent)
    ImageButton imgBtnCommitSent;

    List<CommentModel> comments = new ArrayList<>();
    private CreateCommentPresenter createCommentPresenter;
    private Long storyId;
    private CommentListAdapter commentListAdapter;

    private Long toUserId;
    private String toUserName;
    private Boolean isReply = false;
    @Override
    protected GetCommentPresenter createP() {
        return new GetCommentPresenter(CommitActivity.this, this);
    }

    @Override
    protected void initData() {
        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("bundle");
        storyId = bundle.getLong("storyId");
        presenter.getComment(20, 1, storyId);
        commentListAdapter = new CommentListAdapter(this,comments,this);

        rvCommit.setAdapter(commentListAdapter);
        rvCommit.setLayoutManager(new LinearLayoutManager(this));
        rvCommit.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST,0));
        createCommentPresenter = new CreateCommentPresenter(CommitActivity.this,this);
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_commit);
    }

    @Override
    public void startGet() {
        LogUtil.e("开始获取");
    }

    @Override
    public void endGet() {
        LogUtil.e("结束获取");

    }

    @Override
    public void setResult(List<CommentModel> arrayList) {
        LogUtil.e("获取成功");
        comments = arrayList;
        commentListAdapter.changeData(comments);
    }


    @OnClick(R.id.imgBtn_commit_sent)
    public void onClick() {
        LogUtil.e( etCommit.getHint().toString().trim());
        String content = etCommit.getText().toString().trim();
        if (!content.isEmpty()){
            if (isReply == false)
                createCommentPresenter.createComment(null,storyId,content);
            else {
                LogUtil.e(toUserName+toUserId);
                createCommentPresenter.createComment(toUserId,storyId,content);
            }
        }
    }

    @Override
    public void startCreate() {
        LogUtil.e("开始发表评论");
    }

    @Override
    public void endCreate() {
        LogUtil.e("结束发表评论");

    }

    @Override
    public void setResult() {
        LogUtil.e("发表成功");
        etCommit.setText("");
        presenter.getComment(20, 1, storyId);
    }

    @Override
    public void Reply(Long toUserId, String toUserName) {
        etCommit.setHint("@:"+toUserName);
        etCommit.setFocusable(true);
        etCommit.setFocusableInTouchMode(true);
        etCommit.requestFocus();
        etCommit.requestFocusFromTouch();
        SoftInputUtil.openSoftInput(this,etCommit);
        this.toUserId = toUserId;
        this.toUserName = toUserName;
        isReply = true;
    }
}
