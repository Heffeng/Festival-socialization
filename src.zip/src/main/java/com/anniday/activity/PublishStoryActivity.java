package com.anniday.activity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.ServiceException;
import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.constant.Constant;
import com.anniday.model.CloudFile;

import com.anniday.model.OSS.OSSManager;
import com.anniday.model.db.Story;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.HotAnniDay;
import com.anniday.model.service.StoryModel;
import com.anniday.presenters.PublishStoryPresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.BitmapUtil;
import com.anniday.utils.FilenameUtil;
import com.anniday.utils.IntentUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.ToastUtil;
import com.anniday.view.PublishStoryView;
import com.anniday.widgets.TitleBar;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 发表动态页面的实现
 */
public class PublishStoryActivity extends BaseActivity<PublishStoryPresenter>
        implements OSSManager.SaveCallback, PublishStoryView {

    public static final int CREATE_ANNIDAY_CODE = 1;
    public static final String CREATE_ANNIDAY_TEXT = "CREATE_ANNIDAY_TEXT";
    public static final int SELECT_ANNIDAY_CODE = 2;
    public static final String SELECT_ANNIDAY = "SELECT_ANNIDAY";
    @Bind(R.id.tb_publish_story)
    TitleBar tbPublishStory;
    @Bind(R.id.et_publish_story)
    EditText etPublishStory;
    @Bind(R.id.iv_publish_img)
    ImageView ivPublishImg;
    @Bind(R.id.ll_add)
    LinearLayout llAdd;
    @Bind(R.id.tv_anniday_name)
    TextView tvAnniDay;
    @Bind(R.id.cb_zongchou)
    CheckBox cbZongchou;
    private String cameraPicPath;
    private static int GET_PICTURE = 1;
    private static int GET_CAREMA = 2;
    private static int GET_ANNIDAY = 3;
    private String picturePath;

    private HotAnniDay anniDay;
    private String anniDayName;

    @Override
    protected PublishStoryPresenter createP() {
        return new PublishStoryPresenter(this, this);
    }

    @Override
    public void initView() {
        super.initView();
        tbPublishStory.setOnClickListener(new TitleBar.TitleBarClickListener() {
            @Override
            public void leftClick() {
                Intent intent = new Intent(PublishStoryActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void rightClick() {
                try {
                    if (picturePath==null){
                        ToastUtil.showCustomToastInRelease(App.application,"请选择一张美图吧!!!");
                        return;
                    }
                    if (anniDay==null&&anniDayName==null){
                        ToastUtil.showCustomToastInRelease(App.application,"请选择一个节日吧!!!");
                        return;
                    }
                    LogUtil.e(picturePath);
                    showProgressDialog("正在努力地发布您的故事，请稍后。。。");
                    OSSManager.uploadFile(FilenameUtil.getDesPathName(picturePath), PublishStoryActivity.this);
                } catch (IOException e) {
                    e.printStackTrace();
                    LogUtil.e(e.toString());
                }
            }
        });
    }

    @Override
    protected void initData() {
        presenter.getLastlyAnniDay();
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_publish_story);
    }


    @OnClick({R.id.ll_add, R.id.iv_publish_img})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_publish_img:
                // 拿照片
                Intent intent_file = IntentUtil.getPicIntent();
                startActivityForResult(intent_file, GET_PICTURE);
                break;
            case R.id.ll_add:
                Intent intent_anniDay = new Intent(this,SelectAnniDayActivity.class);
                startActivityForResult(intent_anniDay,GET_ANNIDAY );
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GET_PICTURE) {
            if (data != null) {
                Uri selectedImage = data.getData();
                String[] filePathColumns = {MediaStore.Images.Media.DATA};
                Cursor c = this.getContentResolver().query(selectedImage, filePathColumns, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePathColumns[0]);
                picturePath = c.getString(columnIndex);
                c.close();
                LogUtil.e(picturePath);
                try {
                    BitmapUtil.compressBitmap(picturePath, FilenameUtil.getDesPathName(picturePath));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                LogUtil.e(FilenameUtil.getDesPathName(picturePath));
                ivPublishImg.setImageURI(Uri.parse(FilenameUtil.getDesPathName(picturePath)));
            }
        }else if (requestCode == GET_ANNIDAY){
            if (data!=null){
                if (resultCode==CREATE_ANNIDAY_CODE){
                    anniDayName = data.getStringExtra(CREATE_ANNIDAY_TEXT);
                    anniDay = null;
                    tvAnniDay.setText(anniDayName);
                }else if (resultCode == SELECT_ANNIDAY_CODE){
                    anniDayName = null;
                    anniDay = data.getParcelableExtra(SELECT_ANNIDAY);
                    tvAnniDay.setText(anniDay.getName());
                }
            }
        }
    }


    @Override
    public void onSuccess(CloudFile cloudFile) {
        int type = cbZongchou.isChecked()?Constant.STORY_ZONGCHOU:Constant.STORY_NORMAL;
        if (anniDay!=null){
            presenter.publishStory(etPublishStory.getText().toString(), cloudFile.getFileUrl(), anniDay.getAnniDayId(), null,type);
        }
        if (anniDayName!=null){
            presenter.publishStory(etPublishStory.getText().toString(), cloudFile.getFileUrl(), null, anniDayName,type);
        }
    }

    @Override
    public void onProgress(String objectKey, long byteCount, long totalSize) {
        LogUtil.e(String.valueOf(byteCount / totalSize));
    }

    @Override
    public void onFailure(ClientException clientExcepion, ServiceException serviceException) {
        ToastUtil.showCustomToastInRelease(App.application,"您的图片没有上传成功，请重试一下吧！！！");
    }

    @Override
    public void startPublish() {
    }

    @Override
    public void endPublish() {
        hideProgressDialog();
    }

    @Override
    public void setResult(Story storyModel) {
        ToastUtil.showCustomToastInRelease(App.application, "您的故事已经成功分享出去了！！！");
        AppManager.getInstance().finishActivity(this);
    }

    @Override
    public void setAnniDay(HotAnniDay hotAnniDay) {
        if (anniDay==null) {
            anniDay = hotAnniDay;
            tvAnniDay.setText(anniDay.getName());
        }
    }


    @Override
    public void showError(ErrorMessage message) {
        super.showError(message);
    }

}
