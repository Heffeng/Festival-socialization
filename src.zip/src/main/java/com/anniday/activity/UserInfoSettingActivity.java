package com.anniday.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.app.GlobalParams;
import com.anniday.model.service.User;
import com.anniday.model.service.UserManager;
import com.anniday.presenters.UserInfoSettingPresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.BeanUtils;
import com.anniday.utils.DialogUtil;
import com.anniday.utils.IntentUtil;
import com.anniday.utils.StatusBarCompat;
import com.anniday.utils.ToastUtil;
import com.anniday.view.IUserInfoSettingView;
import com.anniday.widgets.UserInfoItem;
import com.facebook.drawee.view.SimpleDraweeView;

import java.io.File;
import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;

/**
 * Created by VeyHey on 2016/3/29.
 * 用户信息修改的实现
 */
public class UserInfoSettingActivity extends BaseActivity<UserInfoSettingPresenter> implements IUserInfoSettingView {

    @Bind(R.id.sv_avatar)
    SimpleDraweeView svAvatar;
    @Bind(R.id.uf_name)
    UserInfoItem ufName;
    @Bind(R.id.uf_gender)
    UserInfoItem ufGender;
    @Bind(R.id.uf_resume)
    UserInfoItem ufResume;
    @Bind(R.id.uf_phone_num)
    UserInfoItem ufPhoneNum;


    private int currRequestCode;
    private String cameraPicPath;

    public static final int PIC = 1;
    public static final int CAMERA = 2;
    public static final int SELECT_PIC_RECT = 3;
    public static final int WRITE_RESUME = 4;
    Dialog selectAvater;
    private Dialog selectGender;
    private User user;
    private Dialog selectName;
    private String currentPath;

    @Override
    protected UserInfoSettingPresenter createP() {
        return new UserInfoSettingPresenter();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (user == null) {
            user = new User();
            BeanUtils.copyProperties(User.getCurrentUser(), user);
            ufName.getTvUserInfoItemCenter().setText(user.getNickname());
            if (!TextUtils.isEmpty(user.getAvatarUrl())) {
                svAvatar.setImageURI(Uri.parse(user.getAvatarUrl()));
            }
            if (user.getGender() != null) {
                if (user.getGender()) {
                    ufGender.getTvUserInfoItemCenter().setText("男");
                } else {
                    ufGender.getTvUserInfoItemCenter().setText("女");
                }
            }
            ufPhoneNum.getTvUserInfoItemCenter().setText(user.getPhoneNum());
            ufResume.getTvUserInfoItemCenter().setText(user.getResume());
        }
    }

    @Override
    protected void initData() {

    }


    @OnClick({R.id.iv_cancel, R.id.iv_ok, R.id.rl_avatar, R.id.uf_gender, R.id.uf_name,R.id.uf_resume})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_cancel:
                AppManager.getInstance().finishActivity(this);
                break;
            case R.id.iv_ok:
                presenter.commit(currentPath, user);
                break;
            case R.id.rl_avatar:
                showSelectAvaterDialog();
                break;
            case R.id.uf_gender:
                showSelectGenderDialog();
                break;
            case R.id.uf_name:
                showSelectName();
                break;
            case R.id.uf_resume:
                startActivityForResult(new Intent(getApplicationContext(),UserResumeSettingActivity.class), WRITE_RESUME);
                break;
        }
    }

    private void showSelectName() {
        if (selectName == null) {
            selectName = DialogUtil.showDiaLog(R.layout.dialog_change_nickname, this);
            NameDialog nameDialog = new NameDialog(selectName);
            nameDialog.etDialogChangeUsernameNewUsername.setText(user.getNickname());
        } else {
            selectName.show();
        }
    }

    private void showSelectGenderDialog() {
        if (selectGender == null) {
            selectGender = DialogUtil.showDiaLog(R.layout.dialog_select_gender, this);
            GenderDialog genderDialog = new GenderDialog(selectGender);
            if (user.getGender() != null) {
                if (user.getGender()) {
                    genderDialog.rbNan.setChecked(true);
                } else {
                    genderDialog.rbNv.setChecked(false);
                }
            }
        } else {
            selectGender.show();
        }
    }


    @Override
    public void setContentView() {
        setContentView(R.layout.activity_user_info_setting);
    }

    @Override
    protected void initStatusBar() {
        StatusBarCompat.compat(this, 0xFF1E1F23);
    }


    private void showSelectAvaterDialog() {
        if (selectAvater == null) {
            selectAvater = DialogUtil.showDiaLog(R.layout.dialog_user_setting_select_avater, this);
            AvatarDialog avatarDialog = new AvatarDialog(selectAvater);
        } else {
            selectAvater.show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == WRITE_RESUME){
            if (resultCode == RESULT_OK) {
                user.setResume(data.getStringExtra(UserResumeSettingActivity.RESUME));
                ufResume.getTvUserInfoItemCenter().setText(user.getResume());
            }
        }
        else if (requestCode == SELECT_PIC_RECT) {
            if (resultCode == SelectPicShowRectActivity.OK) {
                final float[] scales = data
                        .getFloatArrayExtra(SelectPicShowRectActivity.SCALE);
                final String currentPicPath = data
                        .getStringExtra(SelectPicShowRectActivity.PICTUREPATH);
                previewAvater(scales, currentPicPath);
            }
        } else {
            String picturePath = null;
            if (requestCode == PIC) {
                if (data == null)
                    return;
                Uri selectedImage = data.getData();
                String[] filePathColumns = {MediaStore.Images.Media.DATA};
                Cursor c = this.getContentResolver().query(selectedImage,
                        filePathColumns, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePathColumns[0]);
                picturePath = c.getString(columnIndex);
                c.close();
            } else if ((requestCode == CAMERA)
                    && (resultCode == Activity.RESULT_OK)) {
                picturePath = cameraPicPath;
            }
            if (picturePath != null) {
                Intent intent = new Intent(getApplicationContext(),
                        SelectPicShowRectActivity.class);
                intent.putExtra(SelectPicShowRectActivity.PICTUREPATH,
                        picturePath);
                intent.putExtra(SelectPicShowRectActivity.INTENT_ID,
                        SelectPicShowRectActivity.AVATER);
                startActivityForResult(intent, SELECT_PIC_RECT);
            }
        }
    }

    private void previewAvater(float[] scales, String currentPicPath) {
        presenter.cutAvatar(scales, currentPicPath);
    }


    @Override
    public void cutAvatarSuccess(String path) {
        currentPath = path;
        svAvatar.setImageURI(Uri.fromFile(new File(path)));
    }

    @Override
    public void editUserSucess() {
        user = null;
        onResume();
    }

    class AvatarDialog {
        @OnClick({R.id.tv_user_setting_dialog_select_avater_pics, R.id.tv_user_setting_dialog_select_avater_camera,
                R.id.tv_user_setting_dialog_select_avater_cancel})
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.tv_user_setting_dialog_select_avater_pics:
                    DialogUtil.hideDialog(selectAvater);
                    // 拿照片
                    Intent intent_file = IntentUtil.getPicIntent();
                    currRequestCode = PIC;
                    startActivityForResult(intent_file, currRequestCode);
                    break;
                case R.id.tv_user_setting_dialog_select_avater_camera:
                    DialogUtil.hideDialog(selectAvater);
                    // 照相
                    Intent intent_camera;
                    try {
                        cameraPicPath = GlobalParams.APPFIEPATH + "/camera/"
                                + System.currentTimeMillis() + ".jpg";
                        intent_camera = IntentUtil.getCameraIntent(cameraPicPath);
                        currRequestCode = CAMERA;
                        startActivityForResult(intent_camera, currRequestCode);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.tv_user_setting_dialog_select_avater_cancel:
                    DialogUtil.hideDialog(selectAvater);
                    break;
            }
        }

        AvatarDialog(Dialog view) {
            ButterKnife.bind(this, view);
        }
    }

    class GenderDialog {
        @Bind(R.id.rb_nan)
        RadioButton rbNan;
        @Bind(R.id.rb_nv)
        RadioButton rbNv;

        @OnClick({R.id.rb_nan, R.id.rb_nv})
        public void onCheckedChanged(View v) {
                switch (v.getId()) {
                    case R.id.rb_nan:
                        user.setGender(true);
                        ufGender.getTvUserInfoItemCenter().setText("男");

                        break;
                    case R.id.rb_nv:
                        user.setGender(false);
                        ufGender.getTvUserInfoItemCenter().setText("女");
                        break;
                }
            selectGender.dismiss();
        }

        GenderDialog(Dialog view) {
            ButterKnife.bind(this, view);
        }
    }

     class NameDialog {

        @Bind(R.id.et_dialog_change_username_new_username)
        EditText etDialogChangeUsernameNewUsername;

         @OnClick({R.id.tv_dialog_change_username_ensure,R.id.tv_dialog_change_username_cancel})
         public void onClick(View v){
             switch (v.getId()){
                 case R.id.tv_dialog_change_username_ensure:
                     user.setNickname(etDialogChangeUsernameNewUsername.getText().toString());
                     ufName.getTvUserInfoItemCenter().setText(user.getNickname());
                     selectName.dismiss();
                     break;
                 case R.id.tv_dialog_change_username_cancel:
                     selectName.dismiss();
                     break;
             }
         }

         NameDialog(Dialog view) {
            ButterKnife.bind(this, view);
        }
    }
}
