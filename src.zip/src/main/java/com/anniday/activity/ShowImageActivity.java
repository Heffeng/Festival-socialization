package com.anniday.activity;

import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.GlobalParams;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.AppManager;
import com.anniday.widgets.CustomImageView;

import butterknife.Bind;
import butterknife.OnClick;
import uk.co.senab.photoview.PhotoViewAttacher;


/**
 * Created by Administrator on 2015/5/6.
 */
public class ShowImageActivity extends BaseActivity implements View.OnClickListener, PhotoViewAttacher.OnViewTapListener {
    public static final String IMAGE_URL = "imageUrl";
    public static final String IMAGE_PATH = "imagePath";
    @Bind(R.id.view_custom_image_view)
    public CustomImageView customImageView;//

    @Bind(R.id.fl_progress_show_pic)
    public RelativeLayout frameLayout;
    private String imageUrl;
    private String imagePath;
    private String path;

    private PhotoViewAttacher attacher;

    @Override
    protected BasePresenter createP() {
        return null;
    }

    /**
     * 初始化数据
     */
    @Override
    protected void initData() {
        attacher = new PhotoViewAttacher(customImageView);
        attacher.setOnViewTapListener(this);
        customImageView.setAttacher(attacher);
        path = GlobalParams.APPFIEPATH + "/" + "saveImage/";
        imagePath = getIntent().getStringExtra(IMAGE_PATH);
        Uri uri = null;
        if (!TextUtils.isEmpty(imagePath)) {
            uri = Uri.parse("file://" + imagePath);
        } else {
            imageUrl = getIntent().getStringExtra(IMAGE_URL);
            if (!TextUtils.isEmpty(imageUrl)) {
                uri = Uri.parse(imageUrl);
            }
        }
        customImageView.setImageUri(uri, new CustomImageView.OnGetBitmapCallback() {
            @Override
            public void onGetBitmap() {
                frameLayout.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void initView() {
        super.initView();
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_show_pic);
    }

    @Override
    protected void onResume() {
        overridePendingTransition(R.anim.shwo_pic_in_bottom, R.anim.anim_none);
        super.onResume();
    }

   @OnClick({R.id.fl_progress_show_pic})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fl_progress_show_pic:
                AppManager.getInstance().finishActivity(this);
                overridePendingTransition(R.anim.anim_none, R.anim.show_image_out_bottom);
                break;
        }
    }


    @Override
    protected void onDestroy() {
        customImageView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onViewTap(View view, float v, float v1) {
        AppManager.getInstance().finishActivity(this);
        overridePendingTransition(R.anim.anim_none, R.anim.show_image_out_bottom);
    }
}
