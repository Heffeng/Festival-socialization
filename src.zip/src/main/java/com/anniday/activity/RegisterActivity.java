package com.anniday.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.User;
import com.anniday.presenters.RegisterPresenter;
import com.anniday.utils.AppManager;
import com.anniday.utils.LogUtil;
import com.anniday.utils.ToastUtil;
import com.anniday.view.RegisterView;
import com.anniday.widgets.TitleBar;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnTextChanged;

/**
 * 注册账号的实现
 */
public class RegisterActivity extends BaseActivity<RegisterPresenter> implements RegisterView {


    @Bind(R.id.edtTxt_phonenum)
    EditText edtTxtPhonenum;
    @Bind(R.id.edtTxt_niackname)
    EditText edtTxtNiackname;
    @Bind(R.id.edtTxt_confirmcode)
    EditText edtTxtConfirmcode;
    @Bind(R.id.btn_get_confirmcode)
    Button btnGetConfirmcode;
    @Bind(R.id.edtTxt_password)
    EditText edtTxtPassword;
    @Bind(R.id.btn_register)
    Button btnRegister;
    @Bind(R.id.tv_has_userid)
    TextView tvHasUserid;
    @Bind(R.id.tb_title)
    TitleBar tbTitle;
    String phoneNum;
    String password;
    String nickname;


    @OnTextChanged({R.id.edtTxt_phonenum,R.id.edtTxt_niackname,R.id.edtTxt_password})
    public void onTextChanged() {
        nickname = edtTxtNiackname.getText().toString().trim();
        phoneNum = edtTxtPhonenum.getText().toString().trim();
        password = edtTxtPassword.getText().toString().trim();
        if(phoneNum.length() == 11&&password.length() >= 6&& !TextUtils.isEmpty(nickname)){
            btnRegister.setClickable(true);
            btnRegister.setBackgroundColor(Color.parseColor("#3497db"));
        }else {
            btnRegister.setBackgroundColor(Color.parseColor("#b7b7b7"));
            btnRegister.setClickable(false);
        }
    }
    @Override
    protected RegisterPresenter createP() {
        return new RegisterPresenter(this, this);
    }

    @Override
    protected void initData() {
        tbTitle.setOnClickListener(new TitleBar.TitleBarClickListener() {
            @Override
            public void leftClick() {
                Intent i = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(i);
                finish();
            }

            @Override
            public void rightClick() {

            }
        });
    }

    @Override
    public void setContentView() {
        setContentView(R.layout.activity_register);
    }

    @Override
    public void startRegister() {
        showProgressDialog("开始注册");
    }

    @Override
    public void endRegister() {
        hideProgressDialog();
    }

    @Override
    public void setAuthResult(User accountModel) {
        LogUtil.e("成功");
        if (accountModel != null) {
            User.saveCurrentUser(accountModel);
            ToastUtil.showCustomToastInDevelop(this, "注册成功");
            startActivity(new Intent(this, MainActivity.class));
            AppManager.getInstance().finishActivity(this);
        }
    }

    @OnClick({R.id.btn_get_confirmcode, R.id.btn_register, R.id.tv_has_userid})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_get_confirmcode:
                break;
            case R.id.btn_register:
                String phonenum = edtTxtPhonenum.getText().toString().trim();
                String nickname = edtTxtNiackname.getText().toString().trim();
                String password = edtTxtPassword.getText().toString().trim();
                presenter.register(phonenum, password, nickname);
                break;
            case R.id.tv_has_userid:
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
        }
    }

    @Override
    public void showError(ErrorMessage message) {
        super.showError(message);
    }

}
