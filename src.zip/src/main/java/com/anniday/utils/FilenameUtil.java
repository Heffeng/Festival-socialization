package com.anniday.utils;

import java.io.File;

/**
 * Created by HuangChun on 2016/3/3.
 */
public class FilenameUtil {
    public static String getFileName(String pathname){
        File file = new File(pathname);
        return file.getName();
    }
    public static String getDesPathName(String pathname){

        int start=pathname.lastIndexOf("/");
        if(start!=-1){
            return pathname.substring(0,start+1)+"anniday/"+pathname.substring(start+1,pathname.length());
        }else{
            return null;
        }
    }
}
