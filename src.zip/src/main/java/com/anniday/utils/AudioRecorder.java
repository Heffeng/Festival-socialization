package com.anniday.utils;

import android.media.MediaRecorder;
import android.media.MediaRecorder.OnInfoListener;
import android.os.Environment;

import java.io.File;
import java.io.IOException;

/**
 * 录音,文件后缀为.amr
 *
 * @author Administrator
 */
public class AudioRecorder implements OnInfoListener {
    private MediaRecorder mediaRecorder;
    private String path;
    private int maxDuration = 60000;
    private OnRecorderFinishListener onRecorderFinishListener;

    public AudioRecorder(String path, int maxDuration) throws Exception {
        if (!path.endsWith(".amr")) {
            throw new Exception("录音文件后缀不是 .amr");
        }
        this.path = path;
        this.maxDuration = maxDuration == 0 ? this.maxDuration : maxDuration;
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setOnInfoListener(this);
    }

    /**
     * 开始
     *
     * @throws IOException
     */
    public void start() throws IOException {
        if (!Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            // 存储空间不可用
            throw new IOException("SD卡不可用");
        }
        File file = new File(getPath());
        File dirFile = file.getParentFile();
        if (!dirFile.exists() && !dirFile.mkdirs()) {
            throw new IOException("无法创建该路径");
        }

        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);// 录音源
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.RAW_AMR);// 输出格式
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);// 编码格式

        mediaRecorder.setOutputFile(getPath());
//		mediaRecorder.setMaxDuration(maxDuration);
        mediaRecorder.prepare();
        mediaRecorder.start();
    }

    public void stop() {
        mediaRecorder.stop();
        mediaRecorder.release();
    }

    /**
     * 获取声音的振幅
     *
     * @return
     */
    public int getAmplitude() {
        if (mediaRecorder != null) {
            return mediaRecorder.getMaxAmplitude();
        }
        return 0;
    }

    /************************************/
    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getMaxDuration() {
        return maxDuration;
    }

    public void setMaxDuration(int maxDuration) {
        this.maxDuration = maxDuration;
    }

    public OnRecorderFinishListener getOnRecorderFinishListener() {
        return onRecorderFinishListener;
    }

    public void setOnRecorderFinishListener(
            OnRecorderFinishListener onRecorderFinishListener) {
        this.onRecorderFinishListener = onRecorderFinishListener;
    }

    @Override
    // 当录音结束时，会调用此方法
    public void onInfo(MediaRecorder mr, int what, int extra) {
        switch (what) {
            case MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED:
                stop();
                if (getOnRecorderFinishListener() != null) {
                    getOnRecorderFinishListener().onFinished();
                }
                break;
        }
    }

    /**
     * 录音结束的监听
     *
     * @author Administrator
     */
    public interface OnRecorderFinishListener {
        /**
         * 回调此方法时，录音已结束
         */
        void onFinished();
    }
}
