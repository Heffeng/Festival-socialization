package com.anniday.utils;

import java.lang.reflect.Field;

/**
 * Created by VeyHey on 2016/3/27.
 */
public class BeanUtils {
    public static void copyProperties(Object src,Object dest){
        Class<?> destClass = dest.getClass();
        Class<?> srcClass = src.getClass();
        for (Field field:destClass.getDeclaredFields()){
            try {
                Field field1 = srcClass.getDeclaredField(field.getName());
                field1.setAccessible(true);
                field.setAccessible(true);
                field.set(dest, field1.get(src));
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }
}
