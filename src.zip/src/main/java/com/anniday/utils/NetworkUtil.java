package com.anniday.utils;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

/**
 * Created by mac on 15/5/13.
 */
public class NetworkUtil {
    private static NetworkUtil instance;

    private RequestQueue mReqQueue;

    private NetworkUtil(){

    }

    public void init(Context context)
    {
        mReqQueue= Volley.newRequestQueue(context);
    }

    public static NetworkUtil getInstance()
    {
        if(instance==null)
        {
            instance=new NetworkUtil();
        }

        return  instance;
    }

    public void addTask(Request req)
    {
        if(mReqQueue!=null)
        {
            mReqQueue.add(req);
        }
    }

    public static String encodingParams(Map<String,String> params)
    {

        if(params==null)
            return  null;

        StringBuilder sb=new StringBuilder();

        for(Map.Entry<String,String> entry:params.entrySet())
        {
            sb.append(entry.getKey());
            sb.append("=");
            sb.append(entry.getValue());
            sb.append("&");
        }

        sb.delete(sb.length()-1,sb.length());

        try {
            return URLEncoder.encode(sb.toString(), "UTF-8");
        }catch (UnsupportedEncodingException e)
        {
            return sb.toString();
        }

    }

    public static boolean isConnect(Context ctx)
    {
        return  true;
    }
}
