package com.anniday.utils;

import android.content.Context;
import android.graphics.Typeface;
import android.widget.TextView;

/**
 * Created by Administrator on 2015/5/25.
 * 字体工具
 */
public class TypeFaceUtil {
    public static Typeface tpface;

    public static void setTypeFace(Context context, TextView textView, String path) {
        /*if (tpface == null) {
            tpface = Typeface.createFromAsset(context.getAssets(), path);
        }
        textView.setTypeface(tpface);*/
    }
}
