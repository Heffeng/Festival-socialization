package com.anniday.utils;

import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

/**
 * 多条后台任务的连续执行
 *
 * @author Administrator
 */
public class TaskUtil {
    private List<Task> tasks = new ArrayList<Task>();
    private int currentTaskPos = 0;

    public TaskUtil next(Task task) {
        if (task != null) {
            tasks.add(task);
        }
        return this;
    }

    public void start() {
        tasks.get(currentTaskPos).execute();
    }

    public abstract class Task extends AsyncTask<Object, Void, Boolean> {

        protected Exception exception;

        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);
            if (result) {
                if (++currentTaskPos < tasks.size()) {
                    tasks.get(currentTaskPos).execute(fillResult());
                }
            }
        }

        protected Object[] fillResult() {
            return null;
        }
    }
}
