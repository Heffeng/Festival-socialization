package com.anniday.utils;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class NetUtil {


    /**
     * 判断网络是否连接
     */
    public static boolean checkNet(Context context) {
        boolean isWIFI = isWIFIConnected(context);

        boolean isMobile = isMOBILEConnected(context);

        //如果都没连接
        return !(!isWIFI && !isMobile);
    }

    /**
     * 判断WIFI是否连接
     *
     * @param context
     * @return
     */
    private static boolean isWIFIConnected(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager
                .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return networkInfo.isConnected();
    }

    /**
     * 判断Mobile是否连接
     *
     * @param context
     * @return
     */
    private static boolean isMOBILEConnected(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager
                .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return networkInfo.isConnected();
    }
}
