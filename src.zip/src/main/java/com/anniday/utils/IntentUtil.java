package com.anniday.utils;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.File;
import java.io.IOException;

/**
 * Intent工具
 *
 * @author Administrator
 */
public class IntentUtil {

    /**
     * 获取照相的Intent
     *
     * @param path
     * @return
     * @throws IOException
     */
    public static Intent getCameraIntent(String path) throws IOException {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // 将图片保存至SDcard，相机返回后直接在SDcard读取图片，这样可以解决获取的图片太小的问题。
        FileUtil.creatFile(path, FileUtil.FILE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(path)));
        return intent;
    }

    /**
     * 获取相册的Intent
     *
     * @return
     */
    public static Intent getPicIntent() {
        return new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    }
}
