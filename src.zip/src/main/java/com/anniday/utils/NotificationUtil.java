package com.anniday.utils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.NotificationCompat.Builder;

import com.anniday.R;


/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月2日下午10:51:25
 * <p/>
 * 描述 ： Notification工具类
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class NotificationUtil {

    private static int mp3ResId = R.raw.notificationsound;
    private static NotificationManager manager;
    private static Builder builder;

    /**
     * 显示通知 并制定启动Service的Action
     *
     * @param context
     * @param iconRes
     * @param titleRes
     * @param contentRes
     * @param action
     * @param notifyId
     */
    public static void showNotificationWithServiceAction(Context context,
                                                         int iconRes, int titleRes, int contentRes, String action, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(context.getText(titleRes));
        builder.setContentText(context.getText(contentRes));
        builder.setSound(Uri.parse("android.resource://"
                + context.getPackageName() + "/" + mp3ResId));

        Intent intent = new Intent(action);
        PendingIntent pendingIntent = PendingIntent.getService(context, 0,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);
        show(notifyId);
    }

    /**
     * 显示通知 并制定启动Service的Intent
     *
     * @param context
     * @param iconRes
     * @param titleRes
     * @param contentRes
     * @param intent
     * @param notifyId
     */
    public static void showNotificationWithServiceIntent(Context context,
                                                         int iconRes, int titleRes, int contentRes, Intent intent, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(context.getText(titleRes));
        builder.setContentText(context.getText(contentRes));
        builder.setSound(Uri.parse("android.resource://"
                + context.getPackageName() + "/" + mp3ResId));
        PendingIntent pendingIntent = PendingIntent.getService(context, 0,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);
        show(notifyId);
    }

    /**
     * 显示通知 并制定启动Service的Intent
     *
     * @param context
     * @param iconRes
     * @param title
     * @param content
     * @param intent
     */
    public static void showNotificationWithServiceIntent(Context context,
                                                         int iconRes, String title, String content, Intent intent, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(title);
        builder.setContentText(content);
        builder.setSound(Uri.parse("android.resource://"
                + context.getPackageName() + "/" + mp3ResId));
        PendingIntent pendingIntent = PendingIntent.getService(context, 0,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);
        show(notifyId);
    }

    /**
     * 显示通知 并制定启动Activity的Intent
     *
     * @param context
     * @param iconRes
     * @param titleRes
     * @param contentRes
     * @param intent
     */
    public static void showNotificationWithActivityIntent(Context context,
                                                          int iconRes, int titleRes, int contentRes, Intent intent, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(context.getText(titleRes));
        builder.setContentText(context.getText(contentRes));
        builder.setSound(Uri.parse("android.resource://"
                + context.getPackageName() + "/" + mp3ResId));
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);
        show(notifyId);
    }

    /**
     * 显示通知 并制定启动Activity的Intent
     *
     * @param context
     * @param iconRes
     * @param title
     * @param content
     * @param intent
     */
    public static void showNotificationWithActivityIntent(Context context,
                                                          int iconRes, String title, String content, Intent intent, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(title);
        builder.setContentText(content);
        builder.setSound(Uri.parse("android.resource://"
                + context.getPackageName() + "/" + mp3ResId));
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(pendingIntent);
        show(notifyId);
    }

    /**
     * 显示进度狂
     *
     * @param context
     * @param iconRes
     * @param titleRes
     * @param contentRes
     * @param max
     * @param progress
     * @param notifyId
     */
    public static void showProgressNotification(Context context, int iconRes,
                                                int titleRes, int contentRes, int max, int progress, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(context.getText(titleRes));
        builder.setContentText(context.getText(contentRes));
        builder.setProgress(max, progress, false);
        show(notifyId);
    }

    /**
     * 显示进度狂
     *
     * @param context
     * @param iconRes
     * @param title
     * @param content
     * @param max
     * @param progress
     */
    public static void showProgressNotification(Context context, int iconRes,
                                                String title, String content, int max, int progress, int notifyId) {
        init(context);
        builder = new Builder(context);
        builder.setSmallIcon(iconRes);
        builder.setContentTitle(title);
        builder.setContentText(content);
        builder.setProgress(max, progress, false);
        show(notifyId);
    }

    /**
     * 显示notification
     *
     * @param notifyId
     */
    private static void show(int notifyId) {
        Notification notification = builder.build();
        notification.flags = Notification.FLAG_AUTO_CANCEL;
        manager.notify(notifyId, notification);
    }

    /**
     * 初始化manager
     *
     * @param context
     */
    private static void init(Context context) {
        if (manager == null) {
            manager = (NotificationManager) context
                    .getSystemService(Context.NOTIFICATION_SERVICE);
            builder = new Builder(context);
        }
    }

    public static void cancleNotify(Context context, int cancelId) {
        init(context);
        manager.cancel(cancelId);
    }

}
