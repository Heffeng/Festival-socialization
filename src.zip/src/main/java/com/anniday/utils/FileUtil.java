package com.anniday.utils;

import android.graphics.Bitmap;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月3日下午7:00:15
 * <p/>
 * 描述 ： 文件存储工具类
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class FileUtil {

    public static final int FILE = 0;
    public static final int PATH = 1;
    private static final String ENCODING = "UTF-8";

    public static String getSDPath() {
        if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            return Environment.getExternalStorageDirectory().getAbsolutePath();
        }
        return null;
    }

    /**
     * 将位图写入内存卡
     *
     * @param file
     * @param bitmap
     * @throws IOException
     */
    public static boolean write2SDCard(File file, Bitmap bitmap)
            throws IOException {
        if (file != null) {
            creatFile(file.getAbsolutePath(), FILE);
            FileOutputStream fStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fStream);
            fStream.flush();
            fStream.close();
            return true;
        }
        return false;
    }

    /**
     * 将byte数组写入SD卡
     *
     * @param file
     * @param datas
     * @return
     * @throws IOException
     */
    public static boolean write2SDCard(File file, byte[] datas)
            throws IOException {
        if (file != null) {
            creatFile(file.getAbsolutePath(), FILE);
            FileOutputStream fStream = new FileOutputStream(file);
            fStream.write(datas);
            fStream.flush();
            fStream.close();
            return true;
        }
        return false;
    }

    /**
     * 创建目录或文件
     *
     * @param name
     * @param type
     * @throws IOException
     */
    public static void creatFile(String name, int type) throws IOException {
        switch (type) {
            case FILE:
                File file = new File(name);
                file.mkdirs();
                file.delete();
                file.createNewFile();
                break;
            case PATH:
                new File(name).mkdirs();
                break;

        }
    }

    /**
     * 判断内存卡是否可用
     *
     * @return
     */
    public static boolean isSDCardAvaliable() {
        return Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);
    }

    public static Properties getProperties(String path) {
        InputStream inputStream = FileUtil.class.getClassLoader()
                .getResourceAsStream(path);
        Properties properties = new Properties();
        try {
            properties.load(new InputStreamReader(inputStream, ENCODING));
            return properties;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void copyFile(String srcPath, String desPath) throws IOException {
        creatFile(desPath, FILE);
        FileOutputStream outputStream = new FileOutputStream(desPath);
        FileInputStream inputStream = new FileInputStream(srcPath);
        byte temp[] = new byte[1024];
        int lenght = inputStream.read(temp);
        while (lenght != -1) {
            outputStream.write(temp);
            lenght = inputStream.read(temp);
        }
        inputStream.close();
        outputStream.close();
    }
}
