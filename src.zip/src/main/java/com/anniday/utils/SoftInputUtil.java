package com.anniday.utils;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

/**
 * 软键盘工具
 *
 * @author Administrator
 */
public class SoftInputUtil {
    /**
     * 隐藏软件盘
     *
     * @param activity
     * @param view
     */
    public static void hideSoftInput(Activity activity, View view) {
        if (activity != null && view != null && view.findFocus() != null) {
            ((InputMethodManager) activity
                    .getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(view.findFocus().getWindowToken(),
                            InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * 打开软键盘
     *
     * @param activity
     * @param view     :要获得输入框的那个View
     */
    public static void openSoftInput(Activity activity, View view) {
        ((InputMethodManager) activity
                .getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(
                view, InputMethodManager.SHOW_IMPLICIT);
    }
}
