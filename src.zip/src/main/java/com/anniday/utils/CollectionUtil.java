package com.anniday.utils;

import java.util.Collection;

/**
 * Created by Administrator on 2015/9/12.
 */
public class CollectionUtil {
    public static boolean isCollectionEmpty(Collection collection) {
        if (collection == null || collection != null && collection.size() == 0) {
            return true;
        }
        return false;
    }

    public static boolean isCollectionNull(Collection collection) {
        if (collection == null) {
            return true;
        }
        return false;
    }
}
