package com.anniday.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月2日下午9:14:34
 * <p/>
 * 描述 ：SharePreference工具
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class SharePreferenceUtil {

    private static final String NAME = "config";
    private static SharedPreferences preferences;
    private static Editor editor;

    /**
     * 存放int
     *
     * @param context
     * @param key
     * @param value
     */
    public static void saveInt(Context context, String key, int value) {
        init(context);
        if (!TextUtils.isEmpty(key)) {
            editor.putInt(key, value);
            editor.commit();
        }
    }

    public static int getInt(Context context, String key) {
        init(context);
        if (!TextUtils.isEmpty(key)) {
            return preferences.getInt(key, 0);
        }
        return 0;
    }

    /**
     * 存放string share
     *
     * @param key
     * @param value
     */
    public static void saveString(Context context, String key, String value) {
        init(context);
        if (!TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
            editor.putString(key, value);
            editor.commit();
        }
    }

    /**
     * 从sharepreference中获取字符串信息
     *
     * @param context
     * @param key
     * @return
     */
    public static String getString(Context context, String key) {
        init(context);
        if (!TextUtils.isEmpty(key)) {
            return preferences.getString(key, null);
        }
        return null;
    }

    /**
     * 获取Long
     *
     * @param context
     * @param key
     * @return
     */
    public static long getLong(Context context, String key) {
        init(context);
        if (!TextUtils.isEmpty(key)) {
            return preferences.getLong(key, 0);
        }
        return 0;
    }

    public static void saveLong(Context context, String key, long value) {
        init(context);
        if (!TextUtils.isEmpty(key)) {
            editor.putLong(key, value);
            editor.commit();
        }
    }

    /**
     * 清除sharepre中所有的数据
     *
     * @param context
     */
    public static void clearAll(Context context) {
        init(context);
        editor.clear();
        editor.commit();
    }

    /**
     * 清除key所对应的数据
     *
     * @param context
     * @param key
     */
    public static void clear(Context context, String key) {
        init(context);
        editor.remove(key);
        editor.commit();
    }

    /**
     * 初始化Sharepre
     *
     * @param context
     */
    public static void init(Context context) {
        if (preferences == null) {
            preferences = context.getSharedPreferences(NAME,
                    Context.MODE_PRIVATE);
            editor = preferences.edit();
        }
    }
}
