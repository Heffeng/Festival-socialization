package com.anniday.utils;

import android.os.Environment;
import android.util.Log;

import com.anniday.app.ConsTants;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年1月31日下午12:38:39
 * <p/>
 * 描述 ： 日志打印工具类
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class LogUtil {

    /**
     * 开发阶段
     */
    public static final int DEVELOP = 0;

    /**
     * 内部测试阶段
     */
    public static final int DEBUG = 1;

    /**
     * 公开测试
     */
    public static final int BATE = 2;

    /**
     * 正式版
     */
    public static final int RELEASE = 3;

    /**
     * 当前阶段
     */
    public static int currentState = DEVELOP;

    /**
     * 是否在尾部加入
     */
    public static boolean isAppend = true;

    public static OutputStreamWriter writer;

    static {
        try {
            if (Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                String path = Environment.getExternalStorageDirectory()
                        .getAbsolutePath();
                path = path + "/" + ConsTants.APP_NAME;
                File file = new File(path);
                if (file != null) {
                    if (!file.exists()) {
                        file.mkdirs();
                    }
                    path = path + "/" + DateFormatUtil.getDay() + ".txt";
                    file = new File(path);
                    if (file != null) {
                        if (!file.exists())
                            file.createNewFile();
                        writer = new OutputStreamWriter(new FileOutputStream(
                                file, isAppend), ConsTants.ENCODING);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 自动生成TAG
     *
     * @param caller
     * @return
     */
    private static String generateTag(StackTraceElement caller) {
        String tag = "%s.%s(L:%d)";
        String callerClazzName = caller.getClassName();
        callerClazzName = callerClazzName.substring(callerClazzName
                .lastIndexOf(".") + 1);
        tag = String.format(tag, callerClazzName, caller.getMethodName(),
                caller.getLineNumber());
        // tag = TextUtils.isEmpty(customTagPrefix) ? tag : customTagPrefix +
        // ":" + tag;
        return tag;
    }

    /**
     * 获取当前调用者跟踪器
     *
     * @return
     */
    public static StackTraceElement getCallerStackTraceElement() {
        return Thread.currentThread().getStackTrace()[4];
    }

    /**
     * 习惯打印红色的信息
     *
     * @param msg
     */
    public static void e(String msg) {
        switch (currentState) {
            case DEVELOP:
                // 控制台输出
                // 获取到调用者
                StackTraceElement caller = getCallerStackTraceElement();
                Log.e(generateTag(caller), msg);
                break;
            case DEBUG:
            case BATE:
                // 写到SD卡
                log2SD(msg);
                break;
            case RELEASE:
                break;
        }
    }

    /**
     * 专门写到SD
     *
     * @param msg
     */
    public static void log2SD(String msg) {
        // 写到SD卡
        StackTraceElement caller = getCallerStackTraceElement();
        if (writer != null) {
            try {
                writer.write(DateFormatUtil.getCNTime() + "\n\r"
                        + generateTag(caller) + "\n\r" + msg + "\n\r");
                writer.flush();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
}
