package com.anniday.utils;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年1月31日下午1:40:00
 * <p/>
 * 描述 ：时间格式化等工具
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 */
public class DateFormatUtil {

    public static final int SECONDS_OF_ONE_DAY = 3600 * 24;
    public static final int SECONDS_OF_ONE_HOUR = 3600;
    public static final int SECONDS_OF_ONE_MINUTE = 60;

    /**
     * 获取当前时间戳
     *
     * @return
     */
    public static long getCurrentTimeInMills() {
        return System.currentTimeMillis();
    }

    public static String getCNTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        return dateFormat.format(new Date());
    }

    public static String getTime(String patter, long time) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(patter);
        return dateFormat.format(new Date(time));
    }

    public static String getDay() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");
        return dateFormat.format(new Date());
    }

    public static int getDayOfYear(long time) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(time));
        return calendar.get(Calendar.DAY_OF_YEAR);
    }

    public static int getDayOfYear() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.DAY_OF_YEAR);
    }

    public static String getShowTime(long createTime, Context context) {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yy-M-d HH:mm");
//        return dateFormat.format(createTime);
        String result = "";
        long tiemoff = (DateFormatUtil.getCurrentTimeInMills() - createTime) / 1000;
        int publishDay = DateFormatUtil.getDayOfYear(createTime);
        int currentDay = DateFormatUtil.getDayOfYear();
        if (publishDay == currentDay) {
            if (tiemoff < SECONDS_OF_ONE_MINUTE) {
                result = "刚刚";
            } else if (tiemoff < SECONDS_OF_ONE_HOUR) {
                result = tiemoff / SECONDS_OF_ONE_MINUTE + "分钟前";
            } else if (tiemoff < SECONDS_OF_ONE_DAY) {
                result = tiemoff / SECONDS_OF_ONE_HOUR
                        + "小时前";
            }
        } else if (currentDay - publishDay < 7) {
            result = currentDay - publishDay + "天前";
        } else if (currentDay - publishDay < 14) {
            result = (currentDay - publishDay) / 7 + "周前";
        } else {
            result = DateFormatUtil.getTime("yy-M-d HH:MM", createTime);
        }
        return result;
    }

    public static String getShowTimeWithHmInTodayOrMdBeforeToday(long time, Context context) {
        String result = "";
        int publishDay = DateFormatUtil.getDayOfYear(time);
        int currentDay = DateFormatUtil.getDayOfYear();
        if (publishDay == currentDay) {
            result = DateFormatUtil.getTime("HH:mm", time);
        } else {
            result = DateFormatUtil.getTime("yy-M-d", time);
        }
        return result;
    }
}
