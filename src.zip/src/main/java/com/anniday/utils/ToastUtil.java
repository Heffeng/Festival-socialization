package com.anniday.utils;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.anniday.R;


/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月2日下午5:51:58
 * <p/>
 * 描述 ：显示土司的工具
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class ToastUtil {

    /**
     * 开发的时候显示的土司
     *
     * @param context
     * @param text
     */
    public static void showCustomToastInDevelop(Context context, String text) {

        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
    }

    /**
     * 开发的时候显示的土司
     *
     * @param context
     * @param resID
     */
    public static void showCustomToastInDevelop(Context context, int resId) {
        Toast toast = new Toast(context);
        View view = View.inflate(context, R.layout.custom_toast, null);
        ((TextView) view.findViewById(R.id.tv_custom_toast)).setText(resId);
        toast.setView(view);
        toast.show();
    }

    /**
     * 发步的时候显示的土司
     *
     * @param <T>
     * @param context
     * @param text
     */
    public static void showCustomToastInRelease(Context context, String text) {
        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
    }

    /**
     * 发步的时候显示的土司
     *
     * @param context
     * @param resID
     */
    public static void showCustomToastInRelease(Context context, int resId) {
        Toast toast = new Toast(context);
        View view = View.inflate(context, R.layout.custom_toast, null);
        ((TextView) view.findViewById(R.id.tv_custom_toast)).setText(resId);
        toast.setView(view);
        toast.show();
    }
}
