package com.anniday.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {
    public static String MD5(String password) throws NoSuchAlgorithmException {
        // 得到一个信息摘要器
        MessageDigest digest = MessageDigest.getInstance("md5");
        byte[] result = digest.digest(password.getBytes());

        StringBuffer buffer = new StringBuffer();
        // 把每一个byte做一个与运算0xxf
        for (byte b : result) {
            int num = b & 0xff;
            String str = Integer.toHexString(num);
            if (str.length() == 1) {
                buffer.append(0);
            }
            buffer.append(str);
        }
        // System.out.println(buffer.toString());
        return buffer.toString();
    }
}
