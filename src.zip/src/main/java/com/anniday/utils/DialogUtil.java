package com.anniday.utils;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;

import com.anniday.R;


public class DialogUtil {
    public static ProgressDialog showProgressDialog(Context context) {
        ProgressDialog dialog = new ProgressDialog(context);
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.show();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public static void hideDialog(Dialog dialog) {
        dialog.dismiss();
    }

    /**
     * 显示相应Layout的对话框
     *
     * @param resId
     * @param context
     * @return
     */
    public static Dialog showDiaLog(int resId, Context context) {
        Dialog dialog = new Dialog(context, R.style.DialogStyle);
        View view = View.inflate(context, resId, null);
        dialog.setContentView(view);
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.show();
        return dialog;
    }
}
