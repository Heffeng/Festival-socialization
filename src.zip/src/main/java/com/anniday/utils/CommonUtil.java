package com.anniday.utils;

import android.app.ActivityManager;
import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

/**
 * ============================================================
 * <p/>
 * 版权 ：
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月2日下午3:20:51
 * <p/>
 * 描述 ：公共的工具类
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class CommonUtil {
    /**
     * 通过输入流获取字符串信息
     *
     * @param in      输入流
     * @param charset 字符集
     * @return 如果 字符集不支持 或者  输入流为空 返回null
     */
    public static String inputStream2String(InputStream in, String charset) {
        if (in == null) {
            return null;
        }
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    in, charset));
            String str;
            StringBuilder stringBuilder = new StringBuilder();
            while ((str = reader.readLine()) != null) {
                stringBuilder.append(str);
            }
            return stringBuilder.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void showSDcardError(Context context) {
        ToastUtil.showCustomToastInDevelop(context, "SD卡损坏或不存在");
    }

    public static void showNetError(Context context) {
        ToastUtil.showCustomToastInDevelop(context, "网络错误");
    }

    public static void showRequestDataError(Context context) {
        ToastUtil.showCustomToastInDevelop(context, "请求数据异常");
    }

    /**
     * 复制到剪切板
     *
     * @param context
     * @param text
     */
    public static void copyTextToClipBoard(Context context, CharSequence text) {
        if (android.os.Build.VERSION.SDK_INT > 11) {
            android.content.ClipboardManager c = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            c.setText(text);
        } else {
            android.text.ClipboardManager c = (android.text.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            c.setText(text);
        }
    }

    /**
     * 获取剪切板的内容
     *
     * @param context
     * @return
     */
    public static String paste(Context context) {
        if (android.os.Build.VERSION.SDK_INT > 11) {
            android.content.ClipboardManager c = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            return c.getText().toString();
        } else {
            android.text.ClipboardManager c = (android.text.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            return c.getText().toString();
        }
    }


    public static boolean isAppInFornt(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> appTask = am.getRunningTasks(1);
        if (appTask != null)
            if (appTask.size() > 0)
                if (appTask.get(0).topActivity.toString().contains(packageName))
                    return true;
        return false;
    }

    public static String getTopActivityClassName(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> appTask = am.getRunningTasks(1);
        if (appTask != null)
            if (appTask.size() > 0)
                return appTask.get(0).topActivity.getClassName();
        return null;
    }

    public static Map<String,String> object2Map(Object object) {
        Gson gson = new Gson();
        String json = gson.toJson(object);
        Map<String,String> map = gson.fromJson(json, new TypeToken<Map<String, String>>() {
        }.getType());
        return map;
    }
}
