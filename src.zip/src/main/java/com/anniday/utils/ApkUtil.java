package com.anniday.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

import java.io.File;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年2月3日下午4:32:37
 * <p/>
 * 描述 ：Apk管理工具类 有安装apk方法
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 **/
public class ApkUtil {
    /**
     * 安装
     *
     * @param context
     * @param fileName
     */
    public static void install(Context context, String fileName) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(fileName)),
                "application/vnd.android.package-archive");
        context.startActivity(intent);
    }

    /**
     * 获取安装apk的意图
     *
     * @param context
     * @param fileName
     * @return
     */
    public static Intent getInstallIntent(Context context, String fileName) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(fileName)),
                "application/vnd.android.package-archive");
        return intent;
    }

    /**
     * 获取安装包的相关信息（版本号）
     *
     * @param context
     * @param apkPath
     * @return
     */
    public static String getApkVersion(Context context, String apkPath) {
        PackageManager pm = context.getPackageManager();
        PackageInfo info = pm.getPackageArchiveInfo(apkPath,
                PackageManager.GET_ACTIVITIES);
        if (info != null) {
            // ApplicationInfo appInfo = info.applicationInfo;
            // String appName = pm.getApplicationLabel(appInfo).toString();
            // String packageName = appInfo.packageName; //得到安装包名称
            String version = info.versionName; // 得到版本信息
            return version;
        }
        return null;

    }
}
