package com.anniday.utils;

import android.app.Activity;

import java.util.Iterator;
import java.util.Stack;

/**
 * ============================================================
 * <p/>
 * 版权 ：逗同学
 * <p/>
 * 作者：韩炜伟
 * <p/>
 * 版本 ：1.0
 * <p/>
 * 创建日期 ： 2015年1月31日下午2:49:52
 * <p/>
 * 描述 ：app的管理者，负责管理Activity的销毁和程序的退出
 * <p/>
 * <p/>
 * 修订历史 ：
 * <p/>
 * ============================================================
 */
public class AppManager {
    private static AppManager appManager = new AppManager();
    private Stack<Activity> activityStack;

    // 单例模式
    private AppManager() {
        activityStack = new Stack<Activity>();
    }

    public static AppManager getInstance() {
        return appManager;
    }

    /**
     * 将activity加入栈中
     *
     * @param activity
     */
    public void addActivity(Activity activity) {
        if (activity != null) {
            activityStack.add(activity);
        }
    }

    /**
     * 杀死Activity
     *
     * @param activity
     */
    public void finishActivity(Activity activity) {
        if (activity != null) {
            activityStack.remove(activity);
            activity.finish();
            activity = null;
        }
    }

    public void finishAllActivity() {
        Iterator<Activity> iterator = activityStack.iterator();
        while (iterator.hasNext()) {
            Activity activity = iterator.next();
            activity.finish();
            iterator.remove();
            activity = null;
        }
    }

    public void AppExit() {
        finishAllActivity();
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }

}
