package com.anniday.widgets;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.utils.DensityUtil;
import com.anniday.utils.ToastUtil;


public abstract class BaseRecordNoticeCallback implements AudioHelper.RecoderNoticeCallback {
    /**
     * 上滑提示
     */
    protected PopupWindow upNotice;
    protected PopupWindow canelNotice;
    protected PopupWindow timeNotice;
    protected TextView tvTime;
    private View parent;
    private Context context;

    public BaseRecordNoticeCallback(View parent, Context context) {
        super();
        this.parent = parent;
        this.context = context;
    }

    @Override
    public void update(int voice, boolean isShowCancel) {
        if (isShowCancel) {
            return;
        }
        if (timeNotice == null) {
            tvTime = new TextView(context);
            tvTime.setBackgroundResource(R.mipmap.time_remain_notice);
            tvTime.setTextColor(context.getResources().getColor(
                    R.color.white));
            tvTime.setGravity(Gravity.CENTER);
            int padding = DensityUtil.dip2px(context, 10);
            tvTime.setPadding(padding, padding, padding, padding);
            tvTime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 100);
            timeNotice = new PopupWindow(tvTime,
                    LayoutParams.WRAP_CONTENT,
                    LayoutParams.WRAP_CONTENT);
        }
        if (!timeNotice.isShowing()) {
            show(timeNotice, parent);
        }
        if (upNotice != null) {
            upNotice.dismiss();
        }
        if (canelNotice != null) {
            canelNotice.dismiss();
        }
        tvTime.setText(voice + "");
    }

    protected abstract void show(PopupWindow popWindow, View parent);

    @Override
    public void showWarnToast() {
        ToastUtil.showCustomToastInRelease(context,
                R.string.recoder_time_too_short);
    }

    @Override
    public void showVoiceDialog(int flag) {
        switch (flag) {
            case AudioHelper.RecoderNoticeCallback.SHOW_VOICE:
                if (canelNotice != null) {
                    canelNotice.dismiss();
                }
                if (upNotice == null) {
                    ImageView contentView = new ImageView(context);
                    contentView.setImageResource(R.mipmap.slip_up_tips);
                    upNotice = new PopupWindow(contentView,
                            LayoutParams.WRAP_CONTENT,
                            LayoutParams.WRAP_CONTENT);
                }
                show(upNotice, parent);
                break;
            case AudioHelper.RecoderNoticeCallback.SHOW_CANCEL:
                if (upNotice != null) {
                    upNotice.dismiss();
                }
                if (timeNotice != null) {
                    timeNotice.dismiss();
                }
                if (canelNotice == null) {
                    ImageView contentView = new ImageView(context);
                    contentView
                            .setImageResource(R.mipmap.cancel_audio_tips);
                    canelNotice = new PopupWindow(contentView,
                            LayoutParams.WRAP_CONTENT,
                            LayoutParams.WRAP_CONTENT);
                }
                show(canelNotice, parent);
                break;
        }
    }

    @Override
    public void finishShowVoiceDialog() {
        if (upNotice != null) {
            upNotice.dismiss();
        }
        if (canelNotice != null) {
            canelNotice.dismiss();
        }
        if (timeNotice != null) {
            timeNotice.dismiss();
        }
    }

}
