package com.anniday.widgets;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.listeners.TextChangeListener;
import com.anniday.utils.SoftInputUtil;

import butterknife.Bind;
import butterknife.ButterKnife;


public class InputBox extends LinearLayout implements OnClickListener {

    /**
     * 发送文字的按钮，输入框有文字时显示,无文字时显示
     */
    
    @Bind(R.id.tv_chat_send)
    public TextView tvSend;



    /**
     * 文字输入框
     */

    @Bind(R.id.et_chat_info)
    public EditText etChatInfo;
    /**
     * 按住 说话按钮
     */
    
    @Bind(R.id.btn_chat_press_audio)
    public Button btnPressAudio;
    /**
     * 添加图片按钮
     */
    @Bind(R.id.ib_image_add_select)
    public ImageButton ibAddImage;



    /**
     * 添加语音按钮
     */
//    @Bind(R.id.ib_voice_add_select)
//    public ImageButton ibAddVoice;
    @Bind(R.id.tv_voice_add_select)
    public TextView tvAddVoice;
    /**
     * 添加文字按钮
     */
//    @Bind(R.id.ib_soft_key_select)
//    public ImageButton ibSoftKey;
    @Bind(R.id.tv_soft_key_select)
    public TextView tvSoftKey;
    /**
     * 下面隐藏的布局
     */
    @Bind(R.id.ll_image_voice_hide)
    public LinearLayout llImgVocHide;
    /**
     * 语音表情
     */
    
    @Bind(R.id.tv_image_voice_select)
    public TextView tvImgVoc;
    /**
     * 图片
     */
    
    @Bind(R.id.tv_pic_select)
    public TextView tvPic;
    /**
     * 相机
     */
    
    @Bind(R.id.tv_camera_select)
    public TextView tvCamera;
    private View view;
    private boolean isAudioEnable = true;
    private Activity activity;

    public InputBox(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);

    }

    public InputBox(Context context) {
        super(context);
        init(context);
    }

    public InputBox(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public void initWigt() {
        tvSend.setVisibility(GONE);
        etChatInfo.setVisibility(GONE);
        btnPressAudio.setVisibility(GONE);
//        ibAddVoice.setVisibility(GONE);
//        ibSoftKey.setVisibility(GONE);
        tvAddVoice.setVisibility(GONE);
        tvSoftKey.setVisibility(GONE);
        llImgVocHide.setVisibility(GONE);
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    private void init(Context context) {
        view = View.inflate(context, R.layout.view_input_box, this);
        ButterKnife.bind(this,view);
        // 为输入框添加监听
        etChatInfo.addTextChangedListener(new TextChangeListener() {

            @Override
            public void afterTextChanged(Editable s) {
                // 当输入框有文字时，将按钮的文字换为"发送"
                initWigt();
                if (TextUtils.isEmpty(s)) {
                    if (isAudioEnable) {
//                        ibAddVoice.setVisibility(VISIBLE);
                        tvAddVoice.setVisibility(VISIBLE);
                    } else {
                        tvSend.setTextColor(activity.getResources().getColor(R.color.text_gray));
                        tvSend.setVisibility(VISIBLE);
                    }
                } else {
                    tvSend.setVisibility(VISIBLE);
                    tvSend.setTextColor(activity.getResources().getColor(R.color.common_blue));
                }
                etChatInfo.setVisibility(VISIBLE);
                etChatInfo.requestFocus();
                SoftInputUtil.openSoftInput(activity, etChatInfo);
            }
        });
//        ibAddVoice.setOnClickListener(this);
//        ibSoftKey.setOnClickListener(this);
        tvAddVoice.setOnClickListener(this);
        tvSoftKey.setOnClickListener(this);
        ibAddImage.setOnClickListener(this);
        etChatInfo.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.et_chat_info:
                llImgVocHide.setVisibility(GONE);
                break;
            case R.id.ib_image_add_select:
                SoftInputUtil.hideSoftInput(activity, this);
                if (llImgVocHide.getVisibility() == VISIBLE) {
                    llImgVocHide.setVisibility(GONE);
                    SoftInputUtil.openSoftInput(activity, etChatInfo);
                } else {
                    llImgVocHide.setVisibility(VISIBLE);
                }
                break;
            case R.id.tv_voice_add_select:
                // 语音按钮被点击，显示软键盘按钮，显示btnPressAudio
                SoftInputUtil.hideSoftInput(activity, this);
                initWigt();
                btnPressAudio.setVisibility(VISIBLE);
                tvSoftKey.setVisibility(VISIBLE);
                break;
            case R.id.tv_soft_key_select:
                // 软键盘按钮被点击，显示语音按钮，显示输入框
                initWigt();
                etChatInfo.setVisibility(VISIBLE);
                tvAddVoice.setVisibility(VISIBLE);
                // 请求获取焦点
                etChatInfo.requestFocus();
                SoftInputUtil.openSoftInput(activity, etChatInfo);
                break;
//            case R.id.ib_soft_key_select:
//                // 软键盘按钮被点击，显示语音按钮，显示输入框
//                initWigt();
//                etChatInfo.setVisibility(VISIBLE);
//                ibAddVoice.setVisibility(VISIBLE);
//                // 请求获取焦点
//                etChatInfo.requestFocus();
//                SoftInputUtil.openSoftInput(activity, etChatInfo);
//                break;
//            case R.id.ib_voice_add_select:
//                // 语音按钮被点击，显示软键盘按钮，显示btnPressAudio
//                SoftInputUtil.hideSoftInput(activity, this);
//                initWigt();
//                btnPressAudio.setVisibility(VISIBLE);
//                ibSoftKey.setVisibility(VISIBLE);
//                break;
            default:
                break;
        }
    }


    /**
     * 清空输入框
     */
    public void clearInputBox() {
        etChatInfo.setText("");
    }

    public void setIsAudioEnable(boolean isAudioEnable) {
        this.isAudioEnable = isAudioEnable;
        if (!isAudioEnable) {
            btnPressAudio.setVisibility(View.GONE);
            etChatInfo.setVisibility(View.VISIBLE);
//            ibSoftKey.setVisibility(View.GONE);
            tvAddVoice.setVisibility(GONE);
            tvSend.setVisibility(View.VISIBLE);
        }
    }
}
