package com.anniday.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anniday.R;


/**
 * Created by VeyHey on 2016/2/21.
 */
public class ProfileMenuItem extends RelativeLayout {

    private String mLeftText;
    private boolean mHasRightIcon;
    private boolean mHasInit;
    private Drawable mLeftIcon;

    public TextView getTvRight() {
        return mTvRight;
    }

    private TextView mTvRight;
    private TextView mTvLeft;

    public ProfileMenuItem(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    private void init(AttributeSet attrs) {
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.ProfileMenuItem);
        mLeftText = typedArray.getString(0);
        mHasRightIcon = typedArray.getBoolean(1, false);
        mLeftIcon = typedArray.getDrawable(2);
        setFocusable(true);
        setClickable(true);
    }
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if(!mHasInit){
            View view = View.inflate(getContext(), R.layout.profile_menu_item, this);
            mTvLeft = (TextView) view.findViewById(R.id.tv_profile_menuitem_left);
            mTvRight = (TextView) view.findViewById(R.id.tv_profile_menuitem_right);
            mTvLeft.setText(mLeftText);
            if(!mHasRightIcon) {
                mTvRight.setCompoundDrawablesWithIntrinsicBounds(0,0,0,0);
            }
            if(mLeftIcon!=null){
                mTvLeft.setCompoundDrawablesWithIntrinsicBounds(mLeftIcon, null, null, null);
            }
            mHasInit = true;
        }
    }

    public TextView getTvLeft() {
        return mTvLeft;
    }
}
