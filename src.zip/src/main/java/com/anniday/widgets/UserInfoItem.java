package com.anniday.widgets;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anniday.R;

import butterknife.Bind;
import butterknife.ButterKnife;


/**
 * Created by VeyHey on 2016/2/21.
 */
public class UserInfoItem extends RelativeLayout {

    @Bind(R.id.tv_user_info_item_center)
    TextView tvUserInfoItemCenter;
    @Bind(R.id.tv_user_info_item_left)
    TextView tvUserInfoItemLeft;
    @Bind(R.id.tv_user_info_item_right)
    TextView tvUserInfoItemRight;
    private String mLeftText;
    private boolean mHasRightIcon;
    private boolean mHasInit;
    private View view;

    public TextView getTvUserInfoItemCenter() {
        return tvUserInfoItemCenter;
    }

    public TextView getTvUserInfoItemLeft() {
        return tvUserInfoItemLeft;
    }

    public TextView getTvUserInfoItemRight() {
        return tvUserInfoItemRight;
    }

    public UserInfoItem(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void init(AttributeSet attrs) {
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.ProfileMenuItem);
        mLeftText = typedArray.getString(0);
        mHasRightIcon = typedArray.getBoolean(1, false);
        setFocusable(true);
        setClickable(true);

        if (!mHasInit) {
            view = View.inflate(getContext(), R.layout.user_info_item, this);
            ((ViewGroup)view).getChildAt(0).setMinimumHeight(view.getMinimumHeight());
            ButterKnife.bind(this, view);
            tvUserInfoItemLeft.setText(mLeftText);
            if (!mHasRightIcon) {
                tvUserInfoItemRight.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            }
            mHasInit = true;
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
    }

}
