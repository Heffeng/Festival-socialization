package com.anniday.widgets;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anniday.R;


/**
 * Created by HuangChun on 2016/1/23.
 */
public class TitleBar extends RelativeLayout{
    private TitleBarClickListener mListener;
    private ImageButton leftIv;
    private ImageButton rightIv;
    private TextView titleTv;
    private String title;
    private Drawable leftIcon;
    private Drawable rightIcon;
    private Boolean isLeftVisible;
    private Boolean isRightVisible;
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void initView(Context context){
        RelativeLayout ll = (RelativeLayout) View.inflate(context, R.layout.titlebar,TitleBar.this);
        leftIv = (ImageButton) ll.findViewById(R.id.imgBtn_left);
        rightIv = (ImageButton) ll.findViewById(R.id.imgBtn_right);
        titleTv = (TextView) ll.findViewById(R.id.tv_title);

        if (TextUtils.isEmpty(title))
            title="";
        titleTv.setText(title);
        if (isRightVisible){
            rightIv.setBackground(rightIcon);
            rightIv.setVisibility(VISIBLE);
            rightIv.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null)
                        mListener.rightClick();
                }
            });
        }else rightIv.setVisibility(INVISIBLE);
        if (isLeftVisible){
            leftIv.setBackground(leftIcon);
            leftIv.setVisibility(VISIBLE);
            leftIv.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener!=null){
                        mListener.leftClick();
                    }
                }
            });
        }else leftIv.setVisibility(GONE);
    }

    public TitleBar(Context context) {
        super(context);
        initView(context);
    }

    public TitleBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs,R.styleable.TitleBar);

        title = typedArray.getString(R.styleable.TitleBar_titleText);
        leftIcon=typedArray.getDrawable(R.styleable.TitleBar_leftImg);
        rightIcon=typedArray.getDrawable(R.styleable.TitleBar_rightImg);
        isLeftVisible=typedArray.getBoolean(R.styleable.TitleBar_leftVisible, false);
        isRightVisible=typedArray.getBoolean(R.styleable.TitleBar_rightVisible, false);
        typedArray.recycle();
        initView(context);

    }

    public TitleBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public TextView getTitleTv() {
        return titleTv;
    }

    public ImageButton getRightIv() {
        return rightIv;
    }

    public ImageButton getLeftIv() {
        return leftIv;
    }
    public void setOnClickListener(TitleBarClickListener listener){
        mListener=listener;
    }
    public interface TitleBarClickListener {
        // 左按钮点击事件
        void leftClick();
        // 右按钮点击事件
        void rightClick();
    }
}
