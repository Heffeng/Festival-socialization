package com.anniday.widgets;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.anniday.R;

import butterknife.Bind;
import butterknife.ButterKnife;


/**
 * Created by Administrator on 2015/5/6.
 */
public class MainActionBar {
    
    @Bind(R.id.btn_actionbar_left)
    public Button btnLeft;
    
    @Bind(R.id.btn_actionbar_right)
    public Button btnRight;

    @Bind(R.id.iv_actionbar_right)
    public ImageView ivRight;
    @Bind(R.id.iv_actionbar_left)
    public ImageView ivLeft;

    
    @Bind(R.id.tv_action_bar_middle)
    public TextView tvMiddle;


    public MainActionBar(Activity activity) {
        ButterKnife.bind(this,activity);
    }

    public void initActionBarButton() {
        ivRight.setVisibility(View.INVISIBLE);
        btnRight.setVisibility(View.GONE);
        btnLeft.setVisibility(View.INVISIBLE);
        ivLeft.setVisibility(View.GONE);
        ivRight.clearAnimation();
    }
}
