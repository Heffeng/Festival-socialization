package com.anniday.view.base;


import com.anniday.model.service.ErrorMessage;

public interface BaseView {
    void hideProgressDialog();
    void showProgressDialog(String message);
    void showError(ErrorMessage message);
    void showError(String message);
}
