package com.anniday.view.base;


import com.anniday.app.App;
import com.anniday.model.service.ErrorMessage;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.ToastUtil;

/**
 * Created by Administrator on 2015/7/13，14.52.
 * 描述：
 */
public abstract class BaseHolder<P extends BasePresenter> implements BaseView {

    protected P presenter;

    public BaseHolder() {
        this.presenter = createP();
        presenter.setView(this);
    }

    protected abstract P createP();

    @Override
    public void showProgressDialog(String message) {

    }

    @Override
    public void hideProgressDialog() {

    }

    @Override
    public void showError(ErrorMessage message) {
        ToastUtil.showCustomToastInDevelop(App.application, message.getMessage());
    }

    @Override
    public void showError(String message) {
        ToastUtil.showCustomToastInDevelop(App.application, message);
    }
}
