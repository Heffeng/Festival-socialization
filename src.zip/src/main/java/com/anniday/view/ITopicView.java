package com.anniday.view;

import com.anniday.model.service.Topic;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * Created by VeyHey on 2016/3/28.
 */
public interface ITopicView extends BaseView {

    void showTopics(List<Topic> topics);

    void loadComplete();
}
