package com.anniday.view;


import com.anniday.model.db.Story;
import com.anniday.model.service.Topic;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * Created by HuangChun on 2016/3/1.
 */
public  interface GetStoryView extends BaseView {
     void startGet();
     void endGet();
     void setResult(List<Story> arrayList);

}
