package com.anniday.view;


import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.view.base.BaseView;

import java.util.List;

public interface ISessionView extends BaseView {


    void showRefreshSession(List<Session> sessions);

    void showLoadMoreSession(List<Session> sessions);


    void refreshComplete();


    void loadMoreComplete();


    void showHasNotReadedSession(boolean hasNotReaded);

    void setLoadMoreEnable(boolean enable);

}
