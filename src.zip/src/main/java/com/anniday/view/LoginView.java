package com.anniday.view;

import com.anniday.model.service.User;
import com.anniday.view.base.BaseView;

/**
 * Created by HuangChun on 2016/2/28.
 */
public interface LoginView extends BaseView {
    public void startLogin();
    public void endLogin();
    public void setAuthResult(User account);
}
