package com.anniday.view;

import com.anniday.model.service.HotAnniDay;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * 选择节日
 * Created by VeyHey on 2016/3/28.
 */
public interface ISelectAnniDayView extends BaseView{

    /**
     * 显示节日列表
     * @param hotAnniDays
     */
    void showHotAnniDays(List<HotAnniDay> hotAnniDays);

    void showNoResult(String s);

    void setLoadMoreEnable(boolean enable);
}
