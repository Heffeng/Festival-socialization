package com.anniday.view;


import com.anniday.model.db.User;
import com.anniday.view.base.BaseView;

public interface ISessionItemView extends BaseView {
    void setUser(User user);
}
