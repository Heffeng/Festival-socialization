package com.anniday.view;


import com.anniday.model.db.Story;
import com.anniday.model.service.HotAnniDay;
import com.anniday.view.base.BaseView;

/**
 * Created by HuangChun on 2016/3/1.
 */
public interface PublishStoryView extends BaseView {
     void startPublish();
     void endPublish();
     void setResult(Story storyModel);

    void setAnniDay(HotAnniDay hotAnniDay);
}
