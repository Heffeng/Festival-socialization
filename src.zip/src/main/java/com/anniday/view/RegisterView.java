package com.anniday.view;

import com.anniday.model.service.User;
import com.anniday.view.base.BaseView;

/**
 * Created by HuangChun on 2016/3/1.
 */
public interface RegisterView extends BaseView{
    public void startRegister();
    public void endRegister();
    public void setAuthResult(User accountModel);
}
