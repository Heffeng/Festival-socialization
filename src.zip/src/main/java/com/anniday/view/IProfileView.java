package com.anniday.view;

import com.anniday.model.db.Story;
import com.anniday.model.service.User;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * Created by VeyHey on 2016/3/28.
 */
public interface IProfileView extends BaseView {

    void showStorys(List<Story> stories);

    void loadComplete();

    void setUser(User user);
}
