package com.anniday.view;

import com.anniday.view.base.BaseView;

public interface IUserInfoSettingView extends BaseView {
    void cutAvatarSuccess(String path);

    void editUserSucess();
}
