package com.anniday.view;

import com.anniday.model.CommentModel;
import com.anniday.model.service.ErrorMessage;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * Created by HuangChun on 2016/4/1.
 */
public interface CreateCommentView extends BaseView{
    void startCreate();
    void endCreate();
    void setResult();
}
