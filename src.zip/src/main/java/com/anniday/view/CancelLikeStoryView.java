package com.anniday.view;

import com.anniday.model.db.Story;
import com.anniday.view.base.BaseView;

/**
 * Created by HuangChun on 2016/3/27.
 */
public interface CancelLikeStoryView extends BaseView {
    public void startCancelLike();
    public void endCancelLike();
    public void setResult(Story story);
}
