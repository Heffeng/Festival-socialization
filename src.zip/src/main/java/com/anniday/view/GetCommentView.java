package com.anniday.view;

import com.anniday.model.CommentModel;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * Created by HuangChun on 2016/3/31.
 */
public interface GetCommentView extends BaseView {
    void startGet();
    void endGet();
    void setResult(List<CommentModel> arrayList);
}
