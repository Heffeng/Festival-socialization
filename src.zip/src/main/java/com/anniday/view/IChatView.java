package com.anniday.view;


import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.view.base.BaseView;

import java.util.List;

/**
 * Created by Administrator on 2015/7/13，17.55.
 * 描述：
 */
public interface IChatView extends BaseView {
    /**
     * 显示对话消息
     *
     * @param sessions
     * @param selfAvaterUrl
     * @param friendAvaterUrl
     */
    void showSessions(List<Session> sessions, String selfAvaterUrl, String friendAvaterUrl, String nickName);

    /**
     * 显示加载更多的对话信息
     *
     * @param sessions
     */
    void showLoadMoreSessions(List<Session> sessions);

    /**
     * 当Session更新时调用此方法
     *
     * @param sessions
     */
    void showUpdateSessions(List<Session> sessions);

    /**
     * 返回底部
     */
    void comeToBottom();

    void loadComplete();

    /**
     * 加入黑名单成功
     */
    void addBlackListSucess();

    /**
     * 举报成功
     */
    void showReportSucess();

    /**
     * 举报失败
     *
     * @param message
     */
    void showReportError(String message);

    void showError(String message);
}
