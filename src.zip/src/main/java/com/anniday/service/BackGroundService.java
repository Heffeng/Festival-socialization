package com.anniday.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.anniday.app.App;
import com.anniday.model.leancloud.base.BaseLeanCloud;
import com.anniday.model.leancloud.helper.MessageHelperV2;


/**
 * Created by Administrator on 2015/5/23.
 */
public class BackGroundService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (App.application.daoSession==null){
            App.application.initSession();
        }
        BaseLeanCloud.init(getApplication());
        MessageHelperV2.openImClient();
        return START_STICKY;
    }
}
