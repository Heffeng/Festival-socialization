package com.anniday.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.anniday.service.BackGroundService;


/**
 * Created by Administrator on 2015/5/24.
 */
public class Bootreceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.startService(new Intent(context, BackGroundService.class));
    }
}
