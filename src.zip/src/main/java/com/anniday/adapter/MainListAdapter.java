package com.anniday.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.ChatActivity;
import com.anniday.activity.ProfileActivity;
import com.anniday.activity.ShowImageActivity;
import com.anniday.app.App;
import com.anniday.constant.Constant;
import com.anniday.model.db.Story;
import com.anniday.presenters.CancelLikeStoryPresenter;
import com.anniday.presenters.LikeStoryPresenter;
import com.anniday.utils.DateFormatUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.ToastUtil;
import com.anniday.view.CancelLikeStoryView;
import com.anniday.view.LikeStoryView;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * Created by HuangChun on 2016/2/23.
 */
public class MainListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int HEADER = 1;
    private static final int HISTORY = 2;
    private static final int NORMAL = 3;
    private Context context;
    private List<Story> datas;

    private CommentListener commentListener;

    public void setListener(CommentListener listener) {
        this.commentListener = listener;
    }


    public MainListAdapter(Context context, List<Story> datas) {
        this.context = context;
        this.datas = datas;
    }

    public void changeData(List<Story> stories) {
        this.datas = stories;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return HEADER;
        } else if (datas.get(position -1).isHistory) {
            return HISTORY;
        } else {
            return NORMAL;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == NORMAL) {
            View view = View.inflate(context, R.layout.main_frag_item, null);
            return new NormalHolder(view);
        } else if (viewType == HEADER) {
            View view = new TextView(context);
            view.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 30));
            view.setBackgroundColor(0xfff5f5f5);
            return new HeaderHolder(view);
        } else {
            View view = View.inflate(context, R.layout.history_today_item, null);
            return new HistoryTodayHolder(view);
        }
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        if (viewType == NORMAL) {
            Story bean = datas.get(position-1);
            holder.itemView.setTag(datas.get(position-1));
            ((NormalHolder) holder).setData(bean);
        } else if (viewType == HEADER) {
            return;
        } else {
            Story bean = datas.get(position-1);
            holder.itemView.setTag(datas.get(position-1));
            ((HistoryTodayHolder) holder).setData(bean);
        }

    }

    @Override
    public int getItemCount() {
        return datas.size()+1;
    }

    public class HeaderHolder extends BaseViewHolder {
        public HeaderHolder(View itemView) {
            super(itemView);
        }
    }

    public class NormalHolder extends BaseViewHolder implements LikeStoryView, CancelLikeStoryView {
        private TextView tvUsernameItem;
        private TextView tvTimeItem;
        private TextView tvContentItem;
        private ImageView ivLikeItem;
        private TextView tvLikenumItem;
        private ImageView ivCommitItem;
        private ImageView ivShareItem;
        private SimpleDraweeView sdvUserItem;
        private SimpleDraweeView sdvPhotoItem;
        private TextView tvAnnidayNameItem;
        private LinearLayout llStoryItem;
        private ImageView ivLikeActiveItem;
        private ImageView ivJoin;

        private Story story;
        private View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.iv_commit_item:
                        commentListener.comment(story.getStoryId());
                        break;
                    case R.id.iv_like_item:
                        like(story);
                        ScaleAnimation scaleAnimation = new ScaleAnimation(2, 1, 2, 1, Animation.RELATIVE_TO_SELF, 0.5F, Animation.RELATIVE_TO_SELF, 0.5F);
                        scaleAnimation.setDuration(300);
                        ScaleAnimation scaleAnimationActive = new ScaleAnimation(2, 1, 2, 1, Animation.RELATIVE_TO_SELF, 0.5F, Animation.RELATIVE_TO_SELF, 0.5F);
                        scaleAnimationActive.setDuration(300);
                        scaleAnimationActive.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) {

                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                                ivLikeActiveItem.setVisibility(View.GONE);
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {
                            }
                        });
                        ivLikeItem.startAnimation(scaleAnimation);
                        if (story.getImgUrl() != null && !TextUtils.isEmpty(story.getImgUrl())) {
                            ivLikeActiveItem.setVisibility(View.VISIBLE);
                            ivLikeActiveItem.startAnimation(scaleAnimationActive);
                        }
                        break;
                    case R.id.iv_share_item:
                        ToastUtil.showCustomToastInDevelop(context, "分享");
                        break;
                    case R.id.sdv_user_item:
                        Intent intent = new Intent(context, ProfileActivity.class);
                        intent.putExtra(ProfileActivity.USER_ID, story.getUserId());
                        context.startActivity(intent);
                        break;
                    case R.id.sdv_photo_item:
                        intent = new Intent(context,ShowImageActivity.class) ;
                        intent.putExtra(ShowImageActivity.IMAGE_URL,story.getImgUrl());
                        context.startActivity(intent);
                        break;
                    case R.id.iv_join:
                        intent = new Intent(context,ChatActivity.class) ;
                        intent.putExtra(ChatActivity.ZONG_CHOU,"您好，我想加入您们有意义的众筹");
                        intent.putExtra(ChatActivity.NICK_NAME,story.getNickname());
                        intent.putExtra(ChatActivity.USER_ID_IN_LONG,story.getUserId());
                        context.startActivity(intent);
                        break;
                }
            }
        };

        public void like(Story story) {
            if (story.getIsLike()) {
                CancelLikeStoryPresenter cancelLikeStoryPresenter = new CancelLikeStoryPresenter(context, this);
                cancelLikeStoryPresenter.cancelLike(story);
            } else {
                LikeStoryPresenter likeStoryPresenter = new LikeStoryPresenter(context, this);
                likeStoryPresenter.like(story);
            }
        }

        public NormalHolder(View itemView) {
            super(itemView);

            tvContentItem = (TextView) itemView.findViewById(R.id.tv_content_item);
            tvUsernameItem = (TextView) itemView.findViewById(R.id.tv_username_item);
            tvTimeItem = (TextView) itemView.findViewById(R.id.tv_time_item);
            tvLikenumItem = (TextView) itemView.findViewById(R.id.tv_likenum_item);
            ivCommitItem = (ImageView) itemView.findViewById(R.id.iv_commit_item);
            ivLikeItem = (ImageView) itemView.findViewById(R.id.iv_like_item);
            ivShareItem = (ImageView) itemView.findViewById(R.id.iv_share_item);
            sdvPhotoItem = (SimpleDraweeView) itemView.findViewById(R.id.sdv_photo_item);
            sdvUserItem = (SimpleDraweeView) itemView.findViewById(R.id.sdv_user_item);
            llStoryItem = (LinearLayout) itemView.findViewById(R.id.ll_story_item);
            tvAnnidayNameItem = (TextView) itemView.findViewById(R.id.tv_anniday_name_item);
            ivLikeActiveItem = (ImageView) itemView.findViewById(R.id.iv_like_active_item);
            ivJoin =  (ImageView)itemView.findViewById(R.id.iv_join);
            ivCommitItem.setOnClickListener(listener);
            ivLikeItem.setOnClickListener(listener);
            ivShareItem.setOnClickListener(listener);
            sdvUserItem.setOnClickListener(listener);
            sdvPhotoItem.setOnClickListener(listener);
            ivJoin.setOnClickListener(listener);
        }


        public void setData(Story story) {
            //设置数据的方法
            this.story = story;
            tvUsernameItem.setText(story.getNickname());
            tvTimeItem.setText(DateFormatUtil.getShowTime(story.getCreateAt(), context));
            tvLikenumItem.setText(String.valueOf(story.getLikeCount()));
            if (TextUtils.isEmpty(story.getText())) {
                tvContentItem.setVisibility(View.GONE);
            } else {

                tvContentItem.setVisibility(View.VISIBLE);
                tvContentItem.setText(story.getText());
            }
            if (story.getAnniName().length() > 2)
                tvAnnidayNameItem.setText(story.getAnniName().substring(0, 2));
            else
                tvAnnidayNameItem.setText(story.getAnniName());

            if (story.getImgUrl() != null && !TextUtils.isEmpty(story.getImgUrl())) {
                sdvPhotoItem.setVisibility(View.VISIBLE);
                sdvPhotoItem.setImageURI(Uri.parse(story.getImgUrl()));
            }
            if (story.getAvatarUrl() != null) {
                sdvUserItem.setImageURI(Uri.parse(story.getAvatarUrl()));
            }
            if (story.getIsLike())
                ivLikeItem.setImageResource(R.mipmap.likes_active1);
            else
                ivLikeItem.setImageResource(R.mipmap.likes);
            if (story.getType()==null||story.getType()== Constant.STORY_NORMAL){
                ivJoin.setVisibility(View.GONE);
            }else if (story.getType()==Constant.STORY_ZONGCHOU){
                ivJoin.setVisibility(View.VISIBLE);
                tvAnnidayNameItem.setText("众筹");
            }
        }

        @Override
        public void startCancelLike() {
            LogUtil.e("开始取消赞");
        }

        @Override
        public void endCancelLike() {
            LogUtil.e("结束取消赞");
        }

        @Override
        public void setResult(Story story) {
            if (story.getIsLike()) {
                ivLikeItem.setImageResource(R.mipmap.likes);
                tvLikenumItem.setText(String.valueOf(story.getLikeCount() - 1));
                story.setIsLike(false);
                story.setLikeCount(story.getLikeCount() - 1);
                App.application.daoSession.getStoryDao().insertOrReplaceInTx(story);
            } else {
                ivLikeItem.setImageResource(R.mipmap.likes_active);
                tvLikenumItem.setText(String.valueOf(story.getLikeCount() + 1));
                story.setIsLike(true);
                story.setLikeCount(story.getLikeCount() + 1);
                App.application.daoSession.getStoryDao().insertOrReplaceInTx(story);

            }

        }

        @Override
        public void startLike() {
            LogUtil.e("开始赞");
        }

        @Override
        public void endLike() {
            LogUtil.e("结束赞");
        }
    }


    public interface CommentListener {
        void comment(Long storyId);
    }



     class HistoryTodayHolder extends BaseViewHolder {
        @Bind(R.id.sdv_user_item)
        SimpleDraweeView sdvUserItem;
        @Bind(R.id.tv_username_item)
        TextView tvUsernameItem;
        @Bind(R.id.tv_time_item)
        TextView tvTimeItem;
        @Bind(R.id.tv_anniday_name_item)
        TextView tvAnnidayNameItem;
        @Bind(R.id.tv_content_item)
        TextView tvContentItem;
        @Bind(R.id.sdv_photo_item)
        SimpleDraweeView sdvPhotoItem;
        @Bind(R.id.iv_like_active_item)
        ImageView ivLikeActiveItem;
        @Bind(R.id.fl_user_item)
        FrameLayout flUserItem;
        @Bind(R.id.ll_story_item)
        LinearLayout llStoryItem;
        private Story story;

         @OnClick({R.id.sdv_photo_item})
         public void onClick(View v){
              Intent  intent = new Intent(context,ShowImageActivity.class) ;
             intent.putExtra(ShowImageActivity.IMAGE_URL,story.getImgUrl());
             context.startActivity(intent);
         }

        public void setData(Story story){
            //设置数据的方法
            this.story = story;
            tvUsernameItem.setText(story.getNickname());
            tvTimeItem.setText(story.time);
            if (TextUtils.isEmpty(story.getText())) {
                tvContentItem.setVisibility(View.GONE);
            } else {

                tvContentItem.setVisibility(View.VISIBLE);
                tvContentItem.setText(story.getText());
            }
            if (story.getAnniName().length() > 2)
                tvAnnidayNameItem.setText(story.getAnniName().substring(0, 2));
            else
                tvAnnidayNameItem.setText(story.getAnniName());

            if (story.getImgUrl() != null && !TextUtils.isEmpty(story.getImgUrl())) {
                sdvPhotoItem.setVisibility(View.VISIBLE);
                sdvPhotoItem.setImageURI(Uri.parse(story.getImgUrl()));
            }
            if (story.getAvatarUrl() != null) {
                sdvUserItem.setImageURI(Uri.parse(story.getAvatarUrl()));
            }
        }
        HistoryTodayHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}

