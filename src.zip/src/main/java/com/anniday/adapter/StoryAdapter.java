package com.anniday.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.ProfileActivity;
import com.anniday.activity.ShowImageActivity;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.model.db.Story;
import com.anniday.presenters.CancelLikeStoryPresenter;
import com.anniday.presenters.LikeStoryPresenter;
import com.anniday.utils.DateFormatUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.ToastUtil;
import com.anniday.view.CancelLikeStoryView;
import com.anniday.view.LikeStoryView;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

/**
 * Created by HuangChun on 2016/2/23.
 */
public class StoryAdapter extends BaseAdapter {

    private Context context;
    private List<Story> datas;

    private MainListAdapter.CommentListener commentListener;

    public void setListener(MainListAdapter.CommentListener listener) {
        this.commentListener = listener;
    }


    public StoryAdapter(Context context, List<Story> datas) {
        this.context = context;
        this.datas = datas;
    }

    public void changeData(List<Story> stories) {
        this.datas = stories;
        notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Object getItem(int i) {
        return datas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view==null) {
            view = View.inflate(context, R.layout.main_frag_item, null);
            view.setTag(new NormalHolder(view));
        }
        NormalHolder holder = (NormalHolder) view.getTag();
        Story bean = datas.get(i);
        holder.setData(bean);
        return view;
    }
    public class NormalHolder extends BaseViewHolder implements LikeStoryView, CancelLikeStoryView {
        private TextView tvUsernameItem;
        private TextView tvTimeItem;
        private TextView tvContentItem;
        private ImageView ivLikeItem;
        private TextView tvLikenumItem;
        private ImageView ivCommitItem;
        private ImageView ivShareItem;
        private SimpleDraweeView sdvUserItem;
        private SimpleDraweeView sdvPhotoItem;
        private TextView tvAnnidayNameItem;
        private LinearLayout llStoryItem;
        private ImageView ivLikeActiveItem;
        private Story story;
        private View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.iv_commit_item:
                        commentListener.comment(story.getStoryId());
                        break;
                    case R.id.iv_like_item:
                        like(story);
                        ScaleAnimation scaleAnimation = new ScaleAnimation(2, 1, 2, 1, Animation.RELATIVE_TO_SELF, 0.5F, Animation.RELATIVE_TO_SELF, 0.5F);
                        scaleAnimation.setDuration(300);
                        ScaleAnimation scaleAnimationActive = new ScaleAnimation(2, 1, 2, 1, Animation.RELATIVE_TO_SELF, 0.5F, Animation.RELATIVE_TO_SELF, 0.5F);
                        scaleAnimationActive.setDuration(300);
                        scaleAnimationActive.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) {

                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                                ivLikeActiveItem.setVisibility(View.GONE);
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {
                            }
                        });
                        ivLikeItem.startAnimation(scaleAnimation);
                        if (story.getImgUrl() != null && !TextUtils.isEmpty(story.getImgUrl())) {
                            ivLikeActiveItem.setVisibility(View.VISIBLE);
                            ivLikeActiveItem.startAnimation(scaleAnimationActive);
                        }
                        break;
                    case R.id.iv_share_item:
                        ToastUtil.showCustomToastInDevelop(context, "分享");
                        break;
                    case R.id.sdv_user_item:
                        Intent intent = new Intent(context, ProfileActivity.class);
                        intent.putExtra(ProfileActivity.USER_ID, story.getUserId());
                        context.startActivity(intent);
                        break;
                    case R.id.sdv_photo_item:
                         intent = new Intent(context,ShowImageActivity.class) ;
                         intent.putExtra(ShowImageActivity.IMAGE_URL,story.getImgUrl());
                        context.startActivity(intent);
                        break;
                }
            }
        };

        public void like(Story story) {
            if (story.getIsLike()) {
                CancelLikeStoryPresenter cancelLikeStoryPresenter = new CancelLikeStoryPresenter(context, this);
                cancelLikeStoryPresenter.cancelLike(story);
            } else {
                LikeStoryPresenter likeStoryPresenter = new LikeStoryPresenter(context, this);
                likeStoryPresenter.like(story);
            }
        }

        public NormalHolder(View itemView) {
            super(itemView);

            tvContentItem = (TextView) itemView.findViewById(R.id.tv_content_item);
            tvUsernameItem = (TextView) itemView.findViewById(R.id.tv_username_item);
            tvTimeItem = (TextView) itemView.findViewById(R.id.tv_time_item);
            tvLikenumItem = (TextView) itemView.findViewById(R.id.tv_likenum_item);
            ivCommitItem = (ImageView) itemView.findViewById(R.id.iv_commit_item);
            ivLikeItem = (ImageView) itemView.findViewById(R.id.iv_like_item);
            ivShareItem = (ImageView) itemView.findViewById(R.id.iv_share_item);
            sdvPhotoItem = (SimpleDraweeView) itemView.findViewById(R.id.sdv_photo_item);
            sdvUserItem = (SimpleDraweeView) itemView.findViewById(R.id.sdv_user_item);
            llStoryItem = (LinearLayout) itemView.findViewById(R.id.ll_story_item);
            tvAnnidayNameItem = (TextView) itemView.findViewById(R.id.tv_anniday_name_item);
            ivLikeActiveItem = (ImageView) itemView.findViewById(R.id.iv_like_active_item);

            ivCommitItem.setOnClickListener(listener);
            ivLikeItem.setOnClickListener(listener);
            ivShareItem.setOnClickListener(listener);
            sdvUserItem.setOnClickListener(listener);
            sdvPhotoItem.setOnClickListener(listener);
        }


        public void setData(Story story) {
            //设置数据的方法
            this.story = story;
            tvUsernameItem.setText(story.getNickname());
            tvTimeItem.setText(DateFormatUtil.getShowTime(story.getCreateAt(), context));
            tvLikenumItem.setText(String.valueOf(story.getLikeCount()));
            if (TextUtils.isEmpty(story.getText())) {
                tvContentItem.setVisibility(View.GONE);
            } else {

                tvContentItem.setVisibility(View.VISIBLE);
                tvContentItem.setText(story.getText());
            }
            if (story.getAnniName().length() > 2)
                tvAnnidayNameItem.setText(story.getAnniName().substring(0, 2));
            else
                tvAnnidayNameItem.setText(story.getAnniName());

            if (story.getImgUrl() != null && !TextUtils.isEmpty(story.getImgUrl())) {
                sdvPhotoItem.setVisibility(View.VISIBLE);
                sdvPhotoItem.setImageURI(Uri.parse(story.getImgUrl()));
            }
            if (story.getAvatarUrl() != null) {
                sdvUserItem.setImageURI(Uri.parse(story.getAvatarUrl()));
            }
            if (story.getIsLike())
                ivLikeItem.setImageResource(R.mipmap.likes_active1);
            else
                ivLikeItem.setImageResource(R.mipmap.likes);
        }

        @Override
        public void startCancelLike() {
            LogUtil.e("开始取消赞");
        }

        @Override
        public void endCancelLike() {
            LogUtil.e("结束取消赞");
        }

        @Override
        public void setResult(Story story) {
            if (story.getIsLike()) {
                ivLikeItem.setImageResource(R.mipmap.likes);
                tvLikenumItem.setText(String.valueOf(story.getLikeCount() - 1));
                story.setIsLike(false);
                story.setLikeCount(story.getLikeCount() - 1);
                App.application.daoSession.getStoryDao().insertOrReplaceInTx(story);
            } else {
                ivLikeItem.setImageResource(R.mipmap.likes_active);
                tvLikenumItem.setText(String.valueOf(story.getLikeCount() + 1));
                story.setIsLike(true);
                story.setLikeCount(story.getLikeCount() + 1);
                App.application.daoSession.getStoryDao().insertOrReplaceInTx(story);

            }

        }

        @Override
        public void startLike() {
            LogUtil.e("开始赞");
        }

        @Override
        public void endLike() {
            LogUtil.e("结束赞");
        }
    }

}

