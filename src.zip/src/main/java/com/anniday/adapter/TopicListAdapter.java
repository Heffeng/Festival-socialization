package com.anniday.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.AnniDayDetailActivity;
import com.anniday.app.App;
import com.anniday.model.service.Topic;
import com.anniday.utils.DateFormatUtil;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by HuangChun on 2016/3/2.
 */
public class TopicListAdapter extends RecyclerView.Adapter<TopicListAdapter.ListViewHolder> {
    private Context context;
    private List<Topic> data;

    public TopicListAdapter(Context context, List<Topic> data) {
        this.context = context;
        this.data = data;
    }

    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ListViewHolder(View.inflate(context, R.layout.topic_frag_item, null));
    }

    @Override
    public void onBindViewHolder(ListViewHolder holder, int position) {
        Topic topicModel = data.get(position);
        holder.setData(topicModel);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    public void changeData(List<Topic> topics) {
        this.data = topics;
        notifyDataSetChanged();
    }


    class ListViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.sv_topic_background)
        SimpleDraweeView svTopicBackground;
        @Bind(R.id.tv_anniday_name)
        TextView tvAnnidayName;
        @Bind(R.id.tv_browse_count)
        TextView tvBrowseCount;
        @Bind(R.id.tv_content_count)
        TextView tvContentCount;
        @Bind(R.id.sv_first_user_avatar)
        SimpleDraweeView svFirstUserAvatar;
        @Bind(R.id.tv_first_user_name)
        TextView tvFirstUserName;
        @Bind(R.id.tv_first_user_time)
        TextView tvFirstUserTime;
        private Topic topicModel;

        @OnClick({R.id.ll_background})
        public void onClick(View view){
            switch (view.getId()){
                case R.id.ll_background:
                    Intent intent = new Intent(view.getContext(), AnniDayDetailActivity.class);
                    intent.putExtra(AnniDayDetailActivity.TOPIC,topicModel);
                    context.startActivity(intent);
                break;
            }
        }

        public ListViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
        public void setData(Topic topicModel) {
            this.topicModel = topicModel;
            tvBrowseCount.setText(topicModel.getSeeNum() + "次浏览");
            tvAnnidayName.setText(topicModel.getName());
            tvContentCount.setText(topicModel.getContentNum() + "条内容");
            if (!TextUtils.isEmpty(topicModel.getBackgroundUrl())) {
                svTopicBackground.setImageURI(Uri.parse(topicModel.getBackgroundUrl()));
            }
            if (!TextUtils.isEmpty(topicModel.getLastUserAvaterUrl())) {
                svFirstUserAvatar.setImageURI(Uri.parse(topicModel.getLastUserAvaterUrl()));
            }
            tvFirstUserName.setText(topicModel.getLastUserName());
            tvFirstUserTime.setText(DateFormatUtil.getShowTime(topicModel.getLastUserCreateTime(), App.application) +
                    "更新状态");
        }
    }
}
