package com.anniday.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.anniday.model.service.ErrorMessage;
import com.anniday.view.base.BaseView;

/**
 * Created by HuangChun on 2016/4/5.
 */
public abstract class BaseViewHolder extends RecyclerView.ViewHolder implements BaseView{
    public BaseViewHolder(View itemView) {
        super(itemView);
    }

    @Override
    public void hideProgressDialog() {

    }
    @Override
    public void showProgressDialog(String message) {

    }

    @Override
    public void showError(ErrorMessage message) {

    }

    @Override
    public void showError(String message) {

    }
}
