package com.anniday.adapter;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.model.service.HotAnniDay;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by Administrator on 2015/7/23，22.56.
 * 描述：
 */
public class SelectAnniDayAdapter extends BaseAdapter {
    private List<HotAnniDay> items;
    private Context context;

    public SelectAnniDayAdapter(List<HotAnniDay> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.lv_select_anniday_item, null);
            ViewHolder holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();
        holder.tvAnnidayName.setText(items.get(position).getName());
        holder.tvAnnidayContentnum.setText(items.get(position).getContentNum() + "条内容");
        if (!TextUtils.isEmpty(items.get(position).getBackgroundUrl())){
            holder.svAnnidayBackground.setImageURI(Uri.parse(items.get(position).getBackgroundUrl()));
        }
        return convertView;
    }

    public void changeList(List<HotAnniDay> hotAnniDays) {
        this.items = hotAnniDays;
        notifyDataSetChanged();
    }

    static class ViewHolder {
        @Bind(R.id.sv_anniday_background)
        SimpleDraweeView svAnnidayBackground;
        @Bind(R.id.tv_anniday_name)
        TextView tvAnnidayName;
        @Bind(R.id.tv_anniday_contentnum)
        TextView tvAnnidayContentnum;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
