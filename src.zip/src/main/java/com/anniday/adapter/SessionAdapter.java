package com.anniday.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.anniday.R;
import com.anniday.activity.ChatActivity;
import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DBConstans;
import com.anniday.model.db.User;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.presenters.SessionItemPresenter;
import com.anniday.utils.DateFormatUtil;
import com.anniday.view.ISessionItemView;
import com.anniday.view.base.BaseHolder;
import com.daimajia.swipe.SwipeLayout;
import com.daimajia.swipe.adapters.BaseSwipeAdapter;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by WeiHey on 2015/5/15.
 */
public class SessionAdapter extends BaseSwipeAdapter implements View.OnClickListener {
    private List<Session> sessions;
    private Context context;


    public SessionAdapter(List<Session> sessions, Context context) {
        this.sessions = sessions;
        this.context = context;
    }

    @Override
    public int getCount() {
        return sessions.size();
    }

    @Override
    public Object getItem(int position) {
        return sessions.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getSwipeLayoutResourceId(int i) {
        return R.id.swipe_frag_session;
    }

    @Override
    public View generateView(int position, ViewGroup viewGroup) {
        View convertView = null;
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.lv_sessionitem, null);
            Holder holder = new Holder();
            ButterKnife.bind(holder, convertView);
            convertView.setTag(holder);

            SwipeLayout swipeLayout = holder.swipeLayout;
            swipeLayout.setShowMode(SwipeLayout.ShowMode.PullOut);
            swipeLayout.addDrag(SwipeLayout.DragEdge.Right, holder.tvDelete);
            swipeLayout.setClickToClose(true);
            swipeLayout.setDragDistance(300);

        }
        return convertView;
    }

    @Override
    public void fillValues(int position, View view) {
        final Holder holder = (Holder) view.getTag();
        holder.ivAvater.setImageURI(null);
        holder.tvNickName.setText(null);
        final Session session = sessions.get(position);
        holder.setSession(session);
        holder.tvNickName.setTag(session);
        holder.requestUser(session.getSessionName());
        if (session.getType() != null) {
            switch (session.getType()) {
                case DBConstans.TEXT:
                    holder.tvContent.setText(session.getText());
                    break;
                case DBConstans.AUDIO:
                    holder.tvContent.setText(context.getString(R.string.session_audio_notice));
                    break;
                case DBConstans.PIC:
                    holder.tvContent.setText(context.getString(R.string.session_pic_notice));
                    break;
                case DBConstans.PIC_AUDIO:
                    holder.tvContent.setText(context.getString(R.string.session_pic_audio_notice));
                    break;
            }
        }
        if (!session.getIsReaded()) {
            holder.ivReaded.setVisibility(View.VISIBLE);
        } else {
            holder.ivReaded.setVisibility(View.INVISIBLE);
        }
        holder.tvTime.setText(DateFormatUtil.getShowTimeWithHmInTodayOrMdBeforeToday(session.getTimestamp().getTime(), context));
        holder.llContent.setOnClickListener(this);
        holder.ivAvater.setTag(session);
        holder.ivAvater.setOnClickListener(this);
        holder.llContent.setTag(session);
        holder.tvDelete.setOnClickListener(this);
        holder.tvDelete.setTag(holder);
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        Session session;
        switch (v.getId()) {
            case R.id.iv_frag_session_avater:
//                Intent intent = new Intent(context, ProfileActivity.class);
//                Session session = (Session) v.getTag();
//                intent.putExtra(ProfileActivity.USER_ID, Long.valueOf(session.getSessionName()));
//                context.startActivity(intent);
                break;
            case R.id.ll_frag_session_content:
                intent = new Intent(context, ChatActivity.class);
                session = (Session) v.getTag();
                intent.putExtra(ChatActivity.USER_ID_IN_LONG, Long.valueOf(session.getSessionName()));
                context.startActivity(intent);
                break;
            case R.id.tv_lv_frag_session_delete:
                Holder holder = (Holder) v.getTag();
                holder.delete();
                break;
        }
    }

    public void changeList(List<Session> sessions) {
        this.sessions = sessions;
        notifyDataSetChanged();
    }

    class Holder extends BaseHolder<SessionItemPresenter> implements ISessionItemView {
        @Bind(R.id.iv_frag_session_avater)
        public SimpleDraweeView ivAvater;
        @Bind(R.id.ll_frag_session_content)
        public LinearLayout llContent;
       
        @Bind(R.id.tv_frag_session_nickname)
        public TextView tvNickName;
        
        @Bind(R.id.tv_frag_session_time)
        public TextView tvTime;
        
        @Bind(R.id.tv_frag_session_content)
        public TextView tvContent;

        @Bind(R.id.tv_frag_session_divider)
        public TextView tvDivider;
        @Bind(R.id.iv_frag_session_readed)
        public ImageView ivReaded;
        @Bind(R.id.tv_lv_frag_session_delete)
        public TextView tvDelete;
        @Bind(R.id.swipe_frag_session)
        public SwipeLayout swipeLayout;
        private String userId;
        private Session session;


        @Override
        protected SessionItemPresenter createP() {
            return new SessionItemPresenter();
        }


        public void requestUser(String userId) {
            if(session.user!=null){
                setUser(session.user);
            }else {
                this.userId = userId;
                presenter.getUser(userId);
            }
        }

        public void delete() {
            presenter.deleteUser(userId);
        }

        @Override
        public void setUser(User user) {
            if (user.getUserId().toString().equals(this.userId)) {
                session.user = user;
                tvNickName.setText(user.getNickname());
                if(!TextUtils.isEmpty(user.getAvatarUrl())) {
                    ivAvater.setImageURI(Uri.parse(user.getAvatarUrl()));
                }
            }
        }

        public void setSession(Session session) {
            this.session = session;
        }
    }
}
