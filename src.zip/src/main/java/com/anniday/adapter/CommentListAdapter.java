package com.anniday.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anniday.R;
import com.anniday.activity.ProfileActivity;
import com.anniday.model.CommentModel;
import com.anniday.utils.DateFormatUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.ToastUtil;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

/**
 * Created by HuangChun on 2016/3/31.
 */
public class CommentListAdapter extends RecyclerView.Adapter<CommentListAdapter.ListViewHolder> {

    private Context context;
    private List<CommentModel> comments;
    private ReplyListener replyListener;


    public CommentListAdapter(Context context, List<CommentModel> comments,ReplyListener replyListener) {
        this.context = context;
        this.comments = comments;
        this.replyListener = replyListener;
    }

    public void changeData(List<CommentModel> comments) {
        this.comments = comments;
        notifyDataSetChanged();
    }


    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = View.inflate(context, R.layout.comment_item_layout, null);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ListViewHolder holder, int position) {
        CommentModel comment = comments.get(position);
        holder.itemView.setTag(comments.get(position));
        holder.setData(comment);
    }

    @Override
    public int getItemCount() {
        return comments.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        private SimpleDraweeView sdvCommentItem;
        private TextView tvCommentContent;
        private TextView tvCommentTime;
        private RelativeLayout rlCommentContentItem;

        public ListViewHolder(View itemView) {
            super(itemView);
            sdvCommentItem = (SimpleDraweeView) itemView.findViewById(R.id.sdv_comment_item);
            tvCommentContent = (TextView) itemView.findViewById(R.id.tv_comment_content);
            tvCommentTime = (TextView) itemView.findViewById(R.id.tv_comment_time);
            rlCommentContentItem = (RelativeLayout) itemView.findViewById(R.id.rl_comment_content_item);
        }


        public void setData(final CommentModel commentModel) {
            sdvCommentItem.setImageURI(Uri.parse(commentModel.getFromUserAvatar()));
            String fromUserName = commentModel.getFromUserName();
            String toUserName = commentModel.getToUserName();
            final String comment = commentModel.getComment();
            Long toUserId = commentModel.getToUserId();
            Long fromUserId = commentModel.getFromUserId();
            LogUtil.e("toUserName"+toUserName);

            LogUtil.e("fromUserId"+fromUserId+"fromUserName"+fromUserName);

            StringBuilder actionText = new StringBuilder();
            //谁回复
            actionText.append("<a style=\"text-decoration:none;\" href='fromName' ><font color='#3497D8'>"
                    + fromUserName  + "</font> </a>");

            // 回复谁，被回复的人可能不存在。
            if(toUserName!=null&&toUserName.length()>0) {
                actionText.append("回复");
                actionText.append("<font color='#3497D8'><a style=\"text-decoration:none;\" href='toName'>"
                        + toUserName + " " + " </a></font>");
            }
            // 内容
            actionText.append("<font color='#484848'><a style=\"text-decoration:none;\" href='content'>"
                    + ":" + comment + " " + " </a></font>");

            tvCommentContent.setText(Html.fromHtml(actionText.toString()));
            tvCommentContent.setMovementMethod(LinkMovementMethod
                    .getInstance());
            CharSequence text = tvCommentContent.getText();
            int ends = text.length();
            Spannable spannable = (Spannable) tvCommentContent.getText();
            URLSpan[] urlspan = spannable.getSpans(0, ends, URLSpan.class);
            SpannableStringBuilder stylesBuilder = new SpannableStringBuilder(text);
            stylesBuilder.clearSpans();

            for (URLSpan url : urlspan) {
                MyURLSpan myURLSpan = new MyURLSpan(url.getURL(),fromUserName,fromUserId,toUserName,toUserId,comment);
                stylesBuilder.setSpan(myURLSpan, spannable.getSpanStart(url),
                        spannable.getSpanEnd(url), spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            tvCommentContent.setText(stylesBuilder);
            tvCommentContent.setFocusable(false);
            tvCommentContent.setClickable(false);
            tvCommentContent.setLongClickable(false);


            LogUtil.e(commentModel.getComment() + commentModel.getCreateAt());
            tvCommentTime.setText(DateFormatUtil.getShowTime(commentModel.getCreateAt(), context));

            rlCommentContentItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    replyListener.Reply(commentModel.fromUserId,commentModel.getFromUserName());
                }
            });
        }

        private  class MyURLSpan extends ClickableSpan {
            private String clickString;
            // 回复人的名字
            private String fromName;
            // 被回复人的名字
            private String toName;
            // 评论内容
            private String content;
            private Long fromUserId;
            private Long toUserId;

            public MyURLSpan(String clickString, String fromName,Long fromUserId, String toName,Long toUserId, String content) {
                this.clickString = clickString;
                this.fromName = fromName;
                this.fromUserId =fromUserId;
                this.toUserId = toUserId;
                this.toName = toName;
                this.content = content;
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false);
                //给标记的部分 的文字 添加颜色
                if(clickString.equals("toName")){
                    ds.setColor(Color.BLUE);
                }else if(clickString.equals("fromName")){
                    ds.setColor(Color.BLUE);
                }
            }

            @Override
            public void onClick(View widget) {
                // 根据文字的标记 来进行相应的 响应事件
                if (clickString.equals("toName")) {
                    //可以再次进行跳转activity的操作
                    Intent intent = new Intent(context, ProfileActivity.class);
                    intent.putExtra(ProfileActivity.USER_ID, toUserId);
                    context.startActivity(intent);
                } else if (clickString.equals("fromName")) {
                    //可以再次进行跳转activity的操作
                    Intent intent = new Intent(context, ProfileActivity.class);
                    intent.putExtra(ProfileActivity.USER_ID, fromUserId);
                    context.startActivity(intent);
                } else if(clickString.equals("content")){
                    //可以再次进去回复评论的操作
                    replyListener.Reply(fromUserId,fromName);
                }
            }
        }
    }
    public interface ReplyListener{
        void Reply(Long toUserId,String toUserName);
    }
}

