package com.anniday.constant;

/**
 * Created by HuangChun on 2016/2/28.
 */
public class URLConstant {
    public static final String HOST = "http://139.129.50.142:8080/service/";
//    public static final String HOST = "http://192.168.191.1:8080/AnniDayService/";

    public static final String LOGIN = HOST +"account/login";

    public static final String REGISTER = HOST + "account/register";

    /*状态*/
    public static final String PUBLISHSTORY = HOST + "story/create";
    public static final String GETSTORY = HOST + "story/get";
    public static final String GET_STORY_BY_ANNIDAY = HOST + "story/getByAnniDay";
    public static final String GET_STORY_BY_USER =  HOST + "story/getByUser";


    /*会话*/
    public static final String GET_CONVERSATION_BETWEEN = HOST + "conversation/getConversationBetween";
    public static final String GET_CONVERSATION_BY_USERID = HOST + "conversation/getConversationByUserId";
    public static final String CREATE_CONVERSATION = HOST + "conversation/create";
    public static final String GET_CONVERSATION_BY_LEANCLOUD_ID = HOST + "conversation/getByLeanCloudConversationId";


    /*用户*/
    public static final String GET_USER_BY_ID = HOST + "user/get";
    public static final String USER_EDIT = HOST + "user/edit";

    /*节日*/
    public static final String GET_HOT_ANNIDAYS_BY_NAME = HOST + "anniDay/getHotAnniDaysByName";
    public static final String LIST_TOPICS = HOST + "anniDay/list";

    /*点赞*/
    public static final String LIKE = HOST +"like/create";
    public static final String CANCEL_LIKE = HOST + "like/cancel";

    /*评论*/
    public static final String GET_COMMENT_BY_STORYID = HOST +"comment/getCommentByStoryId";
    public static final String COMMENT = HOST +"comment/create";

    /*历史上的今天*/
    public static final String HISTORY_TODAY_LIST = HOST +"historyToday/todayList";

}
