package com.anniday.constant;

/**
 * Created by HuangChun on 2016/2/28.
 */
public class Constant {

    public static final int OBJECT_NOT_FIND = 2001;
    /***/
    public static final int QUERY_NO_RESULT = 2002;
    /***/
    public static final int REQUEST_NOT_VLIED=2003;
    /***/
    public static final int PHONENUM_OT_PASSWORD_WRONG=2004;


    public static final int PHONENUM_HASBEEN_REGISTERED = 2005;

    public static final int ANNIDAY_DOESNOT_EXIT = 2006;

    public static final int SERVER_UNKNOWN_ERROR= 3001;
    /***/
    public static final int SERVICE_UNAVAILABLE_ERROR=3002;
    /***/
    public static final int CLIENT_AUTH_FAILED_ERROR=3003;
    /***/
    public static final int USER_AUTH_FAILED_ERROR=3004;

    /**
     * 客户端错误码
     *
     * */

    /***/
    public static final int CLIENT_UNKNOWN_ERROR=3005;
    /***/
    public static final int CLIENT_NET_ERROR=3006;
    /***/
    public static final int CLIENT_JSON_ERROR=3007;

    public static final int STORY_NORMAL = 1;
    public static final int STORY_ZONGCHOU = 2;
}
