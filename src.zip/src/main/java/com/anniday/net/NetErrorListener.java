package com.anniday.net;

import android.util.Log;

import com.android.volley.NetworkResponse;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.anniday.constant.Constant;
import com.anniday.model.service.ErrorMessage;
import com.anniday.utils.LogUtil;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.io.UnsupportedEncodingException;

/**
 * Created by HuangChun on 2016/2/28.
 */
public abstract class NetErrorListener implements Response.ErrorListener {
    public abstract void onError(ErrorMessage msg);

    private String url;
    @Override
    public void onErrorResponse(VolleyError error) {
        ErrorMessage msg=null;
        if(error==null)
        {
            Log.e(url,"error is null");
            msg=new ErrorMessage(Constant.CLIENT_UNKNOWN_ERROR);
        }else{
            NetworkResponse response=error.networkResponse;
            if(response!=null)
            {
                Gson gson=new Gson();
                try {
                    String json = new String(
                            response.data,
                            HttpHeaderParser.parseCharset(response.headers));
                    Log.e(url,"结果错误:"+json);
                    msg=gson.fromJson(json, ErrorMessage.class);
                } catch (UnsupportedEncodingException e) {
                    msg=new ErrorMessage(Constant.CLIENT_UNKNOWN_ERROR);
                } catch (JsonSyntaxException e) {
                    msg=new ErrorMessage(Constant.CLIENT_JSON_ERROR);
                }
            }else{
                Log.e(url,error.getMessage()+",response is null");
                msg=new ErrorMessage(Constant.CLIENT_UNKNOWN_ERROR);
            }
        }
        Log.e(getUrl(),"END------------------------------------------------");
        onError(msg);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
