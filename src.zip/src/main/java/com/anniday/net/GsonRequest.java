package com.anniday.net;

import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;
import com.anniday.utils.LogUtil;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by HuangChun on 2016/2/28.
 */
public class GsonRequest<T> extends Request<T> {

    private final NetErrorListener errorListener;
    protected static final String PROTOCOL_CHARSET = "utf-8";

    /** Content type for request. */
    protected final String PROTOCOL_CONTENT_TYPE =
            String.format("application/json; charset=%s", PROTOCOL_CHARSET);

    private final Gson gson=new Gson();
    private  Class<T> clazz;
    private final Response.Listener<T> listener;
    //private final String mRequestBody;
    private final Map<String,String> params;
    private Type type = null;

    public GsonRequest(String url,Map<String,String> params,
                       Class<T> clazz,Response.Listener<T> listener,NetErrorListener errorListener)
    {
        super(Method.POST,url,errorListener);
        this.params=params;
        this.clazz=clazz;
        this.errorListener=errorListener;
        this.listener=listener;
    }

    public GsonRequest(String url, Map<String, String> params,
                       Type type, Response.Listener<T> listener, NetErrorListener errorListener) {
        super(Method.POST,url,errorListener);
        this.type = type;
        this.listener = listener;
        this.params = params;
        this.errorListener = errorListener;
        errorListener.setUrl(url);
        Log.e(getUrl(),"START------------------------------------------------");
        if (params!=null){
            Log.e(getUrl(),"参数:"+params.toString());
        }
    }

    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return params==null?new HashMap<String, String>():params;
    }


    @Override
    protected void deliverResponse(T response) {
        listener.onResponse(response);
    }

    @Override
    protected Response<T> parseNetworkResponse(NetworkResponse response) {

        try {
            String json = new String(
                    response.data,
                    HttpHeaderParser.parseCharset(response.headers));
            Log.e(getUrl(),"返回结果:"+json);
            Log.e(getUrl(),"END------------------------------------------------");
            T t ;
            if(type !=  null){
                t = gson.fromJson(json,type);
            }else {
                t = gson.fromJson(json,clazz);
            }
            return Response.success(t, HttpHeaderParser.parseCacheHeaders(response));
        } catch (UnsupportedEncodingException e) {
            return Response.error(new ParseError(e));
        } catch (JsonSyntaxException e) {
            return Response.error(new ParseError(e));
        }
    }
}
