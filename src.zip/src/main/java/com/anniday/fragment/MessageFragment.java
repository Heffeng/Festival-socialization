package com.anniday.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;

import com.anniday.R;
import com.anniday.activity.MainActivity;
import com.anniday.adapter.SessionAdapter;
import com.anniday.fragment.base.BaseFragment;
import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.presenters.SessionPresenter;
import com.anniday.view.ISessionView;
import com.anniday.widgets.xlistview.XListView;
import com.daimajia.swipe.SwipeLayout;

import java.util.List;

import butterknife.Bind;

/**
 * 会话Fragment
 */
public class MessageFragment extends BaseFragment<SessionPresenter> implements ISessionView {
    @Bind(R.id.lv_chat_friend_list)
    public XListView lvSession;

    private SessionAdapter adapter;

    @Override
    public void onResume() {
        super.onResume();
        closeSwipe(-1);
    }



    /**
     * 关闭滑动
     *
     * @param position
     */
    public void closeSwipe(int position) {
        for (int i = 0; i < lvSession.getChildCount(); i++) {
            if (position != i) {
                View child = lvSession.getChildAt(i).findViewById(R.id.swipe_frag_session);
                if (child != null) {
                    ((SwipeLayout) child).close(true);
                }
            }
        }
    }

    @Override
    protected void initData() {
        lvSession.setAutoLoadEnable(true);
        lvSession.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int x = (int) event.getX();
                int y = (int) event.getY();
                int position = lvSession.pointToPosition(x, y);
                closeSwipe(position);
                return false;
            }
        });

        lvSession.setXListViewListener(new XListView.IXListViewListener() {
            @Override
            public void onRefresh() {
                presenter.refresh();
            }

            @Override
            public void onLoadMore() {
                presenter.loadMore();
            }
        });

        presenter.refresh();
//        presenter.checkNotReadedSession();
    }

    @Override
    protected SessionPresenter createP() {
        return new SessionPresenter();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected View initView(LayoutInflater inflater) {
        View view = View.inflate(getActivity(), R.layout.frag_session, null);
        return view;
    }


    @Override
    public void showRefreshSession(List<Session> sessions) {
        if (adapter == null) {
            adapter = new SessionAdapter(sessions, activity);
            lvSession.setAdapter(adapter);
        } else {
            adapter.changeList(sessions);
        }
        closeSwipe(-1);
    }

    @Override
    public void showLoadMoreSession(List<Session> sessions) {
        adapter.changeList(sessions);
        closeSwipe(-1);
    }

    @Override
    public void refreshComplete() {
        lvSession.stopRefresh();
    }

    @Override
    public void loadMoreComplete() {
        lvSession.stopLoadMore();
    }


    @Override
    public void showHasNotReadedSession(boolean hasNotReaded) {
        ((MainActivity) activity).setMessageNotReaded(hasNotReaded);
    }

    @Override
    public void setLoadMoreEnable(boolean enable) {
        lvSession.setPullLoadEnable(enable);
    }
}
