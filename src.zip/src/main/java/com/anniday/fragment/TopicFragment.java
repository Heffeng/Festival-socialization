package com.anniday.fragment;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;

import com.anniday.R;
import com.anniday.adapter.TopicListAdapter;
import com.anniday.fragment.base.BaseFragment;
import com.anniday.model.service.Topic;
import com.anniday.presenters.TopicPresenter;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.view.ITopicView;
import com.anniday.widgets.DividerItemDecoration;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayout;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayoutDirection;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;

import static com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayoutDirection.TOP;

/**
 * Created by VeyHey on 2016/2/22.
 * 话题页面
 */
public class TopicFragment extends BaseFragment<TopicPresenter> implements SwipyRefreshLayout.OnRefreshListener, ITopicView {
    @Bind(R.id.rv_topic)
    RecyclerView rvTopic;
    @Bind(R.id.main_toolbar)
    RelativeLayout mainToolbar;
    @Bind(R.id.sfl_topic)
    SwipyRefreshLayout sflTopic;
    private TopicListAdapter adapter;

    @Override
    protected TopicPresenter createP() {
        return new TopicPresenter();
    }

    @Override
    protected void initData() {
        if (adapter==null) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(activity);
            rvTopic.addItemDecoration(new DividerItemDecoration(activity, DividerItemDecoration.VERTICAL_LIST,0));
            adapter = new TopicListAdapter(activity, new ArrayList<Topic>());
            rvTopic.setAdapter(adapter);
            rvTopic.setLayoutManager(linearLayoutManager);
            sflTopic.setOnRefreshListener(this);
            presenter.requestTopics();
        }
    }

    public TopicFragment() {
    }

    @Override
    protected View initView(LayoutInflater inflater) {
        return inflater.inflate(R.layout.frag_topic, null);
    }

    @Override
    public void onRefresh(SwipyRefreshLayoutDirection swipyRefreshLayoutDirection) {
        switch (swipyRefreshLayoutDirection){
            case TOP:
                presenter.requestTopics();
                break;
            case BOTTOM:
                presenter.loadMore();
                break;
        }
    }

    @Override
    public void showTopics(List<Topic> topics) {
        adapter.changeData(topics);
    }

    @Override
    public void loadComplete() {
        sflTopic.setRefreshing(false);
    }
}
