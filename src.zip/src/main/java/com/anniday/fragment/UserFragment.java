package com.anniday.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anniday.R;
import com.anniday.activity.AccountSettingActivity;
import com.anniday.activity.ProfileActivity;
import com.anniday.activity.UserInfoSettingActivity;
import com.anniday.fragment.base.BaseFragment;
import com.anniday.model.service.User;
import com.anniday.presenters.base.BasePresenter;
import com.facebook.drawee.view.SimpleDraweeView;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by VeyHey on 2016/2/22.
 * 个人中心页面
 */
public class UserFragment extends BaseFragment {

    @Bind(R.id.sv_avatar)
    SimpleDraweeView svAvatar;
    @Bind(R.id.main_toolbar)
    RelativeLayout mainToolbar;
    @Bind(R.id.tv_username)
    TextView tvUsername;

    @Override
    protected BasePresenter createP() {
        return null;
    }

    @Override
    protected void initData() {
        User user = User.getCurrentUser();
        if (user != null ) {
            tvUsername.setText(user.getNickname());
            if(!TextUtils.isEmpty(user.getAvatarUrl())) {
                svAvatar.setImageURI(Uri.parse(user.getAvatarUrl()));
            }
        }
    }


    @Override
    protected View initView(LayoutInflater inflater) {
        return inflater.inflate(R.layout.frag_user, null);
    }


    @OnClick({R.id.sv_avatar,R.id.btn_user_info_edit,R.id.ll_story})
    public void onClick(View v) {
        Intent intent = null;
        switch(v.getId()){
            case R.id.sv_avatar:
                intent = new Intent(activity, AccountSettingActivity.class);
                startActivity(intent);
                break;
            case R.id.btn_user_info_edit:
                intent = new Intent(activity, UserInfoSettingActivity.class);
                startActivity(intent);
                break;
            case R.id.ll_story:
                intent = new Intent(activity, ProfileActivity.class);
                intent.putExtra(ProfileActivity.USER_ID,User.getCurrentUser().getUserId());
                startActivity(intent);
                break;
        }
    }

}
