package com.anniday.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;

import com.anniday.R;
import com.anniday.activity.CommitActivity;
import com.anniday.adapter.MainListAdapter;
import com.anniday.app.App;
import com.anniday.fragment.base.BaseFragment;
import com.anniday.model.db.Story;
import com.anniday.presenters.CancelLikeStoryPresenter;
import com.anniday.presenters.GetStoryPresenter;
import com.anniday.presenters.LikeStoryPresenter;
import com.anniday.utils.LogUtil;
import com.anniday.view.CancelLikeStoryView;
import com.anniday.view.GetStoryView;
import com.anniday.view.LikeStoryView;
import com.anniday.widgets.DividerItemDecoration;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayout;
import com.orangegangsters.github.swipyrefreshlayout.library.SwipyRefreshLayoutDirection;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by VeyHey on 2016/2/22.
 * 主页的实现
 */
public class MainFragment extends BaseFragment<GetStoryPresenter> implements GetStoryView,
        SwipyRefreshLayout.OnRefreshListener,MainListAdapter.CommentListener{
    @Bind(R.id.recycler_view)
    RecyclerView recyclerView;
    @Bind(R.id.main_toolbar)
    RelativeLayout mainToolbar;
    @Bind(R.id.srl_story)
    SwipyRefreshLayout srlStory;

    MainListAdapter adapter;

    private Long beforeId ;
    private Long afterId;
    @Override
    protected GetStoryPresenter createP() {
        return new GetStoryPresenter(activity, this);
    }

    @Override
    protected void initData() {
        adapter = new MainListAdapter(activity, App.application.daoSession.getStoryDao().loadAll());
        adapter.setListener(this);
        recyclerView.setAdapter(adapter);

        presenter.getStory(20, null, null);
        LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(activity, DividerItemDecoration.VERTICAL_LIST,1));
        srlStory.setOnRefreshListener(this);
    }

    @Override
    protected View initView(LayoutInflater inflater) {
        return inflater.inflate(R.layout.frag_main, null);
    }

    @Override
    public void startGet() {
    }

    @Override
    public void endGet() {
        srlStory.setRefreshing(false);
    }

    @Override
    public void setResult(List<Story> arrayList) {
        adapter.changeData(arrayList);
        if (arrayList.size()>0){
            afterId = arrayList.get(0).getStoryId();
            beforeId = arrayList.get(arrayList.size()-1).getStoryId();
        }
    }


    @Override
    public void onRefresh(SwipyRefreshLayoutDirection direction) {
        switch (direction){
            case BOTTOM:
                presenter.getStory(20,beforeId,null);
                break;
            case TOP:
                presenter.getStory(20,null,null);
                break;
        }
    }

    @Override
    public void comment(Long storyId) {
        Intent intent = new Intent(activity,CommitActivity.class);
        LogUtil.e(String.valueOf(storyId));
        Bundle bundle = new Bundle();
        bundle.putLong("storyId",storyId);
        intent.putExtra("bundle",bundle);
        startActivity(intent);
    }


}
