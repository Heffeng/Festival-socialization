package com.anniday.fragment.base;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.View;

import com.anniday.R;
import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.model.service.ErrorMessage;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.ToastUtil;
import com.anniday.view.base.BaseView;

import butterknife.ButterKnife;

/**
 * Created by VeyHey on 2016/2/20.
 */
public abstract class BaseDialogFragment<P extends BasePresenter>  extends DialogFragment implements BaseView {
    protected P presenter;
    protected BaseActivity activity;
    protected View view;

    protected abstract P createP();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        presenter = createP();
        if (presenter != null) {
            presenter.setView(this);
        }
        activity = (BaseActivity) getActivity();
        int style = DialogFragment.STYLE_NORMAL, theme = 0;
        setStyle(style, theme);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getContext(), R.style.DialogStyle);
        dialog.setContentView(getLayoutId());
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        ButterKnife.bind(this, getDialog());
        initData();
    }

    protected abstract int getLayoutId();

    protected abstract void initData();

    @Override
    public void onResume() {
        super.onResume();
        if (presenter != null) presenter.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (presenter != null) presenter.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (presenter != null) presenter.onDestroy();
        presenter = null;
        activity = null;
        view = null;
    }

    public void showProgressDialog(String message) {
        activity.showProgressDialog(message);
    }

    public void hideProgressDialog() {
        activity.hideProgressDialog();
    }

    @Override
    public void showError(ErrorMessage message) {
        ToastUtil.showCustomToastInDevelop(App.application, message.getMessage());
    }
}
