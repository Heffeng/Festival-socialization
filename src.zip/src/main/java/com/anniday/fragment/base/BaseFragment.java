package com.anniday.fragment.base;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.anniday.activity.base.BaseActivity;
import com.anniday.app.App;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.model.service.ErrorMessage;
import com.anniday.presenters.base.BasePresenter;
import com.anniday.utils.ToastUtil;
import com.anniday.view.base.BaseView;

import butterknife.ButterKnife;

/**
 * Fragment的基类
 *
 * @author Administrator
 */
public abstract class BaseFragment<P extends BasePresenter> extends Fragment implements BaseView {

    protected P presenter;
    protected BaseActivity activity;
    protected View view;
    protected abstract P createP();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        presenter = createP();
        if (presenter != null) {
            presenter.setView(this);
        }
        activity = (BaseActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = initView(inflater);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
    }

    protected abstract void initData();

    protected abstract View initView(LayoutInflater inflater);

    @Override
    public void onResume() {
        super.onResume();
        if (presenter != null) presenter.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (presenter != null) presenter.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (presenter != null) presenter.onDestroy();
        presenter = null;
        activity = null;
        view = null;
    }
    public void showProgressDialog(String message) {
        activity.showProgressDialog(message);
    }

    public void hideProgressDialog() {
        activity.hideProgressDialog();
    }

    @Override
    public void showError(ErrorMessage message) {
        ToastUtil.showCustomToastInDevelop(App.application, message.getMessage());
    }
    @Override
    public void showError(String message) {
        ToastUtil.showCustomToastInDevelop(App.application, message);
    }
}
