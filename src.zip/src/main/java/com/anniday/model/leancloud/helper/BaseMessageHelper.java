package com.anniday.model.leancloud.helper;

import android.support.annotation.NonNull;

import com.android.volley.Response;
import com.anniday.app.App;
import com.anniday.model.db.Conversation;
import com.anniday.model.db.dao.ConversationDao;
import com.anniday.model.service.ConversationManager;
import com.anniday.model.service.ErrorMessage;
import com.anniday.model.service.ListConversationVo;
import com.anniday.model.service.User;
import com.anniday.model.service.UserManager;
import com.anniday.net.NetErrorListener;
import com.anniday.utils.BeanUtils;
import com.anniday.utils.ToastUtil;
import com.avos.avoscloud.im.v2.AVIMClient;
import com.avos.avoscloud.im.v2.AVIMConversation;
import com.avos.avoscloud.im.v2.AVIMException;
import com.avos.avoscloud.im.v2.callback.AVIMClientCallback;
import com.avos.avoscloud.im.v2.callback.AVIMConversationCreatedCallback;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.query.QueryBuilder;
import de.greenrobot.dao.query.WhereCondition;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


/**
 * Created by Administrator on 2015/9/7.
 */
public class BaseMessageHelper {

    private static AVIMClient instance;
    private static boolean hasOpen;
    private static boolean isOpening;

    public static AVIMClient getInstance() {
        if (instance == null) {
            if (User.getCurrentUser() == null) {
                instance = null;
            } else {
                instance = AVIMClient.getInstance(String.valueOf(User.getCurrentUser().getUserId()));
                AVIMClient.setTimeoutInSecs(10);
            }
        }
        return instance;
    }

    /**
     * 开启客户端
     */
    public static void openImClient() {
        if (isOpening||getInstance() == null) {
            return;
        }
        if (!hasOpen) {
            isOpening = true;
            getInstance().open(new AVIMClientCallback() {
                @Override
                public void done(AVIMClient avimClient, AVIMException e) {
                    if (e == null) {
                        ToastUtil.showCustomToastInDevelop(App.application, "成功登陆上即时通信服务器");
                        hasOpen = true;
                        HistoryMessageHelper.getHistoryMessage();
                    } else {
                        ToastUtil.showCustomToastInDevelop(App.application, "登陆即时通信服务器失败");
                    }
                    isOpening = false;
                }
            });
        }
    }

    /**
     * 关闭IM客户端
     */
    public static void closeImClient() {
        if (getInstance() == null) {
            return;
        }
        if (hasOpen) {
            getInstance().close(new AVIMClientCallback() {
                @Override
                public void done(AVIMClient avimClient, AVIMException e) {
                    if (e == null) {
                        hasOpen = false;
                        ToastUtil.showCustomToastInDevelop(App.application, "关闭通讯客户端成功");
                        instance = null;
                    } else {
                        ToastUtil.showCustomToastInDevelop(App.application, "关闭通讯客户端失败");
                    }
                }
            });
        }
    }


    /**
     * 从服务器获取Conversation
     *
     * @param friendId
     * @param onGetConversation
     */
    protected static void getConversationFromServer(final long friendId, final OnGetConversation onGetConversation) {
        //从服务器获取conversation
        ConversationManager.getInstance().getConversationBetween(User.getCurrentUser().getUserId(), friendId, new Response.Listener<ListConversationVo>() {
            @Override
            public void onResponse(ListConversationVo listConversationVo) {
                onGetConversation.onGet(MessageHelperV2.getInstance().getConversation(listConversationVo.getLeanCloudConversationId()));
            }
        }, new NetErrorListener() {
            @Override
            public void onError(ErrorMessage msg) {
                MessageHelperV2.createConversation(friendId, getAVIMConversationCreatedCallback(onGetConversation, friendId));
            }
        });
    }


    /**
     * 创建对话
     *
     * @param friendId
     * @param callback
     */
    public static void createConversation(long friendId, AVIMConversationCreatedCallback callback) {
        List<String> clientIds = new ArrayList<String>();
        clientIds.add(String.valueOf(friendId));
        getInstance().createConversation(clientIds, null, callback);
    }
    /**
     * 获取创建会话的回调
     * @param onGetConversation
     * @param friendId
     * @return
     */
    @NonNull
    protected static AVIMConversationCreatedCallback getAVIMConversationCreatedCallback(final OnGetConversation onGetConversation, final long friendId) {
        return new AVIMConversationCreatedCallback() {
            @Override
            public void done(AVIMConversation avimConversation, AVIMException e) {
                if (e==null) {
                    ConversationManager.getInstance().getInstance().createConversation(User.getCurrentUser().getUserId(),
                            friendId, avimConversation.getConversationId(), new Response.Listener<ListConversationVo>() {
                                @Override
                                public void onResponse(ListConversationVo listConversationVo) {
                                    inserConversation(listConversationVo);
                                }
                            }, new NetErrorListener() {
                                @Override
                                public void onError(ErrorMessage msg) {

                                }
                            });
                }
                onGetConversation.onGet(avimConversation);
            }
        };
    }

    private static void inserConversation(ListConversationVo listConversationVo) {
        com.anniday.model.db.User mainUser = new com.anniday.model.db.User(listConversationVo.getMainUserId(),
                listConversationVo.getMainUserName(),listConversationVo.getMainUserAvatarUrl());
        com.anniday.model.db.User customUser = new com.anniday.model.db.User(listConversationVo.getCustomUserId(),
                listConversationVo.getCustomUserName(),listConversationVo.getCustomUserAvatarUrl());
        mainUser.setCreateAt(System.currentTimeMillis());
        customUser.setCreateAt(System.currentTimeMillis());
        Conversation conversation = new Conversation();
        BeanUtils.copyProperties(listConversationVo, conversation);
        App.application.daoSession.getUserDao().insert(mainUser);
        App.application.daoSession.getUserDao().insert(customUser);
        App.application.daoSession.getConversationDao().insertOrReplace(conversation);
    }

    /**
     * 获取该会话中信息的目的地（接受者）
     *
     * @param conversation      会话
     * @param sourceIdOfMessage 信息的来源
     * @return 接受者的id
     */
    protected static String searchDestinationOfMessage(AVIMConversation conversation, String sourceIdOfMessage) {
        for (String member : conversation.getMembers()) {
            if (!member.equals(sourceIdOfMessage)) {
                return member;
            }
        }
        return null;
    }

    /**
     * 获取Conversation(不包含被黑名单的）
     *  @param friendId
     * @param onGetConversation
     */
    public static void getAvImConversationNotInBlackList(final long friendId, final OnGetConversation onGetConversation) {
        UserManager.getInstance().saveUser(Long.valueOf(friendId));

        if (onGetConversation == null) {
            return;
        }
        final long myId = User.getCurrentUser().getUserId();
        Observable.create(new Observable.OnSubscribe<Conversation>() {
            @Override
            public void call(Subscriber<? super Conversation> subscriber) {
                Conversation conversation = queryConversation(friendId, myId);
                if (conversation != null) {
                    subscriber.onNext(conversation);
                } else {
                    subscriber.onError(new Throwable());
                }
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<Conversation>() {
                    @Override
                    public void call(Conversation conversation) {
                        //判断是否在黑名单中
                        if (isInBlackList(conversation, myId)) {
                            onGetConversation.onGet(null);
                        } else {
                            onGetConversation.onGet(getInstance().getConversation(conversation.getLeanCloudConversationId()));
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        getConversationFromServer(friendId, onGetConversation);
                    }
                });
    }

    private static boolean isInBlackList(Conversation conversation, long myId) {
        return conversation.getMainUserId().equals(myId) && conversation.getMainIsInBlackList()
                || conversation.getCustomUserId().equals(myId) && conversation.getCustomIsInBlackList();
    }

    /**
     * 查询Conversation
     * @param friendId
     * @param myId
     * @return
     */
    private static Conversation queryConversation(long friendId, long myId) {

        WhereCondition condition1 = ConversationDao.Properties.MainUserId.eq(friendId);
        WhereCondition condition2 = ConversationDao.Properties.CustomUserId.eq(myId);

        WhereCondition condition3 = ConversationDao.Properties.CustomUserId.eq(friendId);
        WhereCondition condition4 = ConversationDao.Properties.MainUserId.eq(myId);

        QueryBuilder<Conversation> queryBuilder =
                App.application.daoSession.getConversationDao().queryBuilder();
        WhereCondition and1 = queryBuilder.and(condition1, condition2);
        WhereCondition and2 = queryBuilder.and(condition3, condition4);

        queryBuilder.whereOr(and1, and2);
        return queryBuilder.unique();
    }

    /**
     * 获取历史Conversation（包含被黑名单的）
     *  @param friendId
     * @param onGetConversation
     */
    public static void getHistoryAvimConversation(final long friendId, final OnGetConversation onGetConversation) {
        UserManager.getInstance().saveUser(Long.valueOf(friendId));
        if (onGetConversation == null) {
            return;
        }
        final long myId = User.getCurrentUser().getUserId();
        Observable.create(new Observable.OnSubscribe<Conversation>() {
            @Override
            public void call(Subscriber<? super Conversation> subscriber) {
                Conversation conversation = queryConversation(friendId, myId);
                if (conversation != null) {
                    subscriber.onNext(conversation);
                } else {
                    subscriber.onError(new Throwable());
                }
            }
        }).subscribeOn(Schedulers.io()).subscribe(new Action1<Conversation>() {
            @Override
            public void call(Conversation conversation) {
                onGetConversation.onGet(getInstance().getConversation(conversation.getLeanCloudConversationId()));
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
                getConversationFromServer(friendId, onGetConversation);
            }
        });

    }


    /**
     * 获取到会话的回调
     */
    public interface OnGetConversation {
        void onGet(AVIMConversation conversation);
    }
}
