package com.anniday.model.leancloud.helper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.anniday.app.ConsTants;
import com.anniday.utils.LogUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Created by Administrator on 2015/5/19.
 */
public class PushReceiver extends BroadcastReceiver {
    public static final String likeAction = "com.conner.like";

    @Override
    public void onReceive(final Context context, final Intent intent) {
        LogUtil.e("Get Broadcat");
        try {
            String action = intent.getAction();
            LogUtil.e(action);
            if (likeAction.equals(action)) {

                //获取消息内容
                final JSONObject json = new JSONObject(intent.getExtras().getString("com.avos.avoscloud.Data"));


                Iterator itr = json.keys();
                while (itr.hasNext()) {
                    String key = (String) itr.next();
                    LogUtil.e("..." + key + " => " + json.getString(key));
                }

                if (json != null) {
                    final Long infoId = json.getLong(ConsTants.NOTIFY_INFO_ID);
                    final String userId = json.getString(ConsTants.NOTIFY_USER_ID);
                    final String timestamp = json.getString(ConsTants.NOTIFY_TIME);
//                    if (userId != null && !userId.equals(User.getCurrentUser().getObjectId().toString())) {
//                        UserHelper.getUser(Long.valueOf(userId)).subscribe(new Action1<User>() {
//                            @Override
//                            public void call(User user) {
//                                Intent intent1 = new Intent(context, ShowSingleInfo.class);
//                                intent1.putExtra(ShowSingleInfo.INFO_ID,infoId);
//                                String content = context.getString(R.string.notify_like);
//                                if (user.getUsername() != null) {
//                                    content = StringUtils.replace(content, context.getString(R.string.notify_like_pre), user.getUsername());
//                                } else {
//                                    content = StringUtils.replace(content, context.getString(R.string.notify_like_pre), context.getString(R.string.notify_like_username_default));
//                                }
//                                NotificationUtil.showNotificationWithActivityIntent(context, R.mipmap.ic_launcher, content, content, intent1, ConsTants.MESSAGE_NOTIFY);
//
//                                UserHelper.saveUserToDb(user);
//                            }
//                        }, new Action1<Throwable>() {
//                            @Override
//                            public void call(Throwable throwable) {
//                            }
//                        });
//                    }
                }
            }
        } catch (JSONException e) {
            LogUtil.e("JSONException: " + e.getMessage());
        }
    }
}
