package com.anniday.model.leancloud.helper;

import com.anniday.app.ConsTants;
import com.anniday.model.leancloud.base.BaseBeanHelper;
import com.avos.avoscloud.AVException;
import com.avos.avoscloud.AVOSCloud;


import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

/**
 * 短信助手
 *
 * @author Administrator
 */
public class SmsHelper extends BaseBeanHelper {
    /**
     * 获取短信验证码
     *
     * @param phoneNumber
     * @param opName
     * @throws AVException
     */
    public static Observable getSmsCode(final String phoneNumber, final String opName) {
        return Observable.create(new Observable.OnSubscribe<Object>() {
            @Override
            public void call(Subscriber<? super Object> subscriber) {
                try {
                    AVOSCloud.requestSMSCode(phoneNumber, ConsTants.APP_NAME, opName, 10);
                    subscriber.onNext(null);
                } catch (AVException e) {
                    e.printStackTrace();
                    Throwable throwable = new Throwable(e.getMessage());
                    subscriber.onError(throwable);
                } finally {
                    subscriber.onCompleted();
                }
            }
        }).subscribeOn(Schedulers.io());
    }

    /**
     * 验证SMSCode
     *
     * @param smsCode
     * @param phoneNumber
     * @return
     */
    public static Observable<Object> verifySMSCode(final String smsCode, final String phoneNumber) {
        return Observable.create(new Observable.OnSubscribe<Object>() {
            @Override
            public void call(Subscriber<? super Object> subscriber) {
                try {
                    AVOSCloud.verifyCode(smsCode, phoneNumber);
                    subscriber.onNext(null);
                } catch (AVException e) {
                    e.printStackTrace();
                    Throwable throwable = new Throwable(e.getMessage());
                    subscriber.onError(throwable);
                }
            }
        }).subscribeOn(Schedulers.io());
    }

}
