package com.anniday.model.leancloud.base;

import android.content.Context;

import com.anniday.model.leancloud.helper.ChatEventHanlder;
import com.avos.avoscloud.AVOSCloud;
import com.avos.avoscloud.im.v2.AVIMClient;
import com.avos.avoscloud.im.v2.AVIMMessageManager;
import com.avos.avoscloud.im.v2.AVIMTypedMessage;

public class BaseLeanCloud {
    public static boolean hasInit;

    public synchronized static void init(Context application) {
        if (hasInit) {
            return;
        }
        /** leanCloud的appID */
        String APP_ID = "m30XnAoahssRWpgROx6w03j6-gzGzoHsz";
        /** leanCloud的appKey */
        String APP_KEY = "MQGDsuGDNz9xzANR869n2qWS";
        AVOSCloud.initialize(application, APP_ID, APP_KEY);

        // 设置事件响应接口
        AVIMClient.setClientEventHandler(new ChatEventHanlder.CustomNetworkHandler());
        AVIMMessageManager.setConversationEventHandler(new ChatEventHanlder.CustomConversationHandler());
        AVIMMessageManager.registerMessageHandler(AVIMTypedMessage.class, new ChatEventHanlder.MsgHandler());
        hasInit = true;
    }
}
