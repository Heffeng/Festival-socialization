package com.anniday.model.leancloud.base;

import com.avos.avoscloud.AVException;
import com.avos.avoscloud.AVFile;
import com.avos.avoscloud.AVObject;

import java.util.HashMap;
import java.util.Map.Entry;

public class BaseBeanHelper {
    protected static void finish(BaseCallBack callBack, Exception e,
                                 Object result) {
        if (callBack != null) {
            if (e != null && (e instanceof AVException)) {
                callBack.onFinished(false, ((AVException) e).getCode(), result);
            } else {
                callBack.onFinished(true,
                        BaseCallBack.SUCESS_CODE, result);
            }
        }
    }

    /**
     * 保存文件之后保存对象 在上传完文件后save
     *
     * @param avFiles 要设置的文件
     * @throws AVException
     */
    public static void saveAfterUploaded(AVObject avObject, HashMap<String, AVFile> avFiles)
            throws AVException {
        if (avFiles != null) {
            for (Entry<String, AVFile> item : avFiles.entrySet()) {
                avObject.put(item.getKey(), item.getValue());
            }
        }
        avObject.save();
    }

}
