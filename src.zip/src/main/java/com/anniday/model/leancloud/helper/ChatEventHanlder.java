package com.anniday.model.leancloud.helper;

import android.content.Intent;
import android.text.TextUtils;

import com.android.volley.Response;
import com.anniday.R;
import com.anniday.activity.ChatActivity;
import com.anniday.app.App;
import com.anniday.app.ConsTants;
import com.anniday.model.db.Conversation;
import com.anniday.model.db.Session;
import com.anniday.model.db.dao.DBConstans;
import com.anniday.model.db.dao.ConversationDao;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.model.service.User;
import com.anniday.model.service.UserManager;
import com.anniday.utils.BeanUtils;
import com.anniday.utils.CommonUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.NotificationUtil;
import com.anniday.utils.ToastUtil;
import com.avos.avoscloud.im.v2.AVIMClient;
import com.avos.avoscloud.im.v2.AVIMClientEventHandler;
import com.avos.avoscloud.im.v2.AVIMConversation;
import com.avos.avoscloud.im.v2.AVIMConversationEventHandler;
import com.avos.avoscloud.im.v2.AVIMTypedMessage;
import com.avos.avoscloud.im.v2.AVIMTypedMessageHandler;
import com.avos.avoscloud.im.v2.messages.AVIMTextMessage;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2015/5/12.
 */
public class ChatEventHanlder {
    public static boolean isConnected = true;

    // 处理网络状态变化事件
    public static class CustomNetworkHandler extends AVIMClientEventHandler {
        @Override
        public void onConnectionPaused(AVIMClient client) {
            // 请按自己需求改写
            isConnected = false;
            LogUtil.e("connect paused");
//            if (App.application.sessionDaoImp != null) {
//                App.application.sessionDaoImp.updateToSentFailed();
//            }
            ToastUtil.showCustomToastInRelease(App.application, App.application.getString(R.string.im_connection_pause));
        }

        @Override
        public void onConnectionResume(AVIMClient client) {
            // 请按自己需求改写
            isConnected = true;
            LogUtil.e("connect resume");
//            if (App.application.sessionDaoImp != null) {
//                App.application.sessionDaoImp.updateToSentFailed();
//            }
            ToastUtil.showCustomToastInRelease(App.application, App.application.getString(R.string.im_connection_resume));
        }

        @Override
        public void onClientOffline(AVIMClient avimClient, int i) {

        }
    }

    // 处理对话成员变化事件
    public static class CustomConversationHandler extends AVIMConversationEventHandler {

        @Override
        public void onMemberLeft(AVIMClient client, AVIMConversation conversation, List<String> members, String kickedBy) {
        }

        @Override
        public void onMemberJoined(AVIMClient client, AVIMConversation conversation, List<String> members, String invitedBy) {
        }

        @Override
        public void onKicked(AVIMClient client, AVIMConversation conversation, String kickedBy) {
        }

        @Override
        public void onInvited(AVIMClient client, AVIMConversation conversation, String operator) {
        }
    }


    public static class MsgHandler extends AVIMTypedMessageHandler<AVIMTypedMessage> {

        /**
         * 插入会话
         *
         * @param avimConversation
         */
        private static void insertConversationIntoDB(AVIMConversation avimConversation) {
            Conversation conversation = App.application.daoSession.getConversationDao()
                    .queryBuilder().where(ConversationDao.Properties.LeanCloudConversationId.eq(avimConversation.getConversationId()))
                    .unique();
            if (conversation == null) {
                conversation = new Conversation(null,Long.valueOf(avimConversation.getCreator()),User.getCurrentUser().getUserId(),false,
                        false,avimConversation.getConversationId());
                App.application.daoSession.getConversationDao().insert(conversation);
            }
        }

        /**
         * 获取该会话中信息的目的地（接受者）
         *
         * @param conversation      会话
         * @param sourceIdOfMessage 信息的来源
         * @return 接受者的id
         */
        private static String searchDestinationOfMessage(AVIMConversation conversation, String sourceIdOfMessage) {
            for (String member : conversation.getMembers()) {
                if (!member.equals(sourceIdOfMessage)) {
                    return member;
                }
            }
            return null;
        }

        @Override
        public void onMessage(AVIMTypedMessage message,final AVIMConversation avimConversation, AVIMClient client) {
            // 请按自己需求改写
            if (App.application.daoSession==null){
                App.application.initSession();
            }
            switch (message.getMessageType()) {
                case -1:
                    AVIMTextMessage textMsg = (AVIMTextMessage) message;
                    final  Map<String, Object> pamas = textMsg.getAttrs();
                    final Session session = new Session();
                    session.setSessionId(pamas.get(DBConstans.SESSION_ID).toString());
                    session.setMessageId(textMsg.getMessageId());
                    session.setIsSent(DBConstans.SENT);
                    session.setType(pamas.get(DBConstans.TYPE).toString());
                    session.setTimestamp(new Date(textMsg.getTimestamp()));
                    setFromAndTo(avimConversation, session, textMsg);
                    session.setIsReaded(false);
                    session.setText(textMsg.getText());

                    insertConversationIntoDB(avimConversation);
                    switch (session.getType()) {
                        case DBConstans.PIC_AUDIO:
                            session.setPic(pamas.get(DBConstans.PIC).toString());
                            session.setAudio(pamas.get(DBConstans.AUDIO).toString());
                            session.setAudioDuration(pamas.get(DBConstans.AUDIODURATION).toString());
                            break;
                        case DBConstans.PIC:
                            session.setPic(pamas.get(DBConstans.PIC).toString());
                            break;
                        case DBConstans.AUDIO:
                            session.setAudio(pamas.get(DBConstans.AUDIO).toString());
                            session.setAudioDuration(pamas.get(DBConstans.AUDIODURATION).toString());
                            break;
                        case DBConstans.BLACK_LIST:
                            addToBlackList(avimConversation);
                            return;
                    }
                    App.application.daoSession.getSessionDao().insertOrReplace(session);
                    showNotify(session);
                    break;
            }
        }

        /**
         * 将自己加入到该会话的黑名单中
         *
         * @param avimConversation
         */
        private void addToBlackList(AVIMConversation avimConversation) {
            Conversation conversation = App.application.daoSession.getConversationDao()
                    .queryBuilder().where(ConversationDao.Properties.LeanCloudConversationId.eq(avimConversation.getConversationId()))
                    .unique();
            if (conversation == null) {
                conversation = new Conversation(null, Long.valueOf(avimConversation.getCreator()), User.getCurrentUser().getUserId(), false,
                        false, avimConversation.getConversationId());

            }
            if (conversation.getMainUserId().equals(User.getCurrentUser().getUserId())) {
                conversation.setMainIsInBlackList(true);
            } else {
                conversation.setCustomIsInBlackList(true);
            }
            App.application.daoSession.getConversationDao().insertOrReplace(conversation);
        }

        /**
         * 设置from和to的userId
         *
         * @param conversation
         * @param session
         * @param avimTypedMessage
         */
        private void setFromAndTo(AVIMConversation conversation, Session session, AVIMTypedMessage avimTypedMessage) {
            session.setFromUserId(avimTypedMessage.getFrom());
            session.setToUserId(searchDestinationOfMessage(conversation, session.getFromUserId()));
            if (session.getFromUserId().equals(String.valueOf(User.getCurrentUser().getUserId()))) {
                session.setSessionName( session.getToUserId());
            } else {
                session.setSessionName(session.getFromUserId());
            }
        }

        /**
         * 显示通知
         *
         * @param session
         */
        private void showNotify(final Session session) {
            com.anniday.model.db.User user = App.application.daoSession.getUserDao().load(Long.valueOf(session.getFromUserId()));
            if (user == null) {
                UserManager.getInstance().getUserById(Long.parseLong(session.getFromUserId()), new Response.Listener<User>() {
                    @Override
                    public void onResponse(User user1) {
                        com.anniday.model.db.User user2 = new com.anniday.model.db.User();
                        App.application.daoSession.getUserDao().insertOrReplace(user2);
                        BeanUtils.copyProperties(user1,user2);
                        MsgHandler.this.notify(user2.getNickname(), session);
                    }
                }, null);
            } else {
                MsgHandler.this.notify(user.getNickname(), session);
            }
        }

        /**
         * @param name     用户名字
         * @param session
         */
        private void notify(String name, Session session) {
            if (!String.valueOf(User.getCurrentUser().getUserId()).equals(session.getFromUserId())
                    && !(ChatActivity.class.getName().equals(CommonUtil.getTopActivityClassName(App.application))
                    && session.getFromUserId().equals(ChatActivity.userId))) {
                String content = "";
                switch (session.getType()) {
                    case DBConstans.TEXT:
                        content = session.getText();
                        break;
                    case DBConstans.AUDIO:
                        content = App.application.getString(R.string.session_audio_notice);
                        break;
                    case DBConstans.PIC:
                        content = App.application.getString(R.string.session_pic_notice);
                        break;
                    case DBConstans.PIC_AUDIO:
                        content = App.application.getString(R.string.session_pic_audio_notice);
                        break;
                }
                Intent intent = new Intent(App.application, ChatActivity.class);
                intent.putExtra(ChatActivity.USER_ID_IN_LONG, Long.valueOf(session.getFromUserId()));
                String title = "";
                if (TextUtils.isEmpty(name)) {
                    title = App.application.getString(R.string.on_message_notify_title);
                } else {
                    title = App.application.getString(R.string.on_message_notify_pre) + name + App.application.getString(R.string.on_message_notify_back);
                }
                NotificationUtil.showNotificationWithActivityIntent(App.application, R.mipmap.ic_launcher, title, content, intent, ConsTants.MESSAGE_NOTIFY);
            }
        }

        @Override
        public void onMessageReceipt(AVIMTypedMessage message, AVIMConversation conversation, AVIMClient client) {
            // 请加入你自己需要的逻辑...
        }
    }

}
