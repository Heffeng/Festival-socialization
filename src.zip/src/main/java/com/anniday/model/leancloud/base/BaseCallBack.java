package com.anniday.model.leancloud.base;

/**
 * 参数为bool值得callback
 *
 * @author Administrator
 */
public class BaseCallBack {
    public static int SUCESS_CODE = 6666;
    public static int FAILED_CODE = 7777;

    /**
     * 开始之前的回调
     */
    public void onPreRun() {
    }

    /**
     * 完成的回调
     *
     * @param isSucess
     * @param code
     * @param result
     */
    public void onFinished(boolean isSucess, int code, Object result) {
    }
}
