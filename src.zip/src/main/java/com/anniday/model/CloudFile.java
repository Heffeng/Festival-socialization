package com.anniday.model;

/**
 * Created by HuangChun on 2016/3/3.
 */
public class CloudFile {
    private String objectKey;
    private String fileUrl;
    private String meta;
    private String bucketName;

    public CloudFile() {
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getMeta() {
        return meta;
    }

    public void setMeta(String meta) {
        this.meta = meta;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public CloudFile(String fileUrl, String meta, String bucketName, String objectKey) {
        this.fileUrl = fileUrl;
        this.meta = meta;
        this.bucketName = bucketName;
        this.objectKey = objectKey;
    }
}
