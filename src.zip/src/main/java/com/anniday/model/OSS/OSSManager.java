package com.anniday.model.OSS;

import android.content.Context;

import com.alibaba.sdk.android.oss.ClientConfiguration;
import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.OSSClient;

import com.alibaba.sdk.android.oss.ServiceException;
import com.alibaba.sdk.android.oss.callback.OSSCompletedCallback;
import com.alibaba.sdk.android.oss.callback.OSSProgressCallback;
import com.alibaba.sdk.android.oss.common.auth.OSSCredentialProvider;
import com.alibaba.sdk.android.oss.common.auth.OSSPlainTextAKSKCredentialProvider;
import com.alibaba.sdk.android.oss.common.utils.BinaryUtil;
import com.alibaba.sdk.android.oss.internal.OSSAsyncTask;
import com.alibaba.sdk.android.oss.model.ObjectMetadata;
import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;
import com.anniday.model.CloudFile;
import com.anniday.utils.FilenameUtil;
import com.anniday.utils.LogUtil;
import com.anniday.utils.ToastUtil;
import com.anniday.widgets.TitleBar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Created by HuangChun on 2016/3/3.
 */
public class OSSManager {
    private static String accessKey = "CtkHyHD2nmiCUdrZ";
    private static String bucketName = "andeper";
    private static String sercretKey = "DkNGRfHjAAZEfJQ4zCJvOr3k24LahD";
    private static String endpoint = "oss-cn-shanghai.aliyuncs.com";
    private static OSS oss;
    public static void init(Context context){
        OSSCredentialProvider ossCredentialProvider = new OSSPlainTextAKSKCredentialProvider(accessKey,sercretKey);
        ClientConfiguration conf = new ClientConfiguration();
        conf.setConnectionTimeout(15 * 1000); // 连接超时，默认15秒
        conf.setSocketTimeout(15 * 1000); // socket超时，默认15秒
        conf.setMaxConcurrentRequest(5); // 最大并发请求书，默认5个
        conf.setMaxErrorRetry(2); // 失败后最大重试次数，默认2;
        oss = new OSSClient(context,endpoint,ossCredentialProvider,conf);
    }
    public static void uploadFile(String path ,final OSSManager.SaveCallback saveCallback) throws IOException {
        final String filename = FilenameUtil.getFileName(path);
        final PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,filename,path);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentMD5(BinaryUtil.calculateBase64Md5(path));
        metadata.setContentType("application/octet-stream");
        putObjectRequest.setMetadata(metadata);
        putObjectRequest.setProgressCallback(new OSSProgressCallback<PutObjectRequest>() {
            @Override
            public void onProgress(PutObjectRequest putObjectRequest, long currentSize, long totalSize) {
                //LogUtil.e("currentSize: " + currentSize + " totalSize: " + totalSize);
                saveCallback.onProgress(filename,currentSize,totalSize);
            }
        });
        OSSAsyncTask task = oss.asyncPutObject(putObjectRequest, new OSSCompletedCallback<PutObjectRequest, PutObjectResult>() {
            @Override
            public void onSuccess(PutObjectRequest putObjectRequest, PutObjectResult putObjectResult) {
                LogUtil.e("UploadSuccess");
                LogUtil.e(putObjectResult.getETag());
                LogUtil.e(putObjectResult.getRequestId());
                String url = "http://" + bucketName + "." + endpoint + "/" + filename;
                CloudFile cloudFile = new CloudFile();
                cloudFile.setFileUrl(url);
                cloudFile.setBucketName(bucketName);
                cloudFile.setObjectKey(filename);
                LogUtil.e("1");
                saveCallback.onSuccess(cloudFile);
            }

            @Override
            public void onFailure(PutObjectRequest putObjectRequest, ClientException clientExcepion, ServiceException serviceException) {
                if (clientExcepion != null) {
                    // 本地异常如网络异常等
                    clientExcepion.printStackTrace();
                }
                if (serviceException != null) {
                    // 服务异常
                    LogUtil.e(serviceException.getErrorCode());
                    LogUtil.e(serviceException.getRequestId());
                    LogUtil.e(serviceException.getHostId());
                    LogUtil.e(serviceException.getRawMessage());
                }
                saveCallback.onFailure(clientExcepion,serviceException);

            }
        });
    }

    public static CloudFile uploadFile(String path) throws IOException {
        final String filename = FilenameUtil.getFileName(path);
        final PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,filename,path);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentMD5(BinaryUtil.calculateBase64Md5(path));
        metadata.setContentType("application/octet-stream");
        putObjectRequest.setMetadata(metadata);

        try {
            PutObjectResult task = oss.putObject(putObjectRequest);
            String url = "http://" + bucketName + "." + endpoint + "/" + filename;
            CloudFile cloudFile = new CloudFile();
            cloudFile.setFileUrl(url);
            cloudFile.setBucketName(bucketName);
            cloudFile.setObjectKey(filename);
            return cloudFile;
        } catch (ClientException e) {
            e.printStackTrace();
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        return null;
    }



    public interface SaveCallback {
        void onSuccess(CloudFile cloudFile);

        void onProgress(String objectKey, long byteCount, long totalSize);

        void onFailure(ClientException clientExcepion, ServiceException serviceException);
    }
}
