package com.anniday.model;

/**
 * Created by HuangChun on 2016/3/27.
 */
public class LikeModel {
    public Long userId;
    public Long storyId;
    public Long createAt;
    public Long likeId;

    public LikeModel() {
    }

    public LikeModel(Long userId, Long storyId, Long createAt, Long likeId) {
        this.userId = userId;
        this.storyId = storyId;
        this.createAt = createAt;
        this.likeId = likeId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getStoryId() {
        return storyId;
    }

    public void setStoryId(Long storyId) {
        this.storyId = storyId;
    }

    public Long getLikeId() {
        return likeId;
    }

    public void setLikeId(Long likeId) {
        this.likeId = likeId;
    }

    public Long getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Long createAt) {
        this.createAt = createAt;
    }
}
