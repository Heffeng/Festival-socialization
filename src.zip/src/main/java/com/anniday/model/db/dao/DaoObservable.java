package com.anniday.model.db.dao;

import java.util.Map;
import java.util.Observable;

public class DaoObservable extends Observable {
    /**
     * 通知数据发生变化
     *
     * @param change
     */
    public void notifyChange(Map<String, Object> change) {
        setChanged();
        notifyObservers(change);
    }
}
