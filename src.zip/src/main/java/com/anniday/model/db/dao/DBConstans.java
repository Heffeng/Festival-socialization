package com.anniday.model.db.dao;

public interface DBConstans {
    /*************
     * 公共
     **************/

    String ID = "_id";

    /*************
     * user
     **************/
    String USER = "user";

    String USERNAME = "username";
    String AVATERURL = "avaterUrl";
    String SMALLAVATERURL = "smallAvaterUrl";
    String PHONENUMBER = "phoneNumber";

    /**************
     * session
     **************/
    String SESSION = "session";
    String SESSION_ID = "sessionId";

    String FROMUSERID = "fromUserId";
    String TOUSERID = "toUserId";
    String SESSIONNAME = "sessionName";
    String TYPE = "type";
    String TIMESTAMP = "timestamp";

    String ISREADED = "isReaded";
    String ISSENT = "isSent";
    String INFOID = "infoId";
    String LOCATION_ID = "locationId";


    String TEXT = "text";
    String AUDIO = "audio";
    String PIC = "pic";
    String PIC_AUDIO = "pic_audio";
    String BLACK_LIST = "blackList";


    Integer SENTING = 1;
    Integer  SENT = 2;
    Integer SENT_FAILED = 3;

    String TRUE = "true";
    String FALSE = "false";

    String PICPATH = "picPath";
    String AUDIOPATH = "audioPath";
    String AUDIODURATION = "audioDuration";


}
