package com.anniday.model;

/**
 * Created by HuangChun on 2016/3/31.
 */
public class CommentModel {
    public Long fromUserId;
    public Long toUserId;
    public String fromUserName;
    public String toUserName;
    public String fromUserAvatar;
    public String comment;
    public Long createAt;



    public Long commentId;

    public CommentModel(Long fromUserId, Long createAt, String comment, String fromUserAvatar, String toUserName, Long toUserId, String fromUserName) {
        this.fromUserId = fromUserId;
        this.createAt = createAt;
        this.comment = comment;
        this.fromUserAvatar = fromUserAvatar;
        this.toUserName = toUserName;
        this.toUserId = toUserId;
        this.fromUserName = fromUserName;
    }

    public CommentModel(Long commentId) {
        this.commentId = commentId;
    }

    public Long getFromUserId() {
        return fromUserId;
    }

    public void setFromUserId(Long fromUserId) {
        this.fromUserId = fromUserId;
    }

    public Long getToUserId() {
        return toUserId;
    }

    public void setToUserId(Long toUserId) {
        this.toUserId = toUserId;
    }

    public String getFromUserName() {
        return fromUserName;
    }

    public void setFromUserName(String fromUserName) {
        this.fromUserName = fromUserName;
    }

    public String getToUserName() {
        return toUserName;
    }

    public void setToUserName(String toUserName) {
        this.toUserName = toUserName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Long getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Long createAt) {
        this.createAt = createAt;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public String getFromUserAvatar() {
        return fromUserAvatar;
    }

    public void setFromUserAvatar(String fromUserAvatar) {
        this.fromUserAvatar = fromUserAvatar;
    }
}
