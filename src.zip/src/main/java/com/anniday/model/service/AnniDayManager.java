package com.anniday.model.service;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.utils.NetworkUtil;
import com.google.gson.reflect.TypeToken;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by VeyHey on 2016/3/28.
 */
public class AnniDayManager {
    private static AnniDayManager ourInstance = new AnniDayManager();

    public static AnniDayManager getInstance() {
        return ourInstance;
    }

    private AnniDayManager() {
    }

    public void getHotAnniDayByName(String key, int page, int num, Response.Listener<List<HotAnniDay>> listener, NetErrorListener errorListener){
        Map<String,String> map = new HashMap<>();
        map.put("key",key);
        map.put("page", String.valueOf(page));
        map.put("num", String.valueOf(num));
        GsonRequest gsonRequest = new GsonRequest(URLConstant.GET_HOT_ANNIDAYS_BY_NAME,map,new TypeToken<List<HotAnniDay>>(){}.getType(),listener,
                errorListener);
        NetworkUtil.getInstance().addTask(gsonRequest);
    }

    public void list(int page, int num, Response.Listener<List<Topic>> listener, NetErrorListener errorListener){
        Map<String,String> map = new HashMap<>();
        map.put("page", String.valueOf(page));
        map.put("num", String.valueOf(num));
        GsonRequest gsonRequest = new GsonRequest(URLConstant.LIST_TOPICS,map,new TypeToken<List<Topic>>(){}.getType(),listener,
                errorListener);
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
