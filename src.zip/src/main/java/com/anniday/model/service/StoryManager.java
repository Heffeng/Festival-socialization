package com.anniday.model.service;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.db.Story;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.utils.NetworkUtil;
import com.google.gson.reflect.TypeToken;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by VeyHey on 2016/4/2.
 */
public class StoryManager {
    private static StoryManager ourInstance = new StoryManager();

    public static StoryManager getInstance() {
        return ourInstance;
    }

    private StoryManager() {
    }

    public void getStorysByAnniDayId(long anniDayId,int page, int num, Response.Listener<List<Story>> listener, NetErrorListener errorListener){
        Map<String,String> map = new HashMap<>();
        map.put("anniDayId", String.valueOf(anniDayId));
        map.put("userId", String.valueOf(User.getCurrentUser().getUserId()));
        map.put("page", String.valueOf(page));
        map.put("num", String.valueOf(num));
        GsonRequest gsonRequest = new GsonRequest(URLConstant.GET_STORY_BY_ANNIDAY,map,new TypeToken<List<Story>>(){}.getType(),listener,
                errorListener);
        NetworkUtil.getInstance().addTask(gsonRequest);
    }

    public void getStorysByUserId(long userId ,int page, int num, Response.Listener<List<Story>> listener, NetErrorListener errorListener){
        Map<String,String> map = new HashMap<>();
        map.put("userId", String.valueOf(User.getCurrentUser().getUserId()));
        map.put("targetUserId", String.valueOf(userId));
        map.put("page", String.valueOf(page));
        map.put("num", String.valueOf(num));
        GsonRequest gsonRequest = new GsonRequest(URLConstant.GET_STORY_BY_USER,map,new TypeToken<List<Story>>(){}.getType(),listener,
                errorListener);
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
