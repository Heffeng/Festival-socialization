package com.anniday.model.service;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by VeyHey on 2016/3/28.
 */
public class HotAnniDay implements Parcelable {
    private Long anniDayId;
    private String name;
    private Integer contentNum;
    private String backgroundUrl;
    public Long getAnniDayId() {
        return anniDayId;
    }
    public void setAnniDayId(Long anniDayId) {
        this.anniDayId = anniDayId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getContentNum() {
        return contentNum;
    }
    public void setContentNum(Integer contentNum) {
        this.contentNum = contentNum;
    }
    public String getBackgroundUrl() {
        return backgroundUrl;
    }
    public void setBackgroundUrl(String backgroundUrl) {
        this.backgroundUrl = backgroundUrl;
    }
    public HotAnniDay(Long anniDayId, String name, Integer contentNum, String backgroundUrl) {
        super();
        this.anniDayId = anniDayId;
        this.name = name;
        this.contentNum = contentNum;
        this.backgroundUrl = backgroundUrl;
    }
    @Override
    public String toString() {
        return "HotAnniDay [anniDayId=" + anniDayId + ", name=" + name + ", contentNum=" + contentNum
                + ", backgroundUrl=" + backgroundUrl + "]";
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.anniDayId);
        dest.writeString(this.name);
    }

    protected HotAnniDay(Parcel in) {
        this.anniDayId = (Long) in.readValue(Long.class.getClassLoader());
        this.name = in.readString();
    }

    public static final Parcelable.Creator<HotAnniDay> CREATOR = new Parcelable.Creator<HotAnniDay>() {
        public HotAnniDay createFromParcel(Parcel source) {
            return new HotAnniDay(source);
        }

        public HotAnniDay[] newArray(int size) {
            return new HotAnniDay[size];
        }
    };
}
