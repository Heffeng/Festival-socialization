package com.anniday.model.service;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by HuangChun on 2016/3/2.
 */
public class Topic implements Parcelable {
    private Long anniDayId;
    private String name;
    private Integer seeNum;
    private Integer contentNum;
    private String backgroundUrl;
    private String origin;
    private Long lastUserId;
    private String lastUserName;
    private String lastUserAvaterUrl;

    //最后一位发动态的时间
    private Long lastUserCreateTime;

    public Topic(Long anniDayId, String name, Integer seeNum, Integer contentNum, String backgroundUrl, String origin, Long lastUserId, String lastUserName, String lastUserAvaterUrl, Long lastUserCreateTime) {
        this.anniDayId = anniDayId;
        this.name = name;
        this.seeNum = seeNum;
        this.contentNum = contentNum;
        this.backgroundUrl = backgroundUrl;
        this.origin = origin;
        this.lastUserId = lastUserId;
        this.lastUserName = lastUserName;
        this.lastUserAvaterUrl = lastUserAvaterUrl;
        this.lastUserCreateTime = lastUserCreateTime;
    }

    public Long getAnniDayId() {
        return anniDayId;
    }
    public void setAnniDayId(Long anniDayId) {
        this.anniDayId = anniDayId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getSeeNum() {
        return seeNum;
    }
    public void setSeeNum(Integer seeNum) {
        this.seeNum = seeNum;
    }
    public Integer getContentNum() {
        return contentNum;
    }
    public void setContentNum(Integer contentNum) {
        this.contentNum = contentNum;
    }
    public String getLastUserAvaterUrl() {
        return lastUserAvaterUrl;
    }
    public void setLastUserAvaterUrl(String lastUserAvaterUrl) {
        this.lastUserAvaterUrl = lastUserAvaterUrl;
    }
    public Long getLastUserId() {
        return lastUserId;
    }
    public void setLastUserId(Long lastUserId) {
        this.lastUserId = lastUserId;
    }
    public Long getLastUserCreateTime() {
        return lastUserCreateTime;
    }
    public void setLastUserCreateTime(Long lastUserCreateTime) {
        this.lastUserCreateTime = lastUserCreateTime;
    }
    public String getLastUserName() {
        return lastUserName;
    }
    public void setLastUserName(String lastUserName) {
        this.lastUserName = lastUserName;
    }
    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }
    @Override
    public String toString() {
        return "TopicRespVo [anniDayId=" + anniDayId + ", name=" + name + ", seeNum=" + seeNum + ", contentNum="
                + contentNum + ", lastUserId=" + lastUserId + ", lastUserName=" + lastUserName + ", lastUserAvaterUrl="
                + lastUserAvaterUrl + ", lastUserCreateTime=" + lastUserCreateTime + "]";
    }
    public String getBackgroundUrl() {
        return backgroundUrl;
    }
    public void setBackgroundUrl(String backgroundUrl) {
        this.backgroundUrl = backgroundUrl;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.anniDayId);
        dest.writeString(this.name);
        dest.writeValue(this.seeNum);
        dest.writeValue(this.contentNum);
        dest.writeString(this.backgroundUrl);
        dest.writeString(this.origin);
        dest.writeValue(this.lastUserId);
        dest.writeString(this.lastUserName);
        dest.writeString(this.lastUserAvaterUrl);
        dest.writeValue(this.lastUserCreateTime);
    }

    protected Topic(Parcel in) {
        this.anniDayId = (Long) in.readValue(Long.class.getClassLoader());
        this.name = in.readString();
        this.seeNum = (Integer) in.readValue(Integer.class.getClassLoader());
        this.contentNum = (Integer) in.readValue(Integer.class.getClassLoader());
        this.backgroundUrl = in.readString();
        this.origin = in.readString();
        this.lastUserId = (Long) in.readValue(Long.class.getClassLoader());
        this.lastUserName = in.readString();
        this.lastUserAvaterUrl = in.readString();
        this.lastUserCreateTime = (Long) in.readValue(Long.class.getClassLoader());
    }

    public static final Creator<Topic> CREATOR = new Creator<Topic>() {
        public Topic createFromParcel(Parcel source) {
            return new Topic(source);
        }

        public Topic[] newArray(int size) {
            return new Topic[size];
        }
    };
}
