package com.anniday.model.service;


import com.anniday.model.db.Story;

import java.util.List;

/**
 * Created by HuangChun on 2016/2/28.
 */
public class StoryModel {

    public List<Story> storys;
    public Boolean isClearCache;

    public StoryModel() {
    }

    public StoryModel( List<Story> storys, Boolean isClearCache) {
        this.storys = storys;
        this.isClearCache = isClearCache;
    }

    public Boolean getIsClearCache() {
        return isClearCache;
    }

    public void setIsClearCache(Boolean isClearCache) {
        this.isClearCache = isClearCache;
    }

    public List<Story> getStorys() {
        return storys;
    }

    public void setStorys(List<Story> storys) {
        this.storys = storys;
    }
}
