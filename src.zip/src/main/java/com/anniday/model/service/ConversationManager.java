package com.anniday.model.service;

import com.android.volley.Response;
import com.anniday.app.App;
import com.anniday.constant.URLConstant;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.utils.NetworkUtil;
import com.google.gson.reflect.TypeToken;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by VeyHey on 2016/3/26.
 */
public class ConversationManager {

    private ConversationManager(){}

    public static ConversationManager instance = new ConversationManager();

    public static ConversationManager getInstance(){
        return instance;
    }

    /**
     * 获取某两人之间的会话
     * @param userId
     * @param friendUserId
     * @param listener
     * @param errorListener
     */
    public void getConversationBetween(long userId, long friendUserId, Response.Listener<ListConversationVo> listener, NetErrorListener errorListener){
        Map<String,String> params = new HashMap<>();
        params.put("userId", String.valueOf(userId));
        params.put("friendUserId", String.valueOf(friendUserId));
        GsonRequest<ListConversationVo> request = new GsonRequest<ListConversationVo>(
                URLConstant.GET_CONVERSATION_BETWEEN, params, ListConversationVo.class,listener,errorListener);
        NetworkUtil.getInstance().addTask(request);
    }

    /**
     * 创建会话
     * @param mainUserId
     * @param customUserId
     * @param leanCloudConversationId
     * @param listener
     * @param errorListener
     */
    public void createConversation(long mainUserId,long customUserId,String leanCloudConversationId, Response.Listener<ListConversationVo> listener, NetErrorListener errorListener){
        Map<String,String> params = new HashMap<>();
        params.put("mainUserId", String.valueOf(mainUserId));
        params.put("customUserId", String.valueOf(customUserId));
        params.put("leanCloudConversationId", String.valueOf(leanCloudConversationId));
        GsonRequest<ListConversationVo> request = new GsonRequest<ListConversationVo>(
                URLConstant.CREATE_CONVERSATION, params, ListConversationVo.class,listener,errorListener);
        NetworkUtil.getInstance().addTask(request);
    }


    /**
     * 根据conversationId获取Conversation
     * @param leanCloudConversationId
     * @param listener
     * @param errorListener
     */
    public void getConversationByLeanCloudConversationId(String leanCloudConversationId, Response.Listener<ListConversationVo> listener, NetErrorListener errorListener){
        Map<String,String> params = new HashMap<>();
        params.put("leanCloudConversationId",leanCloudConversationId);
        GsonRequest<ListConversationVo> request = new GsonRequest<ListConversationVo>(
                URLConstant.GET_CONVERSATION_BETWEEN, params, ListConversationVo.class,listener,errorListener);
        NetworkUtil.getInstance().addTask(request);
    }


    /**
     * 获取某人的会话
     * @param userId
     * @param page
     * @param num
     * @param listener
     * @param errorListener
     */
    public void getConversationByUsernId(long userId, int page, int num, Response.Listener<List<ListConversationVo>> listener, NetErrorListener errorListener){
        Map<String,String> params = new HashMap<>();
        params.put("userId", String.valueOf(userId));
        params.put("page", String.valueOf(page));
        params.put("num", String.valueOf(num));
        GsonRequest<List<ListConversationVo>> request = new GsonRequest<List<ListConversationVo>>(
                URLConstant.GET_CONVERSATION_BY_USERID, params, new TypeToken<List<ListConversationVo>>(){}.getType(),listener,errorListener);
        NetworkUtil.getInstance().addTask(request);
    }
}
