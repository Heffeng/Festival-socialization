package com.anniday.model.service;

import com.android.volley.Response;
import com.anniday.constant.URLConstant;
import com.anniday.model.db.HistoryToday;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.utils.NetworkUtil;
import com.google.gson.reflect.TypeToken;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by VeyHey on 2016/3/28.
 */
public class HistoryTodayManager {
    private static HistoryTodayManager ourInstance = new HistoryTodayManager();

    public static HistoryTodayManager getInstance() {
        return ourInstance;
    }

    private HistoryTodayManager() {
    }



    public void todayList(Response.Listener<List<HistoryToday>> listener, NetErrorListener errorListener){
        Map<String,String> map = new HashMap<>();
        GsonRequest gsonRequest = new GsonRequest(URLConstant.HISTORY_TODAY_LIST,map,new TypeToken<List<HistoryToday>>(){}.getType(),listener,
                errorListener);
        NetworkUtil.getInstance().addTask(gsonRequest);
    }
}
