package com.anniday.model.service;

import com.android.volley.Response;
import com.anniday.app.App;
import com.anniday.constant.URLConstant;
import com.anniday.net.GsonRequest;
import com.anniday.net.NetErrorListener;
import com.anniday.utils.BeanUtils;
import com.anniday.utils.CommonUtil;
import com.anniday.utils.NetworkUtil;

import java.util.HashMap;
import java.util.Map;

import rx.functions.Action1;

/**
 * Created by VeyHey on 2016/3/27.
 */
public class UserManager {
    private static UserManager ourInstance = new UserManager();

    public static UserManager getInstance() {
        return ourInstance;
    }

    private UserManager() {
    }

    /**
     * 根据userId获取用户的基本信息
     * @param userId
     * @param listener
     * @param errorListener
     */
    public void getUserById(long userId, Response.Listener<User> listener, NetErrorListener errorListener){
        Map<String,String> params = new HashMap<>();
        params.put("userId", String.valueOf(userId));
        GsonRequest<User> request = new GsonRequest<User>(
                URLConstant.GET_USER_BY_ID, params, User.class,listener,errorListener);
        NetworkUtil.getInstance().addTask(request);
    }

    public void editUser(User user, Response.Listener<User> listener, NetErrorListener errorListener){
        Map<String, String> params = CommonUtil.object2Map(user);
        GsonRequest<User> request = new GsonRequest<User>(
                URLConstant.USER_EDIT, params, User.class,listener,errorListener);
        NetworkUtil.getInstance().addTask(request);
    }

    public  void saveUser(Long userId) {
        com.anniday.model.db.User user = App.application.daoSession.getUserDao().load(userId);
        if (user == null) {
            getUserById(userId, new Response.Listener<User>() {
                @Override
                public void onResponse(User user) {
                    UserManager.this.saveUser(user);
                }
            },null);
        } else {
            if (user.getCreateAt() == null || System.currentTimeMillis() - user.getCreateAt() > 24 * 3600 * 1000) {
                getUserById(userId, new Response.Listener<User>() {
                    @Override
                    public void onResponse(User user) {
                        UserManager.this.saveUser(user);
                    }
                }, null);
            }
        }
    }

    public void saveUser(User user) {
        com.anniday.model.db.User dbUser = new com.anniday.model.db.User();
        BeanUtils.copyProperties(user, dbUser);
        dbUser.setCreateAt(System.currentTimeMillis());
        App.application.daoSession.getUserDao().insertOrReplace(dbUser);
    }
}
