package com.anniday.model.service;

import com.anniday.constant.Constant;


/**
 * Created by mac on 15/5/12.
 */
public class ErrorMessage {

    private int code;
    private String message;

    public ErrorMessage(){}

    public ErrorMessage(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public ErrorMessage(int code)
    {
        this.code=code;

        switch (code)
        {

            case Constant.OBJECT_NOT_FIND:
                this.message="对象未找到";
                break;
            case Constant.QUERY_NO_RESULT:
                this.message="查询无结果";
                break;
            case Constant.REQUEST_NOT_VLIED:
                this.message="请求不合法";
                break;
            case Constant.PHONENUM_OT_PASSWORD_WRONG:
                this.message = "手机号不存在或密码不正确";
                break;
            case Constant.PHONENUM_HASBEEN_REGISTERED:
                this.message = "该手机已被注册";
                break;
            case Constant.ANNIDAY_DOESNOT_EXIT:
                this.message = "不存在该纪念日";
                break;
            default:
                this.message="网络异常";
        }
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return String.format("[code=%d,message=%s]", code, message);
    }
}
