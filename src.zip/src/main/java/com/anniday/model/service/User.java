package com.anniday.model.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.anniday.app.App;
import com.anniday.utils.SharePreferenceUtil;

/**
 * Created by HuangChun on 2016/2/28.
 */
public class User {
    public static final String CURRENT_USER = "CURRENT_USER";
    private String phoneNum;
    private String password;
    private Long userId;
    private String nickname;
    private String avatarUrl;
    private Long createAt;
    private Boolean gender;
    //个人简介
    private String resume;
    public User(){}
    public User(String phoneNum, String password, long userId, String nickName, String avatarUrl, long createAt) {
        this.phoneNum = phoneNum;
        this.password = password;
        this.userId = userId;
        this.nickname = nickName;
        this.avatarUrl = avatarUrl;
        this.createAt = createAt;
    }

    private static User mCurrentUser;

    public User(long userId) {
        this.userId = userId;
    }


    public static User getCurrentUser() {
        if (mCurrentUser == null) {
            String userJson = SharePreferenceUtil.getString(App.application, CURRENT_USER);
            if (userJson != null) {
                mCurrentUser = JSONObject.parseObject(userJson, User.class);
            }
        }
        return mCurrentUser;
    }
    public static void saveCurrentUser(User currentUser){
        mCurrentUser = currentUser;
        if (mCurrentUser!=null){
            SharePreferenceUtil.saveString(App.application,CURRENT_USER, JSON.toJSONString(mCurrentUser));
        }
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public Long getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Long createAt) {
        this.createAt = createAt;
    }

    public Boolean getGender() {
        return gender;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }
}
