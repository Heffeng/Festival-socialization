package com.anniday.app;

public class GlobalParams {
    /**
     * SD卡的路径
     */
    public static String SDPATH;
    /**
     * 应用的SD卡文件路径
     */
    public static String APPFIEPATH;
    /**
     * 应用的版本名称
     */
    public static String appversion;
    public static int screenWidth;
    public static int screenHeight;

    public static String deviceId;
}
