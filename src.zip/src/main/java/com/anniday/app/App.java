package com.anniday.app;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.telephony.TelephonyManager;

import com.anniday.model.OSS.OSSManager;
import com.anniday.model.db.dao.DaoMaster;
import com.anniday.model.db.dao.DaoSession;
import com.anniday.model.leancloud.base.BaseLeanCloud;
import com.anniday.model.service.User;
import com.anniday.utils.NetworkUtil;
import com.facebook.drawee.backends.pipeline.Fresco;

import de.greenrobot.dao.query.QueryBuilder;

public class App extends Application {

    private static final String TAG = "App";
    public static App application;
    private DaoMaster daoMaster;
    public DaoSession daoSession;


    @Override
    public void onCreate() {
        super.onCreate();

        application = this;
        initAVOSCloud();
        NetworkUtil.getInstance().init(this);
        initSDFile();

        initVersion();

        initDentisy();

        initFresco();

        initOSS();

    }

    public void initSession() {
       if (daoMaster == null && User.getCurrentUser() != null) {
            DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this,String.valueOf(User.getCurrentUser().getUserId()), null);
            SQLiteDatabase db = helper.getWritableDatabase();
            daoMaster = new DaoMaster(db);
            daoSession = daoMaster.newSession();
            QueryBuilder.LOG_SQL = true;
            QueryBuilder.LOG_VALUES = true;
       }
    }
    private void initOSS() {
        OSSManager.init(application);
    }

    private void initFresco() {
        Fresco.initialize(this);
    }

    private void initDentisy() {
        GlobalParams.screenWidth = getResources().getDisplayMetrics().widthPixels;
        GlobalParams.screenHeight = getResources().getDisplayMetrics().heightPixels;
    }

    /**
     * 获取应用版本信息
     */
    private void initVersion() {
        try {
            // 获取deviceID
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            GlobalParams.deviceId = telephonyManager.getDeviceId();
            // 获取版本名称
            GlobalParams.appversion = getPackageManager().getPackageInfo(
                    getPackageName(), PackageManager.GET_CONFIGURATIONS).versionName;
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 初始化SD卡文件路径
     */
    public void initSDFile() {
        if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            GlobalParams.SDPATH = Environment.getExternalStorageDirectory()
                    .getAbsolutePath();
            GlobalParams.APPFIEPATH = GlobalParams.SDPATH + "/"
                    + ConsTants.APP_NAME;
        }
    }
    /**
     * 初始化AVOSCloud
     */
    private void initAVOSCloud() {
        BaseLeanCloud.init(application);
    }
}
