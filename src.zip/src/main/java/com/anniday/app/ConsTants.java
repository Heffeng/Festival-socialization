package com.anniday.app;


/**
 * 应用相关常亮
 *
 * @author Administrator
 */
public interface ConsTants {

    String APP_NAME = "Anni Day";
    String ENCODING = "UTF-8";
    String APK_NAME = "Anni Day.apk";


    /**
     * 消息通知ID
     */
    int MESSAGE_NOTIFY = 4;
    /**
     * 更新通知ID
     */
    int UPDATE_NOTIFY = 5;

    /**
     * **********NotifyJson******************************
     */
    String NOTIFY_INFO_ID = "infoId";
    String NOTIFY_USER_ID = "userId";
    String NOTIFY_STR_ACTION = "action";
    String NOTIFY_ACTION_LIKE = "com.conner.like";
    String NOTIFY_TIME = "notifyTime";
}
